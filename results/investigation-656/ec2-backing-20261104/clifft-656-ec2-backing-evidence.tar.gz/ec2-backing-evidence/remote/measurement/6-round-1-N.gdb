set pagination off
set confirm off
attach 2621
break *0x7ffff1ff3320
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
disable 1
python

import json,random,subprocess,time
from pathlib import Path
inferior=gdb.selected_inferior()
state_address=int(gdb.parse_and_eval('$rdi'))
address=int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x18)'))
imag=int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x20)'))
assert address%4096==0 and imag==address+8192
assert int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x28)'))==address+16384
assert int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x30)'))==address+20480
saved=bytes(inferior.read_memory(address,24576))
def frames(at,count=6):
    value=json.loads(subprocess.check_output(['sudo','-n','python3','/home/ubuntu/clifft-656-backing-20261104/helpers/page_frames.py',str(inferior.pid),str(at),str(count)],text=True))
    assert all(value['present']),value
    return value['pfns']
def call(expression):
    value=int(gdb.parse_and_eval(expression))
    assert value not in (-1,0,(1<<64)-1),expression
    return value
slots=Path('/home/ubuntu/clifft-656-backing-20261104/measurement/6-pool.json')
before=frames(address)
if not slots.exists():
    pool=call('(long)mmap((void*)0,1048576,3,34,-1,0)')
    inferior.write_memory(pool,b'\0'*1048576)
    pool_pfns=frames(pool,256)
    assert len(set(pool_pfns+before))==262
    colors=list(range(16));random.Random(656204+3).shuffle(colors)
    by_color={c:[p for p in pool_pfns if p%16==c] for c in colors}
    choices=[c for c in colors if len(by_color[c])>=3]
    assert len(choices)>=4,{k:len(v) for k,v in by_color.items()}
    a,b,c,d=choices[:4]
    n=[by_color[a][0],by_color[b][0],by_color[c][0],by_color[d][0]]
    conditions=dict(N=n,R=[n[0],by_color[a][1],n[2],n[3]],I=[n[0],n[1],n[2],by_color[c][1]],X=[n[0],n[1],by_color[a][2],n[3]])
    locations={str(p):pool+i*4096 for i,p in enumerate(pool_pfns)}
    locations.update({str(p):address+i*4096 for i,p in enumerate(before)})
    temporary=call('(long)mmap((void*)0,4096,0,34,-1,0)')
    state=dict(address=address,pool=pool,pool_pfns=pool_pfns,original=before.copy(),conditions=conditions,locations=locations,temporary=temporary,current=before.copy(),created=time.time())
    Path('/home/ubuntu/clifft-656-backing-20261104/measurement/6-round-1-N.predictions.json').write_text(json.dumps(state,indent=2))
else:
    state=json.loads(slots.read_text())
    assert address==state['address']
    assert before==state['current'],(before,state['current'])
target=(state['original'][:4] if 'N'=='original' else state['conditions']['N'])+state['original'][4:]
for i,desired in enumerate(target[:4]):
    current=state['current'][i]
    if current==desired:continue
    active=address+i*4096
    other=state['locations'][str(desired)]
    temporary=state['temporary']
    assert state['locations'][str(current)]==active
    assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)'%(active,temporary))==temporary
    assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)'%(other,active))==active
    assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)'%(temporary,other))==other
    assert call('(long)mmap((void*)%d,4096,0,50,-1,0)'%temporary)==temporary
    state['locations'][str(current)]=other
    state['locations'][str(desired)]=active
    state['current'][i]=desired
inferior.write_memory(address,saved)
assert bytes(inferior.read_memory(address,24576))==saved
after=frames(address)
assert after==target,(after,target)
state['current']=after
state['configuration']='N'
slots.write_text(json.dumps(state,indent=2))
evidence=dict(state_address=state_address,imag=imag,configuration='N',address=address,before=before,after=after,expected=target,restored_bytes=len(saved),conditions=state['conditions'])
Path('/home/ubuntu/clifft-656-backing-20261104/measurement/6-round-1-N.backing.json').write_text(json.dumps(evidence,indent=2))
print('PREDICTION_BACKING',json.dumps(evidence))

end
detach
quit
end
python open('/home/ubuntu/clifft-656-backing-20261104/measurement/6-round-1-N.ready','w').write('ready')
continue
