# Normal-build d5 page-backing experiment on the EC2 reference instance

This EC2 protocol is fixed before collecting EC2 perf measurements. The local attempt was interrupted after eight completed passes because another agent started C++ tests on that VM. All partial data are retained as interrupted evidence, and none enters this comparison. The maintainer has now provided SSH access to the existing clifft-bench EC2 instance and authorized stopping it when finished. The question is whether PR #657 reduces the reversible real-array backing penalty in normal builds, or mainly reduces instruction work while leaving the penalty intact.

## Identities and scope

- Parent source: `7e83ec2823bf99c54aa1b90c54a092641c10c4b0`.
- PR source: `7e1099bfe4024c1bfb11b3dc3afabfeece5f60f8`.
- Reuse the already validated normal CMake installs with function alignment 16, Clang 22.1.8, ThinLTO, lld and the same OpenMP runtime. Both AVX-512 function entries are at ELF virtual offset `0x1c4320`.
- Parent extension SHA-256: `eb3a4f103ee26bbb66cf4c456d25853d46c29cd212efa9da2b40dedeb86cc9e9`.
- PR extension SHA-256: `eaaf6657215e21922ee688cd9ae49f453b1ccc386199330f0bbacdb00acd399e`.
- Exact build packages and build settings are retained at the preceding evidence commit `247aac6073af0a6ac328d7180b4872f49f58c043` in clifft-bench.
- Direct batch 1, cultivation d5, the pinned benchmark adapter and full sampling/output semantics. CPU 0, ASLR disabled, Python hash seed 0, thread caps set before import, 12 GiB address-space ceiling. Host: the existing m7a.xlarge clifft-bench instance, AMD EPYC 9R14, four vCPUs, Ubuntu 24.04, kernel 7.0.0-1014-aws. This is a fixed-work diagnostic on the reference instance, not a release-harness run. The exact local normal binaries, Python 3.12.14, NumPy 2.5.4, OpenMP 18 shared library and pinned adapter/workload are copied without rebuilding. Host libc/libstdc++ and kernel are recorded. Perf 7.0.14 is used.

## Fixed experiment

Four fresh experimental workers per build, selected by creation order, plus one unchanged reference worker per build: ten measured workers total. There are four chronological blocks containing one parent and one PR worker; creation order alternates parent/PR then PR/parent. Both workers in each block use the same deterministic color preference, but select their own physical frames. No workers or pages are selected using performance.

Reuse the anonymous-page exchange method from the earlier probe, with its restoration bookkeeping corrected. At a separate diagnostic breakpoint at the actual width-10 State, allocate/fault a 256-page pool. Choose four distinct PFN-modulo-16 digits a,b,c,d, with at least three available frames per digit, in the order from Python Random(656204 + block). Choose the first available frames of those digits in pool-address order.

- N uses coefficient digits [a,b,c,d].
- R uses [a,a,c,d], changing only the upper real coefficient page to a distinct full PFN with the same modulo-16 digit as the lower real page.
- Repeats use the exact same actual frames. The four coefficient VAs, current bytes, code, and both original scratch pages remain fixed within each worker.
- These labels predict a tendency based on prior evidence. N is not assumed fast and R is not assumed slow in every new worker.
- Experimental block orders are NRRN, RNNR, NRRN, RNNR. Rotate block execution order each round and reverse build order within each block on odd rounds. The two unchanged reference workers run once per round, with their order reversed on odd rounds.
- Each pass: 100 API calls x 20,000 attempted shots; seeds 20270819 through 20270918. Two N and two R passes per experimental worker; four passes per reference. Total: 40 measured passes, 80 million attempted shots.
- Measure cycles:u and instructions:u, retaining perf scheduled-time percentages, wall time and process CPU time. No compilation or test suite runs concurrently with measurement.

## Validation and analysis

A separate untimed smoke run exercises N/R reversals and exact seeded full-output checks on both builds, and verifies restoration. Its workers are excluded from the fixed measurement cohort.

Every worker asserts the extension hash, selected ISA and batch. Full-output checks at setup and after restoration must match across builds for three fixed seeds. Each diagnostic and measured call must preserve its expected exact aggregate counts. Record actual live State addresses/PFNs through GDB, and validate all six PFNs immediately before and after each timed pass. After each measured pass, a separate diagnostic call confirms that the actual live State still uses those pages. At completion, verify restoration against an independent pre-intervention record, then stop every worker. Retain failed validation runs if any; do not replace timing observations to obtain a favorable result.

The primary quantity is each experimental worker's percentage cycle penalty: 100 * (median(R) / median(N) - 1). Report all eight penalties, their ranges and build medians, and the descriptive difference between build medians. Also report per-block differences, within-condition repeat variation, exact instruction counts and both reference time series. Interpretation depends on whether the expected parent penalty reproduces and whether reduction is consistent across blocks; no statistical population or universal placement claim follows from four workers per build.

Physical frames and other process data are not identical between parent and PR workers. The causal contrasts are the within-worker N/R exchanges. Comparing those contrasts across builds is a small repeated-cohort comparison, not the same-frame patch intervention. This deliberately preserves the previous anonymous-allocation experiment instead of changing the allocation mechanism. One alignment and one backing relationship cannot establish that all sensitivity is resolved.

Regardless of outcome, finish this bounded cohort and publish the evidence in #656. No allocator changes, source bisect or new instance launch are included. A two-hour OS shutdown fallback is armed, and the maintainer confirmed instance-initiated shutdown is configured to Stop. Retrieve and hash-verify evidence before issuing final shutdown; the maintainer will confirm AWS stopped state because SSH access cannot verify it.

Input archive SHA-256: `0791ec633466e3614a7b22e359872a0ec2579861a941166f2ff758c0372cb1f0`. All individual input files are hash-verified remotely before running. Temporary perf/ptrace settings are recorded and restored after profiling.
