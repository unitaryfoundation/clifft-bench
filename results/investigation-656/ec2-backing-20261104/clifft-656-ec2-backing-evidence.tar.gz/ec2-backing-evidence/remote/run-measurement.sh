#!/bin/bash
set -eu
cd /home/ubuntu/clifft-656-backing-20261104
paranoid=$(cat /proc/sys/kernel/perf_event_paranoid)
ptrace=$(cat /proc/sys/kernel/yama/ptrace_scope)
monitor_pid=''
cleanup() {
  result=$?
  if test -n "$monitor_pid"; then kill "$monitor_pid" 2>/dev/null || true; wait "$monitor_pid" 2>/dev/null || true; fi
  sudo -n sysctl -w "kernel.perf_event_paranoid=$paranoid" "kernel.yama.ptrace_scope=$ptrace" > restored-settings.log
  printf '%s\n' "$result" > exit.status
}
trap cleanup EXIT
sudo -n sysctl -w kernel.perf_event_paranoid=1 kernel.yama.ptrace_scope=0 > profiling-settings.log
taskset -c 3 python3 monitor.py &
monitor_pid=$!
timeout --signal=INT --kill-after=30s 75m python3 run.py > measurement.log 2>&1
