set pagination off
set confirm off
attach 1900
break *0x7ffff1ff3320
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
disable 1
python
import json,subprocess
from pathlib import Path
address=int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x18)'))
evidence=json.loads(subprocess.check_output(['sudo','-n','python3','/home/ubuntu/clifft-656-backing-20261104/helpers/page_frames.py',str(gdb.selected_inferior().pid),str(address),'6'],text=True))
evidence['state_address']=int(gdb.parse_and_eval('$rdi'))
evidence['imag']=int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x20)'))
assert evidence['imag']==address+8192 and all(evidence['present'])
Path('/home/ubuntu/clifft-656-backing-20261104/smoke/1-smoke-observe-R3.observed.json').write_text(json.dumps(evidence,indent=2))
end
detach
quit
end
python open('/home/ubuntu/clifft-656-backing-20261104/smoke/1-smoke-observe-R3.ready','w').write('ready')
continue
