"""Validate and summarize the fixed normal-build backing experiment."""
import csv,hashlib,json,statistics,sys
from pathlib import Path
root=Path(sys.argv[1])
events=[json.loads(s) for s in (root/'measurement/results.jsonl').read_text().splitlines()]
raw=root/'measurement'
setup={e['worker']:e for e in events if e.get('phase')=='prepare'}
assert len(setup)==10
expected_shas={'parent':'eb3a4f103ee26bbb66cf4c456d25853d46c29cd212efa9da2b40dedeb86cc9e9','candidate':'eaaf6657215e21922ee688cd9ae49f453b1ccc386199330f0bbacdb00acd399e'}
for e in setup.values():
 assert e['result']['extension_sha256']==expected_shas[e['variant']]
 assert e['result']['runtime_isa']=='avx512' and e['result']['metadata']['effective_batch_size']==1
correct=[e for e in events if e.get('request',{}).get('command')=='correctness']
assert len(correct)==18
assert all(e['result']==correct[0]['result'] for e in correct)
rows=[]
for event in events:
 request=event.get('request',{})
 if request.get('command')!='sample':continue
 calls=request['calls'];result=event['result']
 assert result['totals']==([2000000,287417,1712583,0] if calls==100 else [20000,2852,17148,0])
 if calls!=100:continue
 worker=event['worker'];phase=event['phase']
 counters={}
 for line in (raw/f'{worker}-{phase}.csv').read_text().splitlines():
  fields=line.split(',')
  if len(fields)>5 and fields[2] in ['cycles:u','instructions:u']:
   assert float(fields[4])==100.0,fields
   counters[fields[2].split(':')[0]]=int(fields[0])
 assert len(counters)==2
 verification=[e for e in events if e.get('action')=='verified-measurement' and e['worker']==worker and e['phase']==phase]
 assert len(verification)==1
 v=verification[0];assert v['before']['pfns']==v['after']['pfns'] and all(v['before']['present']) and all(v['after']['present'])
 obs=[e for e in events if e.get('action')=='observed-backing' and e['worker']==worker and e['phase']==phase+'-after']
 assert len(obs)==1 and obs[0]['evidence']['pfns']==v['after']['pfns'] and obs[0]['evidence']['address']==v['after']['address']
 if not event['control']:
  conf=[e for e in events if e.get('action')=='configuration' and e['worker']==worker and e['phase']==phase]
  assert len(conf)==1 and conf[0]['evidence']['after']==v['before']['pfns']
  original=json.loads((raw/f'{worker}-setup.predictions.json').read_text())
  assert v['before']['pfns'][4:]==original['original'][4:]
 rows.append(dict(worker=worker,variant=event['variant'],pair=event['pair'],control=event['control'],phase=phase,configuration='control' if event['control'] else phase[-1],**counters,seconds=result['seconds'],cpu_seconds=result['cpu_seconds'],cpu_to_wall=result['cpu_seconds']/result['seconds'],shots=result['totals'][0],throughput=result['totals'][0]/result['seconds']))
assert len(rows)==40 and sum(r['shots'] for r in rows)==80000000
configs=[e for e in events if e.get('action')=='configuration'];assert len(configs)==48
for e in configs:
 v=e['evidence'];assert v['after']==v['expected'] and len(set(v['after']))==6 and v['restored_bytes']==24576
 a,b,c,d=[p%16 for p in v['after'][:4]]
 if v['configuration']=='N':assert len({a,b,c,d})==4
 elif v['configuration']=='R':assert a==b and len({a,c,d})==3
for w in range(8):
 initial=json.loads((raw/f'{w}-setup.predictions.json').read_text())
 final=json.loads((raw/f'{w}-pool.json').read_text())
 assert final['current']==final['original']==initial['original']
 restoration=[e for e in events if e.get('action')=='restoration-verified' and e['worker']==w]
 assert len(restoration)==1 and restoration[0]['pfns']==initial['original']
exits=[e for e in events if e.get('action')=='worker-exit'];assert len(exits)==10 and all(e['returncode']==0 for e in exits)
workers=[]
for worker in range(8):
 source=setup[worker]
 conditions={}
 for conf in ['N','R']:
  selected=[r for r in rows if r['worker']==worker and r['configuration']==conf];assert len(selected)==2
  cycles=[r['cycles'] for r in selected];instructions=[r['instructions'] for r in selected]
  conditions[conf]=dict(cycles=cycles,median_cycles=statistics.median(cycles),median_instructions=statistics.median(instructions),repeat_range_percent=100*(max(cycles)/min(cycles)-1))
 penalty=100*(conditions['R']['median_cycles']/conditions['N']['median_cycles']-1)
 workers.append(dict(worker=worker,variant=source['variant'],pair=source['pair'],conditions=conditions,penalty_percent=penalty))
builds={}
for variant in ['parent','candidate']:
 selected=[w for w in workers if w['variant']==variant];penalties=[w['penalty_percent'] for w in selected]
 builds[variant]=dict(penalties_percent=penalties,median_penalty_percent=statistics.median(penalties),range_penalty_percent=[min(penalties),max(penalties)],positive_workers=sum(p>0 for p in penalties),median_instructions=statistics.median(r['instructions'] for r in rows if r['variant']==variant and not r['control']))
refs=[]
for worker in [8,9]:
 selected=[r for r in rows if r['worker']==worker];assert len(selected)==4
 observations=[e['evidence'] for e in events if e.get('action')=='observed-backing' and e['worker']==worker]
 assert len(observations)==9 and all(o['pfns']==observations[0]['pfns'] and o['address']==observations[0]['address'] for o in observations)
 vals=[r['cycles'] for r in selected]
 refs.append(dict(worker=worker,variant=setup[worker]['variant'],cycles=vals,range_percent=100*(max(vals)/min(vals)-1),cpu_to_wall=[r['cpu_to_wall'] for r in selected]))
blocks=[]
for pair in range(4):
 p=next(w for w in workers if w['pair']==pair and w['variant']=='parent')['penalty_percent']
 c=next(w for w in workers if w['pair']==pair and w['variant']=='candidate')['penalty_percent']
 blocks.append(dict(pair=pair,parent_penalty_percent=p,candidate_penalty_percent=c,difference_percentage_points=c-p))
summary=dict(workers=workers,builds=builds,blocks=blocks,references=refs,profiled_passes=len(rows),measured_attempted_shots=sum(r['shots'] for r in rows),full_output_seed_checks=3*len(correct),restored_workers=8,exited_workers=10,instruction_change_percent=100*(builds['candidate']['median_instructions']/builds['parent']['median_instructions']-1),median_penalty_difference_percentage_points=builds['candidate']['median_penalty_percent']-builds['parent']['median_penalty_percent'],blocks_with_smaller_candidate_penalty=sum(b['difference_percentage_points']<0 for b in blocks),cpu_to_wall_range=[min(r['cpu_to_wall'] for r in rows),max(r['cpu_to_wall'] for r in rows)])
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (root/'samples.csv').open('w') as stream:
 writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,indent=2))
