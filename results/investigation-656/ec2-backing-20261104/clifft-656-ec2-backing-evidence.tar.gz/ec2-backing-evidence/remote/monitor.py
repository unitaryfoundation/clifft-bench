"""Low-frequency host activity log, outside the benchmark CPU."""
import json,time
from pathlib import Path
with Path('host-activity.jsonl').open('w') as stream:
 while True:
  row=dict(time=time.time(),stat=Path('/proc/stat').read_text(),load=Path('/proc/loadavg').read_text(),memory=Path('/proc/meminfo').read_text(),processes=[])
  for path in Path('/proc').iterdir():
   if not path.name.isdigit():continue
   try:
    stat=(path/'stat').read_text();right=stat.rfind(')');fields=stat[right+2:].split()
    row['processes'].append(dict(pid=int(path.name),comm=stat[stat.find('(')+1:right],ticks=int(fields[11])+int(fields[12]),cpu=int(fields[36])))
   except (OSError,ValueError,IndexError):continue
  stream.write(json.dumps(row)+'\n');stream.flush();time.sleep(10)
