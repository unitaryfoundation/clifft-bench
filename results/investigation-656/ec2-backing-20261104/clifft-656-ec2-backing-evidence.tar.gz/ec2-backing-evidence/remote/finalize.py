"""Freeze validated remote evidence before copying it off the instance."""
import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
assert (root/'exit.status').read_text().strip()=='0'
rows=[json.loads(s) for s in (root/'measurement/results.jsonl').read_text().splitlines()]
pids={r['pid'] for r in rows if r.get('action')=='request'}
assert all(not Path(f'/proc/{pid}').exists() for pid in pids)
assert Path('/proc/sys/kernel/perf_event_paranoid').read_text().strip()=='4'
assert Path('/proc/sys/kernel/yama/ptrace_scope').read_text().strip()=='1'
(root/'shutdown-scheduled.txt').write_text(Path('/run/systemd/shutdown/scheduled').read_text())
identities={}
for path in (root/'measurement').glob('*.maps'):
 for line in path.read_text().splitlines():
  fields=line.split()
  if len(fields)<6:continue
  name=fields[-1]
  if not name.startswith('/') or name in identities:continue
  source=Path(name)
  if source.is_file():identities[name]=dict(bytes=source.stat().st_size,sha256=hashlib.sha256(source.read_bytes()).hexdigest())
(root/'loaded-file-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
selected=[]
for name in ['measurement','smoke','setup-failure-affinity']:
 selected.extend(p for p in (root/name).rglob('*') if p.is_file())
for p in root.iterdir():
 if p.is_file() and (p.suffix in ['.py','.sh','.log','.json','.jsonl','.md','.csv','.status','.txt']) and p.name not in ['raw-file-sha256.json']:
  selected.append(p)
selected=sorted(set(selected))
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in selected}
(root/'raw-file-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(root/'remote-evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for p in selected+[root/'raw-file-sha256.json']:
  tar.add(p,arcname=str(p.relative_to(root)))
archive=root/'remote-evidence.tar.gz'
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(root/'remote-evidence.sha256').write_text(sha+'  remote-evidence.tar.gz\n')
print('Frozen files:',len(manifest),'archive bytes:',archive.stat().st_size,'SHA256:',sha)
print('All measured workers exited and original profiling settings restored.')
