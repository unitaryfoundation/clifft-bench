"""Summarize host activity without mistaking idle coexisting processes for load."""
import json,statistics,sys
from pathlib import Path
root=Path(sys.argv[1])
rows=[json.loads(s) for s in (root/'host-activity.jsonl').read_text().splitlines()]
def cpu(row,key):
 line=next(s for s in row['stat'].splitlines() if s.split()[0]==key)
 return list(map(int,line.split()[1:]))
intervals=[]
process_ticks={}
for old,new in zip(rows,rows[1:]):
 dt=new['time']-old['time']
 delta=[b-a for a,b in zip(cpu(old,'cpu0'),cpu(new,'cpu0'))];total=sum(delta[:8])
 intervals.append(dict(seconds=dt,cpu0_user_percent=100*delta[0]/total,cpu0_system_percent=100*delta[2]/total,cpu0_idle_percent=100*delta[3]/total,cpu0_steal_percent=100*delta[7]/total))
 before={p['pid']:p for p in old['processes']}
 for p in new['processes']:
  if p['pid'] in before and p['comm']==before[p['pid']]['comm']:
   ticks=p['ticks']-before[p['pid']]['ticks']
   process_ticks[p['comm']]=process_ticks.get(p['comm'],0)+ticks
summary=dict(snapshots=len(rows),duration_seconds=rows[-1]['time']-rows[0]['time'],cpu0_steal_percent_range=[min(i['cpu0_steal_percent'] for i in intervals),max(i['cpu0_steal_percent'] for i in intervals)],cpu0_steal_percent_median=statistics.median(i['cpu0_steal_percent'] for i in intervals),observed_process_tick_increments=dict(sorted(process_ticks.items(),key=lambda p:-p[1])),minimum_mem_available_kib=min(int(next(s.split()[1] for s in row['memory'].splitlines() if s.startswith('MemAvailable:'))) for row in rows),limits='Ten-second snapshots can miss short-lived processes. Tick increments are lower bounds for processes whose start/exit falls between snapshots; the log is a check for sustained competing work, not proof of complete host isolation.')
(root/'activity-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
