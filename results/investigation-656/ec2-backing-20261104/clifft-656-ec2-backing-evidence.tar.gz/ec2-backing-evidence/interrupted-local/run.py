"""Bounded anonymous-backing experiment on the exact normal parent/PR builds."""
import argparse, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path('/tmp/clifft-656-placement')
BUILD=Path('/tmp/clifft-656-next')
HERE=Path(__file__).resolve().parent
BENCH=Path('/tmp/clifft-rc-investigation/bench')
PERF='/usr/lib/linux-tools/6.8.0-106-generic/perf'
sys.path.insert(0,str(BENCH/'src'))
from clifft_bench.system import restricted_environment
parser=argparse.ArgumentParser()
parser.add_argument('--smoke',action='store_true')
args=parser.parse_args()
OUT=HERE/('smoke' if args.smoke else 'measurement');OUT.mkdir()
output=(OUT/'results.jsonl').open('w')
processes=[]
ORDER=['NRRN','RNNR','NRRN','RNNR']
CORE='cycles:u,instructions:u'
raw=json.loads((BENCH/'results/release-v1/0.13.0rc1-20261103-183623/raw.json').read_text())
case=next(c for c in raw['cases'] if c['case_id']=='msc-d5-inject-cultivate-p1e-3--clifft-current')
SHAS={'parent':'eb3a4f103ee26bbb66cf4c456d25853d46c29cd212efa9da2b40dedeb86cc9e9','candidate':'eaaf6657215e21922ee688cd9ae49f453b1ccc386199330f0bbacdb00acd399e'}
expected_correctness=None


def save(value):
    output.write(json.dumps(value)+'\n');output.flush()


def frames(worker,address):
    return json.loads(subprocess.check_output(['sudo','-n','python3',str(ROOT/'page_frames.py'),str(worker.process.pid),str(address),'6'],text=True))


class Worker:
    def __init__(self,index,variant,pair,control=False):
        self.index=index;self.variant=variant;self.pair=pair;self.control=control
        self.identity=dict(worker=index,variant=variant,pair=pair,control=control)
        env=restricted_environment();env['PYTHONHASHSEED']='0'
        env['PYTHONPATH']=str(BUILD/f'{variant}-16')+':'+str(BENCH/'src')
        command=['setarch','x86_64','-R',str(BUILD/'build-env/bin/python'),str(HERE/'normal_worker.py')]
        self.process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(OUT/f'{index}.stderr').open('w'),text=True,env=env)
        processes.append(self.process)
        result=self.request(dict(command='prepare',case=case,artifact=str(BENCH/'workloads/circuits'/Path(case['workload']['artifact']['path']).name),batch_size=1),'prepare')
        assert result['extension_sha256']==SHAS[variant] and result['runtime_isa']=='avx512'
        assert result['metadata']['effective_batch_size']==1
        (OUT/f'{index}.maps').write_text(Path(f'/proc/{self.process.pid}/maps').read_text())
        self.correctness('initial')

    def request(self,request,phase):
        self.process.stdin.write(json.dumps(request)+'\n');self.process.stdin.flush()
        line=self.process.stdout.readline()
        assert line,(self.index,(OUT/f'{self.index}.stderr').read_text())
        result=json.loads(line);assert result['ok'],result
        save(dict(action='request',**self.identity,pid=self.process.pid,phase=phase,request=request,result=result))
        return result

    def correctness(self,label):
        global expected_correctness
        result=self.request(dict(command='correctness',shots=2048),'correctness-'+label)
        if expected_correctness is None:expected_correctness=result
        assert result==expected_correctness,(self.index,label,result)

    def sample(self,phase,calls=100):
        result=self.request(dict(command='sample',shots=20000,calls=calls),phase)
        expected=[2000000,287417,1712583,0] if calls==100 else [20000,2852,17148,0]
        assert result['totals']==expected,(self.index,phase,result)
        return result

    def profile(self,phase):
        prefix=OUT/f'{self.index}-{phase}'
        before=frames(self,self.address)
        with Path(str(prefix)+'.perf-log').open('w') as log:
            profiler=subprocess.Popen([PERF,'stat','-p',str(self.process.pid),'-x',',','-e',CORE,'-o',str(prefix)+'.csv'],stdout=log,stderr=log)
            try:
                time.sleep(.15);assert profiler.poll() is None
                result=self.sample(phase)
            finally:
                profiler.send_signal(signal.SIGINT);profiler.wait(timeout=10)
        after=frames(self,self.address)
        assert before['pfns']==after['pfns'] and all(before['present']) and all(after['present'])
        if not self.control:
            state=json.loads((OUT/f'{self.index}-pool.json').read_text())
            assert before['pfns']==state['current']
        save(dict(action='verified-measurement',**self.identity,phase=phase,before=before,after=after))
        print('measured',self.index,self.variant,phase,round(result['totals'][0]/result['seconds']),flush=True)


def observe(worker,label):
    mapping=next(line.split() for line in Path(f'/proc/{worker.process.pid}/maps').read_text().splitlines() if '_clifft_core.abi3.so' in line and 'r-xp' in line)
    pc=int(mapping[0].split('-')[0],16)+0x1c3320-int(mapping[2],16)
    prefix=OUT/f'{worker.index}-{label}'
    ready=Path(str(prefix)+'.ready');assert not ready.exists()
    script=f'''set pagination off
set confirm off
attach {worker.process.pid}
break *{pc:#x}
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
disable 1
python
import json,subprocess
from pathlib import Path
address=int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x18)'))
evidence=json.loads(subprocess.check_output(['sudo','-n','python3',{str(ROOT/'page_frames.py')!r},str(gdb.selected_inferior().pid),str(address),'6'],text=True))
evidence['state_address']=int(gdb.parse_and_eval('$rdi'))
evidence['imag']=int(gdb.parse_and_eval('*(unsigned long long*)($rdi+0x20)'))
assert evidence['imag']==address+8192 and all(evidence['present'])
Path({str(prefix)+'.observed.json'!r}).write_text(json.dumps(evidence,indent=2))
end
detach
quit
end
python open({str(ready)!r},'w').write('ready')
continue
'''
    Path(str(prefix)+'.gdb').write_text(script)
    with Path(str(prefix)+'.gdb-log').open('w') as log:
        debugger=subprocess.Popen(['gdb','-q','-nx','-batch','-x',str(prefix)+'.gdb'],stdout=log,stderr=subprocess.STDOUT)
        until=time.monotonic()+15
        while not ready.exists() and debugger.poll() is None and time.monotonic()<until:time.sleep(.05)
        assert ready.exists(),Path(str(prefix)+'.gdb-log').read_text()
        worker.sample('debug-'+label,1)
        debugger.wait(timeout=20)
        assert debugger.returncode==0,Path(str(prefix)+'.gdb-log').read_text()
    evidence=json.loads(Path(str(prefix)+'.observed.json').read_text())
    address=int(evidence['address'],16)
    if hasattr(worker,'address'):assert worker.address==address
    worker.address=address
    if not worker.control:
        state=json.loads((OUT/f'{worker.index}-pool.json').read_text())
        assert evidence['pfns']==state['current']
    save(dict(action='observed-backing',**worker.identity,phase=label,evidence=evidence))
    return evidence


exec((HERE/'configure_fragment.py').read_text())

try:
    workers=[]
    for pair in range(1 if args.smoke else 4):
        for variant in (['parent','candidate'] if pair%2==0 else ['candidate','parent']):
            worker=Worker(len(workers),variant,pair);workers.append(worker)
            configure(worker,ORDER[pair][0],'setup')
    controls=[]
    if not args.smoke:
        for variant in ['parent','candidate']:
            worker=Worker(len(workers)+len(controls),variant,None,True);controls.append(worker)
            observe(worker,'initial-control')
    # The smoke run exercises both swaps and restoration without collecting perf timings.
    if args.smoke:
        for label in ['N','R','N','R']:
            for worker in workers:
                configure(worker,label,'smoke-'+label+str(sum(1 for _ in OUT.glob(f'{worker.index}-smoke-*.backing.json'))))
                worker.correctness(label)
                observe(worker,'smoke-observe-'+label+str(sum(1 for _ in OUT.glob(f'{worker.index}-*.observed.json'))))
    else:
        for round_index in range(4):
            pairs=list(range(4));pairs=pairs[round_index:]+pairs[:round_index]
            for pair in pairs:
                pair_workers=[w for w in workers if w.pair==pair]
                if round_index%2:pair_workers.reverse()
                for worker in pair_workers:
                    label=ORDER[pair][round_index];phase=f'round-{round_index}-{label}'
                    configure(worker,label,phase)
                    worker.profile(phase)
                    observe(worker,phase+'-after')
            for worker in (controls if round_index%2==0 else list(reversed(controls))):
                phase=f'control-round-{round_index}'
                observe(worker,phase+'-before')
                worker.profile(phase)
                observe(worker,phase+'-after')
    for worker in workers:
        configure(worker,'original','restore-original')
        state=json.loads((OUT/f'{worker.index}-pool.json').read_text())
        prediction=json.loads((OUT/f'{worker.index}-setup.predictions.json').read_text())
        assert state['current']==state['original']==prediction['original']
        observe(worker,'restored-check')
        worker.correctness('restored')
        save(dict(action='restoration-verified',**worker.identity,pfns=state['current']))
finally:
    for process in processes:
        if process.poll() is None:
            process.stdin.close()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=5)
        save(dict(action='worker-exit',pid=process.pid,returncode=process.returncode))
    output.close()
