"""Clifft core C++ extension module"""

from collections.abc import Mapping, Sequence
import enum
from typing import Annotated, Literal, overload

import numpy
from numpy.typing import NDArray

import clifft


class BatchTuningTrial:
    """
    Timing for one batch-size candidate. The first probe is recorded as warmup; its throughput is used when no subsequent measurement is available.
    """

    @property
    def batch_size(self) -> int: ...

    @property
    def shot_workers(self) -> int: ...

    @property
    def warmup_shots(self) -> int: ...

    @property
    def shots(self) -> int: ...

    @property
    def setup_seconds(self) -> float: ...

    @property
    def warmup_seconds(self) -> float: ...

    @property
    def elapsed_seconds(self) -> float: ...

    @property
    def used_warmup(self) -> bool:
        """Whether throughput comes from the first probe only."""

    @property
    def shots_per_second(self) -> float:
        """
        Attempted-shot throughput used for selection, or zero without timing data.
        """

    def __repr__(self) -> str: ...

class BatchTuningReport:
    """
    Calibration outcome and reusable batch size. sufficient_measurements says whether the automatic choice and an alternative were compared; stop_reason records why calibration ended, including budget exhaustion even when falling back to auto.
    """

    @property
    def batch_size(self) -> int: ...

    @property
    def baseline_batch_size(self) -> int: ...

    @property
    def shot_workers(self) -> int: ...

    @property
    def intra_shot_workers(self) -> int: ...

    @property
    def trial_shots(self) -> int: ...

    @property
    def elapsed_seconds(self) -> float: ...

    @property
    def sufficient_measurements(self) -> bool: ...

    @property
    def stop_reason(self) -> str: ...

    @property
    def trials(self) -> list[BatchTuningTrial]: ...

    def __repr__(self) -> str: ...

class ParseError(Exception):
    pass

def version() -> str:
    """Return the Clifft version string"""

def runtime_isa() -> str:
    """
    Return the resolved kernel ISA: 'scalar', 'neon', 'avx2', 'avx512', or a 'trap:...' value when CLIFFT_FORCE_ISA requests an unavailable backend
    """

class _NonComputationalModel:
    pass

class _NonComputationalProgram:
    @property
    def strategy(self) -> str: ...

    def explain(self) -> str: ...

    def sample(self, shots: int, seed: int | None = None, threads: int | str | None = 1, *, batch_size: int | str = 'auto', collect_stats: bool = False, tuning_budget_seconds: float | None = None) -> tuple: ...

def _compile_noncomputational(circuit: Circuit, model: _NonComputationalModel, final_status: bool = False, execution: str = 'auto', max_active_width: int | None = None) -> _NonComputationalProgram: ...

class _FixedNonComputationalProgram:
    def sample(self, shots: int, seed: int | None = None, threads: int | None = 1, *, batch_size: int | str = 'auto') -> tuple: ...

    @property
    def metrics(self) -> dict: ...

def _prepare_noncomputational_fixed(circuit: Circuit, model: _NonComputationalModel, final_status: bool = False, max_active_width: int | None = None) -> object: ...

def _build_noncomp_model(initial_state: Sequence[float], transitions: Mapping[str, Sequence[Sequence[float]]], classifier_matrix: Sequence[Sequence[float]] | None = None, reset_restores_lost: bool = False, damping: str = 'exact', gate_partner_effects: Mapping[str, Sequence[float]] = {}, interactions: Sequence[tuple[str, int, str, Sequence[float]]] = []) -> _NonComputationalModel:
    """
    Build the built-in five-level NonComputationalModel from raw matrices. See clifft.noncomp.Model.
    """

def _sample_noncomputational(circuit: Circuit, model: _NonComputationalModel, shots: int, seed: int | None = None, max_active_width: int | None = None, threads: int | str = 1) -> tuple:
    """Sample a noncomputational model with Clifft's sampler."""

def _num_optypes() -> int: ...

def _num_gate_types() -> int: ...

def _gate_metadata() -> dict: ...

class GateType(enum.Enum):
    """Quantum gate types"""

    H = 0

    S = 1

    S_DAG = 2

    X = 3

    Y = 4

    Z = 5

    SQRT_X = 6

    SQRT_X_DAG = 7

    SQRT_Y = 8

    SQRT_Y_DAG = 9

    H_XY = 10

    H_YZ = 11

    H_NXY = 12

    H_NXZ = 13

    H_NYZ = 14

    C_XYZ = 15

    C_ZYX = 16

    C_NXYZ = 17

    C_NZYX = 18

    C_XNYZ = 19

    C_XYNZ = 20

    C_ZNYX = 21

    C_ZYNX = 22

    SPP = 23

    SPP_DAG = 24

    T = 25

    T_DAG = 26

    TPP = 27

    TPP_DAG = 28

    R_X = 29

    R_Y = 30

    R_Z = 31

    U3 = 32

    R_XX = 33

    R_YY = 34

    R_ZZ = 35

    R_PAULI = 36

    CX = 37

    CY = 38

    CZ = 39

    SWAP = 40

    ISWAP = 41

    ISWAP_DAG = 42

    SQRT_XX = 43

    SQRT_XX_DAG = 44

    SQRT_YY = 45

    SQRT_YY_DAG = 46

    SQRT_ZZ = 47

    SQRT_ZZ_DAG = 48

    CXSWAP = 49

    CZSWAP = 50

    SWAPCX = 51

    XCX = 52

    XCY = 53

    XCZ = 54

    YCX = 55

    YCY = 56

    YCZ = 57

    M = 58

    MX = 59

    MY = 60

    MR = 61

    MRX = 62

    MRY = 70

    MPP = 63

    MXX = 64

    MYY = 65

    MZZ = 66

    R = 67

    RX = 68

    RY = 69

    MPAD = 71

    I = 72

    II = 73

    I_ERROR = 74

    II_ERROR = 75

    X_ERROR = 76

    Y_ERROR = 77

    Z_ERROR = 78

    DEPOLARIZE1 = 79

    DEPOLARIZE2 = 80

    DEPOLARIZE3 = 81

    PAULI_CHANNEL_1 = 82

    PAULI_CHANNEL_2 = 83

    PAULI_CHANNEL_3 = 84

    CORRELATED_ERROR = 85

    ELSE_CORRELATED_ERROR = 86

    READOUT_NOISE = 87

    DETECTOR = 88

    OBSERVABLE_INCLUDE = 89

    TICK = 90

    LEVEL_TRANSITION = 91

    LEAKAGE = 92

    LOSS = 93

    LEAKAGE_INTERACTION = 100

    LOSS_INTERACTION = 101

    HERALD_LEAKAGE_EVENT = 94

    HERALD_LOSS_EVENT = 95

    EXP_VAL = 96

    CH = 97

    CCX = 98

    CCZ = 99

    UNKNOWN = 102

class Target:
    """Encoded quantum target"""

    @property
    def value(self) -> int: ...

    @property
    def is_rec(self) -> bool: ...

    @property
    def is_inverted(self) -> bool: ...

    @property
    def has_pauli(self) -> bool: ...

    @property
    def pauli(self) -> int: ...

    @property
    def pauli_char(self) -> str: ...

    def __repr__(self) -> str: ...

class AstNode:
    """A single circuit operation"""

    @property
    def gate(self) -> GateType: ...

    @property
    def targets(self) -> list[Target]: ...

    @property
    def tag(self) -> str: ...

    @property
    def arg(self) -> float: ...

    @property
    def args(self) -> list[float]: ...

    @property
    def source_line(self) -> int: ...

    def __repr__(self) -> str: ...

class Circuit:
    """A parsed quantum circuit"""

    @property
    def nodes(self) -> list[AstNode]: ...

    @property
    def num_qubits(self) -> int: ...

    @property
    def num_measurements(self) -> int: ...

    def __len__(self) -> int: ...

    def __repr__(self) -> str: ...

class Qasm2Import:
    """
    A natively parsed unitary OpenQASM 2 circuit and its source phase correction
    """

    @property
    def circuit(self) -> Circuit: ...

    @property
    def global_phase_half_turns(self) -> float:
        """Source phase correction t representing exp(i * pi * t)."""

    @property
    def num_qubits(self) -> int: ...

    def __len__(self) -> int: ...

    def __repr__(self) -> str: ...

@overload
def parse(text: str) -> Circuit:
    """Parse a quantum circuit from a string."""

@overload
def parse(text: str, max_ops: int) -> Circuit:
    """Parse a quantum circuit from a string with an explicit AST node limit."""

@overload
def parse_file(path: str) -> Circuit:
    """Parse a quantum circuit from a file."""

@overload
def parse_file(path: str, max_ops: int) -> Circuit:
    """Parse a quantum circuit from a file with an explicit AST node limit."""

@overload
def parse_qasm2(text: str) -> Qasm2Import:
    """Parse and lower a unitary OpenQASM 2 circuit."""

@overload
def parse_qasm2(text: str, max_ops: int) -> Qasm2Import:
    """
    Parse and lower a unitary OpenQASM 2 circuit with an explicit AST node limit.
    """

@overload
def parse_qasm2_file(path: str) -> Qasm2Import:
    """Parse and lower a unitary OpenQASM 2 circuit file."""

@overload
def parse_qasm2_file(path: str, max_ops: int) -> Qasm2Import:
    """
    Parse and lower a unitary OpenQASM 2 file with an explicit AST node limit.
    """

class OpType(enum.Enum):
    """Heisenberg IR operation types"""

    T_GATE = 0

    MEASURE = 1

    CONDITIONAL_PAULI = 2

    NOISE = 3

    READOUT_NOISE = 4

    PHASE_ROTATION = 5

    DETECTOR = 6

    OBSERVABLE = 7

    EXP_VAL = 8

    INSTRUMENT = 9

class HeisenbergOp:
    """A single abstract operation in the Heisenberg IR"""

    @property
    def op_type(self) -> OpType: ...

    @property
    def is_dagger(self) -> bool: ...

    @property
    def is_hidden(self) -> bool: ...

    @property
    def sign(self) -> bool: ...

    @property
    def pauli_string(self) -> str: ...

    def as_dict(self) -> dict:
        """Return a JSON-friendly dictionary representation."""

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

class HirModule:
    """Heisenberg Intermediate Representation"""

    @property
    def num_ops(self) -> int: ...

    @property
    def num_t_gates(self) -> int: ...

    @property
    def num_qubits(self) -> int: ...

    @property
    def num_measurements(self) -> int: ...

    @property
    def num_detectors(self) -> int: ...

    @property
    def num_observables(self) -> int: ...

    @property
    def num_exp_vals(self) -> int: ...

    @property
    def postselection_mask(self) -> list[int]:
        """
        Optional list of uint8 flags, one per detector, marking postselected detectors.
        """

    @postselection_mask.setter
    def postselection_mask(self, arg: Sequence[int], /) -> None: ...

    @property
    def expected_detectors(self) -> list[int]:
        """Optional noiseless reference parities for detectors."""

    @expected_detectors.setter
    def expected_detectors(self, arg: Sequence[int], /) -> None: ...

    @property
    def expected_observables(self) -> list[int]:
        """Optional noiseless reference parities for observables."""

    @expected_observables.setter
    def expected_observables(self, arg: Sequence[int], /) -> None: ...

    @property
    def source_map(self) -> list:
        """Source line mapping parallel to ops (list of list of uint32)."""

    def __len__(self) -> int:
        """Return the number of HIR operations."""

    def __getitem__(self, arg: int, /) -> HeisenbergOp:
        """Return the HIR operation at the given index."""

    def __iter__(self) -> object: ...

    def as_dict(self) -> dict:
        """Return a JSON-friendly dictionary representation."""

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

def trace(circuit: Circuit, postselection_mask: Sequence[int] = [], expected_detectors: Sequence[int] = [], expected_observables: Sequence[int] = [], normalize_syndromes: bool = False) -> HirModule:
    """
    Trace a parsed circuit through the Clifford front-end to produce the Heisenberg IR. Single-qubit rotations within 1e-12 half-turns of a Clifford angle are canonicalized. Optional postselection_mask, expected_detectors, expected_observables, and normalize_syndromes settings are recorded on the returned HirModule for HIR optimization passes and lower().
    """

class HirPass:
    """Abstract base class for HIR optimization passes."""

class PeepholeFusionPass(HirPass):
    """
    Symplectic peephole optimization: cancels and fuses T/T-dag gates, canonicalizes rotations within 1e-12 half-turns, and removes terminal phases consumed by same-axis measurements.
    """

    def __init__(self) -> None: ...

    @property
    def cancellations(self) -> int: ...

    @property
    def fusions(self) -> int: ...

    def __repr__(self) -> str: ...

class PhasePolynomialPass(HirPass):
    """
    Reduce commuting T rotations using fixed constraints from the all-zero input, measurements, and feedback. Run after peephole fusion and before squeezing or scheduling.
    """

    def __init__(self, max_variables: int = 128, *, max_wide_work: int = 50000000, max_wide_terms: int = 200000) -> None: ...

    @property
    def wide_attempts(self) -> int: ...

    @property
    def wide_rewrites(self) -> int: ...

    @property
    def wide_work(self) -> int: ...

    @property
    def wide_budget_exhausted(self) -> bool: ...

    @property
    def blocks_reduced(self) -> int: ...

    @property
    def pauli_pullbacks(self) -> int: ...

    @property
    def input_t_count(self) -> int: ...

    @property
    def output_t_count(self) -> int: ...

    @property
    def applied(self) -> bool: ...

    def __repr__(self) -> str: ...

class RotationSimplificationPass(HirPass):
    """
    Simplify Pauli rotations using outcome-independent stabilizer constraints. Run after PhasePolynomialPass and before squeezing or scheduling.
    """

    def __init__(self, max_region_ops: int = 256, max_region_passes: int = 8) -> None: ...

    @property
    def regions_examined(self) -> int: ...

    @property
    def regions_reduced(self) -> int: ...

    @property
    def regions_capped(self) -> int: ...

    @property
    def rotations_removed(self) -> int: ...

    @property
    def applied(self) -> bool: ...

class StatevectorSqueezePass(HirPass):
    """
    Bidirectional bubble sort: moves measurements leftward and
    non-Clifford gates rightward to minimize peak active width.
    """

    def __init__(self) -> None: ...

class ActiveWidthSchedulePass(HirPass):
    """
    State-aware beam search over the schedule-dependence trace class that
    reduces peak active width, then a dense-work estimate. Opt in by
    adding it after PeepholeFusionPass and StatevectorSqueezePass.
    """

    def __init__(self, noise_transparent: bool = True, beam_width: int = 8, search_budget: float | None = 16.0, sink_neutral_rotations: bool | None = True) -> None: ...

    @property
    def incumbent_peak(self) -> int: ...

    @property
    def result_peak(self) -> int: ...

    @property
    def incumbent_dense_work(self) -> float: ...

    @property
    def result_dense_work(self) -> float: ...

    @property
    def applied(self) -> bool: ...

    @property
    def swept_ops(self) -> int: ...

    @property
    def classification_probes(self) -> int: ...

    def __repr__(self) -> str: ...

class RemoveNoisePass(HirPass):
    """
    Strips all stochastic noise and readout noise ops from the HIR.
    Not included in the default pass list. Used internally by
    compute_reference_syndrome() for noiseless reference shots.
    """

    def __init__(self) -> None: ...

class DropNonUnitaryPass(HirPass):
    """
    Drops non-evolution HIR ops so the remaining program is a unitary skeleton.
    Not included in the default pass list and not semantics-preserving.
    """

    def __init__(self) -> None: ...

def compute_reference_syndrome(hir: HirModule) -> dict:
    """
    Compute noiseless reference syndrome for an HirModule.

    Removes stochastic and readout noise and samples one shot at seed 0.
    Does not check determinism; coherent rotations remain. For coherent
    errors, pass the intended ideal circuit's HIR instead.
    Returns a dict with 'detectors' and 'observables' lists.
    """

class HirPassManager:
    """Runs a sequence of optimization passes over an HirModule."""

    def __init__(self) -> None: ...

    def add(self, hir_pass: HirPass) -> None:
        """Add an optimization pass. Passes run in the order added."""

    def run(self, hir: HirModule) -> None:
        """Run all passes on the HIR module in sequence."""

def default_hir_pass_manager(*, overrides: Sequence[HirPass] = ()) -> HirPassManager:
    """
    Return the default pipeline, replacing selected passes in their original slots.

    Overrides must be instances of distinct default-enabled pass types. The manager
    retains these instances; their statistics remain available after a run.
    """

def active_width_trace(hir: HirModule) -> dict:
    """
    Structural active-width trace of an HIR module, without lowering it to an executable program.

    Returns a dict with 'initial', 'peak', and 'final' width, plus per-op 'widths' (the width after each op) and 'effects' (a lower-case effect name per op).
    """

class Program:
    """A reusable compiled sampling program"""

    @property
    def peak_active_width(self) -> int:
        """Largest active width reached by the compiled program."""

    @property
    def peak_rank(self) -> int:
        """Deprecated alias for peak_active_width."""

    @property
    def num_qubits(self) -> int: ...

    @property
    def num_measurements(self) -> int: ...

    @property
    def num_hidden_measurements(self) -> int: ...

    @property
    def num_detectors(self) -> int: ...

    @property
    def num_observables(self) -> int: ...

    @property
    def num_exp_vals(self) -> int: ...

    @property
    def has_postselection(self) -> bool: ...

    @property
    def num_actions(self) -> int: ...

    @property
    def noise_site_probabilities(self) -> Annotated[NDArray[numpy.float64], dict(order='C')]:
        """
        Per-site total fault probabilities: quantum noise sites followed by readout noise.
        """

    def inspect(self) -> str:
        """
        Deterministic human-readable diagnostic text for the whole lowered CPU program.

        The format is diagnostic output for debugging and tooling, not a stable machine-readable interface.
        """

    def inspect_action(self, action: int) -> str:
        """
        Deterministic human-readable diagnostic text for a single action in the lowered CPU program.

        The format is diagnostic output for debugging and tooling, not a stable machine-readable interface.
        """

    def __repr__(self) -> str: ...

def lower(hir: HirModule, postselection_mask: Sequence[int] | None = None, expected_detectors: Sequence[int] | None = None, expected_observables: Sequence[int] | None = None) -> Program:
    """
    Lower a Heisenberg IR module to an executable sampling program.

    Args:
        hir: The Heisenberg IR module to lower.
        postselection_mask: Optional list of uint8 flags, one per detector.
            Defaults to hir.postselection_mask when None.
        expected_detectors: Optional noiseless reference parities for detectors.
            Defaults to hir.expected_detectors when None.
        expected_observables: Optional noiseless reference parities for observables.
            Defaults to hir.expected_observables when None.
    """

def _prepare_hir_for_lowering(stim_text: str, expected_detectors: Sequence[int] = [], expected_observables: Sequence[int] = [], normalize_syndromes: bool = False, hir_passes: HirPassManager | None = None, postselection_mask: Sequence[int] = []) -> tuple: ...

def compile(stim_text: str, postselection_mask: Sequence[int] = [], expected_detectors: Sequence[int] = [], expected_observables: Sequence[int] = [], normalize_syndromes: bool = False, hir_passes: HirPassManager | None = None) -> Program:
    """
    Compile a quantum circuit string to an executable program.

    Compilation plans optimized HIR and prepares it for Clifft's sampler.

    When normalize_syndromes=True, a noiseless reference shot is
    executed internally to extract expected detector and observable
    parities. Detectors and observables are then XOR-normalized so
    that 0 means 'matches noiseless reference' and 1 means 'error'.
    This does not check determinism; coherent error rotations remain.
    For coherent errors, supply expected parities from the ideal circuit.

    Args:
        stim_text: Circuit in .stim text format.
        postselection_mask: Optional list of uint8 flags, one per detector.
            Detectors where mask[i] != 0 become post-selection checks
            that abort the shot early if their parity is non-zero.
        expected_detectors: Optional noiseless reference parities for detectors.
        expected_observables: Optional noiseless reference parities for observables.
        normalize_syndromes: If True, auto-compute reference parities from a
            noiseless reference shot (mutually exclusive with explicit parities).
        hir_passes: Optional HirPassManager to run on the HIR before lowering.
    """

def _compile_qasm2(qasm_text: str, postselection_mask: Sequence[int] = [], expected_detectors: Sequence[int] = [], expected_observables: Sequence[int] = [], normalize_syndromes: bool = False, hir_passes: HirPassManager | None = None) -> Program:
    """Compile a unitary OpenQASM 2 circuit string to an executable program."""

def sample(program: Program, shots: int, seed: int | None = None, threads: int | Literal['auto'] = 1, thread_layout: tuple[int, int] | None = None, intra_shot_min_active_width: int | None = None, batch_size: int | Literal['auto', 'tune'] = 'auto', *, tuning_budget_seconds: float | None = None) -> clifft.SampleResult:
    """
    Run a compiled program and return a SampleResult.

    Raises ValueError for post-selected programs because fixed-row output
    cannot represent discarded shots. Use sample_survivors() instead.

    If seed is None (default), uses hardware entropy. threads is a positive
    total worker budget or 'auto' to use the implementation-reported hardware
    concurrency; it defaults to 1. Automatic scheduling uses either cross-shot
    or intra-shot workers. thread_layout=(shot_workers, intra_shot_workers)
    overrides that choice and ignores threads; intra-shot counts above 1
    require OpenMP support. intra_shot_min_active_width overrides the
    default threshold of 18 for an explicit layout. batch_size='auto'
    uses the conservative plan policy; 1 forces scalar execution,
    and a positive integer requests a packed lane-capacity limit. Seeded
    results replay within one batching configuration, but individual rows
    may differ between scalar and packed modes or different capacities.

    batch_size='tune' calibrates before running all requested shots. tuning_budget_seconds is a soft calibration deadline, defaulting to 0.25 seconds. Trials are extra work and are excluded from returned rows and counts. The selected configuration and timings are in result.batch_tuning. Timing-based selection need not replay for a fixed seed; pin a numeric batch_size for debugging.

    Returns a SampleResult with .measurements, .detectors, .observables attributes.
    Supports tuple unpacking: m, d, o = clifft.sample(prog, shots)
    """

def sample_k(program: Program, shots: int, k: int, seed: int | None = None, threads: int | Literal['auto'] = 1, thread_layout: tuple[int, int] | None = None, intra_shot_min_active_width: int | None = None, batch_size: int | Literal['auto', 'tune'] = 'auto', *, tuning_budget_seconds: float | None = None) -> clifft.SampleResult:
    """
    Sample with exactly k forced faults per shot (importance sampling).

    Sites are drawn from the exact conditional Poisson-Binomial
    distribution. Results are conditioned on K=k and must be combined
    across strata with P(K=k) weights for correct error rate estimation.
    Raises ValueError for post-selected programs because fixed-row output
    cannot represent discarded shots. Use sample_k_survivors() instead.

    For post-selected circuits, weight numerator and denominator
    separately via sample_k_survivors(): p_fail =
    sum(P(K=k)*errors_k/shots_k) / sum(P(K=k)*passed_k/shots_k).

    Raises ValueError if the k-fault stratum has zero probability mass
    (e.g. k exceeds the number of non-zero-probability sites).

    When all site probabilities are equal, an O(k) Fisher-Yates
    sampler is used automatically. threads is a positive total worker budget
    or 'auto' to use the implementation-reported hardware concurrency;
    it defaults to 1. thread_layout=(shot_workers, intra_shot_workers)
    overrides automatic scheduling. intra_shot_min_active_width overrides
    the default threshold of 18 for an explicit layout. batch_size='auto'
    uses the conservative plan policy; 1 forces scalar execution,
    and a positive integer requests a packed lane-capacity limit.

    batch_size='tune' calibrates before running all requested shots. tuning_budget_seconds is a soft calibration deadline, defaulting to 0.25 seconds. Trials are extra work and are excluded from returned rows and counts. The selected configuration and timings are in result.batch_tuning. Timing-based selection need not replay for a fixed seed; pin a numeric batch_size for debugging.

    Returns a SampleResult with .measurements, .detectors, .observables attributes.
    Supports tuple unpacking: m, d, o = clifft.sample_k(prog, shots, k)
    """

def sample_k_survivors(program: Program, shots: int, k: int, seed: int | None = None, keep_records: bool = False, threads: int | Literal['auto'] = 1, thread_layout: tuple[int, int] | None = None, intra_shot_min_active_width: int | None = None, batch_size: int | Literal['auto', 'tune'] = 'auto', *, tuning_budget_seconds: float | None = None) -> clifft.SampleResult:
    """
    Sample survivors with exactly k forced faults per shot.

    Results are conditioned on K=k. To estimate the overall logical
    error rate across strata, weight numerator and denominator
    separately to account for k-dependent survival probability:
      p_fail = sum(P(K=k)*logical_errors_k/shots_k)
             / sum(P(K=k)*passed_k/shots_k)

    Raises ValueError if the k-fault stratum has zero probability mass.
    threads is a positive total worker budget or 'auto' to use the
    implementation-reported hardware concurrency; it defaults to 1.
    thread_layout=(shot_workers, intra_shot_workers) overrides automatic
    scheduling. intra_shot_min_active_width overrides the default threshold
    of 18 for an explicit layout. batch_size='auto' uses the conservative
    plan policy; 1 forces scalar execution, and a positive integer requests
    a packed lane-capacity limit.

    batch_size='tune' calibrates before running all requested shots. tuning_budget_seconds is a soft calibration deadline, defaulting to 0.25 seconds. Trials are extra work and are excluded from returned rows and counts. The selected configuration and timings are in result.batch_tuning. Timing-based selection need not replay for a fixed seed; pin a numeric batch_size for debugging.

    Returns a SampleResult. Survivor metadata is always populated via
    .total_shots, .passed_shots, .discards, .logical_errors, and
    .observable_ones. Per-shot record arrays
    (.measurements, .detectors, .observables, .exp_vals) are only
    filled when keep_records=True; otherwise they are empty (rows=0).
    """

def sample_survivors(program: Program, shots: int, seed: int | None = None, keep_records: bool = False, threads: int | Literal['auto'] = 1, thread_layout: tuple[int, int] | None = None, intra_shot_min_active_width: int | None = None, batch_size: int | Literal['auto', 'tune'] = 'auto', *, tuning_budget_seconds: float | None = None) -> clifft.SampleResult:
    """
    Sample shots and return results only for surviving (non-discarded) shots.

    If seed is None (default), uses hardware entropy. threads is a positive
    total worker budget or 'auto' to use the implementation-reported hardware
    concurrency; it defaults to 1. thread_layout=(shot_workers,
    intra_shot_workers) overrides automatic scheduling.
    intra_shot_min_active_width overrides the default threshold of 18 for
    an explicit layout. batch_size='auto' uses the conservative plan policy;
    1 forces scalar execution, and a positive integer requests a packed
    lane-capacity limit.

    batch_size='tune' calibrates before running all requested shots. tuning_budget_seconds is a soft calibration deadline, defaulting to 0.25 seconds. Trials are extra work and are excluded from returned rows and counts. The selected configuration and timings are in result.batch_tuning. Timing-based selection need not replay for a fixed seed; pin a numeric batch_size for debugging.

    Returns a SampleResult. Survivor metadata is always populated via
    .total_shots, .passed_shots, .discards, .logical_errors, and
    .observable_ones. Per-shot record arrays
    (.measurements, .detectors, .observables, .exp_vals) are only
    filled when keep_records=True; otherwise they are empty (rows=0).
    """

def get_statevector(program: Program) -> Annotated[NDArray[numpy.complex128], dict(order='C')]:
    """
    Return a dense representative of a compiled pure-unitary program's final state.

    The result is normalized and defined only up to global phase. Relative amplitudes
    and phases are preserved, but the global phase may vary across equivalent source
    circuits, compiler pass configurations, or Clifft versions.
    """

def _basis_probabilities_from_bitmasks(program: Program, basis_masks: Annotated[NDArray[numpy.uint64], dict(shape=(None, None), order='C', writable=False)]) -> Annotated[NDArray[numpy.float64], dict(order='C')]:
    """Internal helper for clifft.basis_probabilities()."""

def _record_probabilities_from_records(program: Program, records: Annotated[NDArray[numpy.uint8], dict(shape=(None, None), order='C', writable=False)]) -> Annotated[NDArray[numpy.float64], dict(order='C')]:
    """
    Internal helper for clifft.record_probabilities(). Returns log-probabilities; the Python wrapper exponentiates to linear unless return_log=True.
    """

def _replay_record(program: Program, forced_records: Sequence[object]) -> dict:
    """
    Private CPU reference for GPU conformance tests. Forces visible then hidden records; log_probability is meaningful only when reachable. Noise, instruments and postselection are unsupported.
    """
