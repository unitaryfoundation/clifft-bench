"""Build-time configuration for the installed Clifft package."""

CPU_BASELINE = "x86-64-v2"
