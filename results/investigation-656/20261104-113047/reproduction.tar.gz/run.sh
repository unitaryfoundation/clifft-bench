#!/usr/bin/env bash
set -euo pipefail
RUN=/home/ubuntu/clifft-bench-ec2-results/d5-repeat-20261104-113047
HARNESS=/home/ubuntu/clifft-bench-656
export PYTHONPATH="$HARNESS/src"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1
finish() {
    code=$?
    trap - EXIT
    printf '{"exit_code":%s,"finished_at":"%s"}\n' "$code" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$RUN/exit-status.json"
    sync
    exit "$code"
}
trap finish EXIT
cd "$HARNESS"
test "$(git rev-parse HEAD)" = d2e711f61b4cad439a5f1752edefc51bb96905f1
test -z "$(git status --porcelain --untracked-files=all)"
mkdir -p "$RUN/.campaign-envs" "$RUN/wheels"
for entry in previous-wheel:0.12.0rc1 current-wheel:0.13.0rc1; do
    name=${entry%%:*}
    version=${entry#*:}
    python3.12 -m venv "$RUN/.campaign-envs/$name"
    py="$RUN/.campaign-envs/$name/bin/python"
    "$py" -m pip install --only-binary=:all: --report "$RUN/$name-install.json" "clifft==$version" 'numpy==2.5.4'
    "$py" -m pip check
done
python3.12 "$RUN/inspect_envs.py" "$RUN"
python3.12 "$RUN/driver.py" "$RUN"
