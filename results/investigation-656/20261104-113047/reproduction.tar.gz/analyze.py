"""Validate the bounded repeat and summarize independent workers, never pooled samples."""
from pathlib import Path
import json
import statistics as st
import tempfile
import sys
from clifft_bench.results import read_result, export_csv

root = Path(sys.argv[1])
progress = json.loads((root/'progress.json').read_text())
assert progress['state'] == 'complete'
assert json.loads((root/'exit-status.json').read_text())['exit_code'] == 0
assert len(progress['records']) == 16
expected = [(b,p,l) for b,order in enumerate(['ABDC','BCAD','CDBA','DACB'],1) for p,l in enumerate(order,1)]
assert [(r['block'],r['order'],r['condition']) for r in progress['records']] == expected
assert len(list((root/'workers').rglob('raw.json'))) == 16
rows=[]
calibrations=[]
peaks=[]
durations=[]
versions={'A':'0.12.0rc1','B':'0.13.0rc1','C':'0.12.0rc1','D':'0.13.0rc1'}
pins={'0.12.0rc1':'847757e2bc8c4f7439b9e92011550fd61719eb85','0.13.0rc1':'69b5869267c1823ded4bc7156c76d9673c350ba5'}
with tempfile.TemporaryDirectory() as tmp:
    for r in progress['records']:
        path=root/r['raw']; doc=read_result(path); c,=doc['cases']; label=r['condition']
        assert c['status']=='success' and c['correctness']['status']=='passed'
        assert c['correctness']['details']['attempted_shots']==8 and c['warmup']['attempted_shots']==1
        assert len(c['samples'])==5
        assert c['setup']['affinity']['available_after']==[0]
        runtime=c['setup']['runtime_metadata']; execution=c['execution']
        assert runtime['address_space_limit_bytes']==12*(1<<30)
        assert execution['threads_effective']==1 and execution['shots_per_call']==20000
        assert execution['options']=={'scheduler':{'beam_width':8,'noise_transparent':True,'search_budget':16.0,'sink_neutral_rotations':True}}
        assert execution['postselection'] is True
        assert c['simulator']['version']==versions[label] and c['simulator']['commit_sha']==pins[versions[label]]
        assert c['simulator']['dependencies']['numpy']=='2.5.4'
        assert doc['runner']['python']=='3.12.3'
        assert doc['runner']['suite_source']=={'commit':'d2e711f61b4cad439a5f1752edefc51bb96905f1','dirty':False}
        assert doc['runner']['cloud']['boot_id']=='d6fd85a0-f272-42a3-8f20-96388d772c7a'
        assert c['workload']['id']=='msc-d5-inject-cultivate-p1e-3'
        assert c['workload']['artifact']['sha256']=='c2b4566917bd9bf27a5705284dac02700ef0dcc7c03c91066670db376d633a6d'
        assert c['workload']['semantics']=={'observable_index':0,'postselect_all_detectors':True}
        for i,s in enumerate(c['samples']):
            assert s['duration_seconds']>=30
            assert s['seed_first']==20270819+i*100000000
            assert s['seed_last']==s['seed_first']+s['api_calls']-1
            assert s['attempted_shots']==s['accepted_shots']+s['discarded_shots']==s['api_calls']*20000
            peaks.append(s['peak_rss_bytes']); durations.append(s['duration_seconds'])
        out=Path(tmp)/'cases.csv'; export_csv(doc,out)
        assert out.read_bytes()==path.with_name('cases.csv').read_bytes()
        rates=[s['throughput_attempted_shots_per_second'] for s in c['samples']]
        median=st.median(rates)
        assert median==r['median_rate']
        rows.append({'block':r['block'],'position':r['order'],'label':label,'raw':r['raw'],'median':median,
                     'rates':rates,'relative_mad_pct':100*st.median(abs(x-median) for x in rates)/median,
                     'range_pct':100*(max(rates)/min(rates)-1),'min':min(rates),'max':max(rates),
                     'batch':execution['batch_size_effective'],'peak_rss_bytes':max(s['peak_rss_bytes'] for s in c['samples'])})
        if label in 'CD':
            cal=runtime['batch_calibration']
            assert cal['policy']=='bounded-v3' and cal['candidates']==[1,32,64,256,1024,2048]
            assert cal['repetitions']==3 and cal['probe_seconds']==1 and cal['budget_seconds']==60
            assert cal['selected_batch_size']==execution['batch_size_effective']
            for candidate in cal['results']:
                for i,s in enumerate(candidate['samples']):
                    assert s['seed_first']==520270819+i*1000000
            calibrations.append({'block':r['block'],'label':label,'selected_batch':cal['selected_batch_size'],
                'candidates':[{'batch':x['batch_size'],'status':x['status'],'rate':x.get('median_attempted_shots_per_second')} for x in cal['results']],
                'seconds':cal['duration_seconds'],'final_rate':median})
        else:
            assert 'batch_calibration' not in runtime and execution['batch_size_effective']==1
blocks=[]
for b in range(1,5):
    v={r['label']:r['median'] for r in rows if r['block']==b}
    blocks.append({'block':b,'direct_pct':100*(v['B']/v['A']-1),'calibrated_pct':100*(v['D']/v['C']-1)})
groups={}
for label in 'ABCD':
    values=[r['median'] for r in rows if r['label']==label]
    groups[label]={'rates':values,'median':st.median(values),'min':min(values),'max':max(values),'spread_pct':100*(max(values)/min(values)-1)}
combined={'direct_pct':100*(groups['B']['median']/groups['A']['median']-1),'calibrated_pct':100*(groups['D']['median']/groups['C']['median']-1)}
validation={'workers':16,'samples':80,'correctness':'all passed','raw_reader':'all passed','csv_regeneration':'all byte-identical',
            'predeclared_order':'exact match','protocol_checks':'identities, workload, scheduler, selection/output semantics, affinity, memory, threads, durations, seeds and aggregate counts passed',
            'calibration_choices':[r['selected_batch'] for r in calibrations],
            'minimum_sample_seconds':min(durations),'maximum_peak_rss_bytes':max(peaks),
            'maximum_within_worker_relative_mad_pct':max(r['relative_mad_pct'] for r in rows),
            'maximum_within_worker_range_pct':max(r['range_pct'] for r in rows)}
(root/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
analysis={'rows':rows,'blocks':blocks,'groups':groups,'combined':combined,'calibrations':calibrations,'validation':validation}
(Path(__file__).parent/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
print(json.dumps({'blocks':blocks,'groups':groups,'combined':combined,'validation':validation},indent=2))
