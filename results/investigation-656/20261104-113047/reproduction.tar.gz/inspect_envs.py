"""Record the exact installed artifacts and shared build settings for this run."""
import hashlib
import json
import os
from pathlib import Path
import urllib.request
import subprocess
import sys
from clifft_bench.system import collect_runner_metadata, require_reference_host
from clifft_bench.config import load_suite

root = Path(sys.argv[1])
harness = Path('/home/ubuntu/clifft-bench-656')
suite = load_suite(harness / 'campaigns/release-v1.toml')
cloud = require_reference_host(harness, suite.run['reference_host'], 12, 0)
metadata = {
    'host': collect_runner_metadata(harness, cloud=cloud),
    'compiler': subprocess.check_output(['g++', '--version'], text=True),
    'lscpu': subprocess.check_output(['lscpu'], text=True),
    'build_settings': {k: os.environ.get(k) for k in ['CC', 'CXX', 'CMAKE_ARGS', 'CMAKE_BUILD_PARALLEL_LEVEL', 'CLIFFT_CPU_BASELINE', 'CLIFFT_INTERPROCEDURAL_OPTIMIZATION', 'CLIFFT_OPENMP']},
    'environments': {},
    'wheels': [],
}
script = '''import hashlib, importlib.metadata as m, json, platform
from pathlib import Path
import clifft, numpy
p=m.distribution('clifft')
files={str(f):hashlib.sha256(Path(p.locate_file(f)).read_bytes()).hexdigest() for f in p.files if str(f).endswith(('.so','METADATA','RECORD'))}
print(json.dumps({'version':m.version('clifft'),'runtime_version':clifft.version(),'python':platform.python_version(),'numpy':numpy.__version__,'cpu_baseline':clifft.CPU_BASELINE,'runtime_isa':clifft.runtime_isa(),'direct_url':json.loads(p.read_text('direct_url.json') or '{}'),'files':files}))'''
for name in ['previous-wheel', 'current-wheel']:
    py = root / '.campaign-envs' / name / 'bin/python'
    data = json.loads(subprocess.check_output([str(py), '-c', script], text=True))
    assert data['python'] == '3.12.3'
    assert data['numpy'] == '2.5.4'
    assert data['version'] == data['runtime_version']
    data['freeze'] = subprocess.check_output([str(py), '-m', 'pip', 'freeze', '--all'], text=True)
    metadata['environments'][name] = data

old_root = Path('/home/ubuntu/clifft-bench-ec2-results/investigation-656-20261104-014655')
for name, version in [('previous-wheel', '0.12.0rc1'), ('current-wheel', '0.13.0rc1')]:
    assert metadata['environments'][name]['version'] == version
    report = json.loads((root / f'{name}-install.json').read_text())
    old_report = json.loads((old_root / f'{name}-install.json').read_text())
    old_hashes = {i['metadata']['name']: i['download_info']['archive_info']['hashes']['sha256'] for i in old_report['install']}
    for item in report['install']:
        package = item['metadata']['name']
        info = item['download_info']
        expected = info['archive_info']['hashes']['sha256']
        assert expected == old_hashes[package], (name, package, 'changed published artifact')
        filename = info['url'].rsplit('/', 1)[1]
        assert filename.endswith('.whl')
        dest = root / 'wheels' / name / filename
        dest.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(info['url'], dest)
        assert hashlib.sha256(dest.read_bytes()).hexdigest() == expected
        metadata['wheels'].append({'environment': name, 'package': package, 'path': str(dest.relative_to(root)), 'url': info['url'], 'sha256': expected})
metadata['prior_boot_id'] = '245a2b00-efd4-4f77-b8d3-e9b0e71f31dc'
metadata['boot_id'] = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert metadata['boot_id'] != metadata['prior_boot_id']
metadata['placement_provenance'] = 'User stopped/restarted the same instance; new boot and address. Independent stop/start placement per benchmark contract; physical host identity is not exposed.'
(root / 'environment.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2), flush=True)
