"""Execute the predeclared d5 repeat through the unchanged benchmark runner."""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import json
import statistics
import sys
import time

from clifft_bench.config import Implementation, load_suite
from clifft_bench.results import read_result, write_json
from clifft_bench.runner import run_suite
from clifft_bench.system import utc_now

PINS = {
    'previous-wheel': '847757e2bc8c4f7439b9e92011550fd61719eb85',
    'current-wheel': '69b5869267c1823ded4bc7156c76d9673c350ba5',
}
D5 = 'msc-d5-inject-cultivate-p1e-3'
CONDITIONS = {
    'A': {'implementation': 'previous-wheel', 'batch': 1},
    'B': {'implementation': 'current-wheel', 'batch': 1},
    'C': {'implementation': 'previous-wheel', 'batch': 'calibrate'},
    'D': {'implementation': 'current-wheel', 'batch': 'calibrate'},
}
ORDER = ['ABDC', 'BCAD', 'CDBA', 'DACB']


def main():
    root = Path(sys.argv[1]).resolve()
    harness = Path('/home/ubuntu/clifft-bench-656')
    suite = load_suite(harness / 'campaigns/release-v1.toml')
    environment = json.loads((root / 'environment.json').read_text())['environments']
    progress = dict(started_at=utc_now(), finished_at=None, state='running',
                    records=[], active=None)
    write_json(root / 'plan.json', {
        'conditions': CONDITIONS, 'blocks': ORDER, 'workload': D5,
        'total_measured_workers': 16, 'fresh_worker_per_entry': True,
        'harness_commit': 'd2e711f61b4cad439a5f1752edefc51bb96905f1',
        'prior_evidence_commit': '3bb234081a62c19b0854d99d554c5a15f4444c37',
        'preparation_seed': 520270819, 'sampling_seed': 20260818,
        'correctness_seed': 20260819, 'sample_seed_first': 20270819,
        'sample_seed_stride': 100000000, 'samples_per_worker': 5,
        'sample_seconds': 30, 'shots_per_call': 20000,
        'stop_rule': 'Complete only these 16 measured workers; no adaptive repeats or root-cause investigation.',
    })
    deadline = time.monotonic() + 75 * 60

    def save():
        write_json(root / 'progress.json', progress)

    save()
    try:
        for block, order in enumerate(ORDER, 1):
            for position, label in enumerate(order, 1):
                if time.monotonic() > deadline:
                    raise TimeoutError('Bounded repeat reached its 75-minute measurement deadline')
                condition = CONDITIONS[label]
                name = condition['implementation']
                identifier = f'd5-block{block}-{position}-{label}-{name}'
                template_variant = 'clifft-previous' if name == 'previous-wheel' else 'clifft-current'
                case = next(c for c in suite.cases if c.workload.id == D5 and c.definition['variant_id'] == template_variant)
                definition = deepcopy(case.definition)
                definition.update(id=identifier, variant_id=name, implementation_id=name)
                definition['execution']['batch_size'] = condition['batch']
                assert definition['shots_per_call'] == 20000
                implementation = deepcopy(case.implementation.definition)
                implementation.update(id=name, version=environment[name]['version'],
                                      display_version=environment[name]['version'], commit_sha=PINS[name])
                case = replace(case, definition=definition, implementation=Implementation(implementation, root))
                run = deepcopy(suite.run)
                run.pop('variants', None)
                run.update(profile_id=identifier, title='Bounded interleaved d5 release repeat',
                           cases=[definition], comparisons=[])
                one = replace(suite, run=run, cases=(case,))
                out = root / 'workers' / f'block-{block}' / f'{position}-{label}'
                progress['active'] = {'worker': identifier, 'started_at': utc_now()}
                save()
                print('START', identifier, flush=True)
                run_suite(one, output_dir=out, cpu=0, require_ec2=True)
                document = read_result(out / 'raw.json')
                result = document['cases'][0]
                if result['status'] != 'success':
                    raise RuntimeError(f"{identifier}: {result['error']}")
                assert len(result['samples']) == 5
                assert result['setup']['affinity']['available_after'] == [0]
                assert result['execution']['threads_effective'] == 1
                assert result['setup']['runtime_metadata']['address_space_limit_bytes'] == 12 * (1 << 30)
                assert result['simulator']['dependencies']['numpy'] == '2.5.4'
                rates = [s['throughput_attempted_shots_per_second'] for s in result['samples']]
                progress['records'].append(dict(condition=label, block=block,
                    order=position, implementation=name, raw=str((out/'raw.json').relative_to(root)),
                    median_rate=statistics.median(rates), sample_rates=rates,
                    selected_batch=result['execution']['batch_size_effective']))
                progress['active'] = None
                save()
                print('FINISHED', identifier, 'median', statistics.median(rates),
                      'batch', result['execution']['batch_size_effective'], flush=True)
        assert len(progress['records']) == 16
        progress['state'] = 'complete'
    except BaseException as error:
        progress['state'] = 'failed'
        progress['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        progress['finished_at'] = utc_now()
        save()


if __name__ == '__main__':
    main()
