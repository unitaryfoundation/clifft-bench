#!/usr/bin/env bash
set -euo pipefail
RUN=/home/ubuntu/clifft-bench-ec2-results/investigation-656-20261104-014655
HARNESS=/home/ubuntu/clifft-bench-656
export PYTHONPATH="$HARNESS/src"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1
export CC=/usr/bin/gcc CXX=/usr/bin/g++ CMAKE_BUILD_PARALLEL_LEVEL=4
export CLIFFT_CPU_BASELINE=x86-64-v2 CLIFFT_INTERPROCEDURAL_OPTIMIZATION=OFF CLIFFT_OPENMP=AUTO
export CMAKE_ARGS=-DCMAKE_BUILD_TYPE=Release
finish() {
    code=$?
    trap - EXIT
    printf '{"exit_code":%s,"finished_at":"%s"}\n' "$code" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$RUN/exit-status.json"
    sync
    exit "$code"
}
trap finish EXIT
cd "$HARNESS"
test "$(git rev-parse HEAD)" = d2e711f61b4cad439a5f1752edefc51bb96905f1
test -z "$(git status --porcelain --untracked-files=all)"
mkdir -p "$RUN/.campaign-envs" "$RUN/wheels" "$RUN/build-cache"
python3.12 -m venv "$RUN/.campaign-envs/build-tools"
TOOLS="$RUN/.campaign-envs/build-tools/bin/python"
"$TOOLS" -m pip install --upgrade pip
"$TOOLS" -m pip install 'numpy==2.5.4' scikit-build-core nanobind setuptools-scm setuptools cmake ninja
"$TOOLS" -m pip freeze --all > "$RUN/build-tools.txt"
for entry in previous-wheel:0.12.0rc1 current-wheel:0.13.0rc1; do
    name=${entry%%:*}
    version=${entry#*:}
    python3.12 -m venv "$RUN/.campaign-envs/$name"
    py="$RUN/.campaign-envs/$name/bin/python"
    "$py" -m pip install --only-binary=:all: --report "$RUN/$name-install.json" "clifft==$version" 'numpy==2.5.4'
    "$py" -m pip check
 done
for entry in parent-source:69b5869267c1823ded4bc7156c76d9673c350ba5 patch-source:6abe2509d57acedbae2b2b497e28379f106194f4; do
    name=${entry%%:*}
    sha=${entry#*:}
    python3.12 -m venv "$RUN/.campaign-envs/$name"
    py="$RUN/.campaign-envs/$name/bin/python"
    "$py" -m pip install -r "$RUN/build-tools.txt"
    "$py" -m pip --cache-dir "$RUN/build-cache/$name" install -v --no-build-isolation --no-deps --report "$RUN/$name-install.json" "clifft @ git+https://github.com/unitaryfoundation/clifft.git@$sha"
    "$py" -m pip check
 done
python3.12 "$RUN/inspect_envs.py" "$RUN"
python3.12 "$RUN/driver.py" "$RUN"
