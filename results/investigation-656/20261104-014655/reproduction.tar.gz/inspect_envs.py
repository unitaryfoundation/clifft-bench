"""Record the exact installed artifacts and shared build settings for this run."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from clifft_bench.system import collect_runner_metadata, require_reference_host
from clifft_bench.config import load_suite

root = Path(sys.argv[1])
harness = Path('/home/ubuntu/clifft-bench-656')
suite = load_suite(harness / 'campaigns/release-v1.toml')
cloud = require_reference_host(harness, suite.run['reference_host'], 12, 0)
metadata = {
    'host': collect_runner_metadata(harness, cloud=cloud),
    'compiler': subprocess.check_output(['g++', '--version'], text=True),
    'lscpu': subprocess.check_output(['lscpu'], text=True),
    'build_settings': {k: os.environ.get(k) for k in ['CC', 'CXX', 'CMAKE_ARGS', 'CMAKE_BUILD_PARALLEL_LEVEL', 'CLIFFT_CPU_BASELINE', 'CLIFFT_INTERPROCEDURAL_OPTIMIZATION', 'CLIFFT_OPENMP']},
    'environments': {},
    'wheels': [],
}
script = '''import hashlib, importlib.metadata as m, json, platform
from pathlib import Path
import clifft, numpy
p=m.distribution('clifft')
files={str(f):hashlib.sha256(Path(p.locate_file(f)).read_bytes()).hexdigest() for f in p.files if str(f).endswith(('.so','METADATA','RECORD'))}
print(json.dumps({'version':m.version('clifft'),'runtime_version':clifft.version(),'python':platform.python_version(),'numpy':numpy.__version__,'cpu_baseline':clifft.CPU_BASELINE,'runtime_isa':clifft.runtime_isa(),'direct_url':json.loads(p.read_text('direct_url.json') or '{}'),'files':files}))'''
for name in ['previous-wheel', 'current-wheel', 'parent-source', 'patch-source']:
    py = root / '.campaign-envs' / name / 'bin/python'
    data = json.loads(subprocess.check_output([str(py), '-c', script], text=True))
    assert data['python'] == '3.12.3'
    assert data['numpy'] == '2.5.4'
    assert data['version'] == data['runtime_version']
    data['freeze'] = subprocess.check_output([str(py), '-m', 'pip', 'freeze', '--all'], text=True)
    metadata['environments'][name] = data
for path in (root / 'build-cache').rglob('clifft*.whl'):
    name = path.relative_to(root / 'build-cache').parts[0]
    dest = root / 'wheels' / name / path.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)
    metadata['wheels'].append({'environment':name, 'path':str(dest.relative_to(root)), 'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
for name, sha in [('parent-source','69b5869267c1823ded4bc7156c76d9673c350ba5'), ('patch-source','6abe2509d57acedbae2b2b497e28379f106194f4')]:
    assert metadata['environments'][name]['direct_url']['vcs_info']['commit_id'] == sha
    assert any(w['environment'] == name for w in metadata['wheels'])
(root / 'environment.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2), flush=True)
