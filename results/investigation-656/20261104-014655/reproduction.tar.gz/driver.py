"""Execute the issue's temporary matrix through the unchanged benchmark runner."""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import json
import statistics
import sys
import time

from clifft_bench.config import Implementation, load_suite
from clifft_bench.results import read_result, write_json
from clifft_bench.runner import run_suite
from clifft_bench.system import utc_now

PINS = {
    'previous-wheel': '847757e2bc8c4f7439b9e92011550fd61719eb85',
    'current-wheel': '69b5869267c1823ded4bc7156c76d9673c350ba5',
    'parent-source': '69b5869267c1823ded4bc7156c76d9673c350ba5',
    'patch-source': '6abe2509d57acedbae2b2b497e28379f106194f4',
}
D3 = 'msc-d3-inject-cultivate-p1e-3'
D5 = 'msc-d5-inject-cultivate-p1e-3'
DRAPER = 'draper-adder-m16-basis-all-observables'


def plan():
    conditions = []
    def add(name, workload, batch, pair, repeat=False):
        conditions.append(dict(name=name, workload=workload, batch=batch, pair=pair, repeat=repeat))
    source = ['parent-source', 'patch-source']
    wheels = ['previous-wheel', 'current-wheel']
    add('patch-draper-b1024', DRAPER, 1024, source, True)
    add('patch-d3-b256', D3, 256, source, True)
    add('patch-d3-b2048', D3, 2048, source, True)
    add('wheel-draper-b1024', DRAPER, 1024, wheels)
    add('rc-wheel-source-draper-b1024', DRAPER, 1024, ['current-wheel', 'parent-source'], True)
    for batch in (32, 256, 1024, 2048):
        add(f'wheel-d3-b{batch}', D3, batch, wheels)
    add('wheel-d3-calibrated', D3, 'calibrate', wheels)
    add('wheel-d5-b1', D5, 1, wheels, True)
    add('wheel-d5-calibrated', D5, 'calibrate', wheels, True)
    return conditions


def summarize(records, condition, block):
    selected = [r for r in records if r['condition'] == condition['name'] and r['block'] == block]
    medians = {name: [r['median_rate'] for r in selected if r['implementation'] == name]
               for name in condition['pair']}
    ratio = statistics.median(medians[condition['pair'][1]]) / statistics.median(medians[condition['pair'][0]])
    spread = max(max(v) / min(v) - 1 for v in medians.values())
    return dict(condition=condition['name'], block=block, medians=medians, ratio=ratio,
                largest_independent_worker_spread=spread,
                batches=[r['selected_batch'] for r in selected])


def main():
    root = Path(sys.argv[1]).resolve()
    harness = Path('/home/ubuntu/clifft-bench-656')
    suite = load_suite(harness / 'campaigns/release-v1.toml')
    environment = json.loads((root / 'environment.json').read_text())['environments']
    conditions = plan()
    progress = dict(started_at=utc_now(), finished_at=None, state='running',
                    conditions=conditions, records=[], summaries=[], active=None)
    write_json(root / 'plan.json', {'conditions': conditions, 'initial_order': 'ABBA',
                                   'repeat_order': 'BAAB', 'repeat_rule': 'Always repeat patch, source/wheel bridge, and d5 history controls; also repeat a >1.1% slowdown or >1.1% independent-worker spread.',
                                   'preparation_seed': 520270819, 'sampling_seed': 20260818,
                                   'sample_seed_first': 20270819, 'sample_seed_stride': 100000000,
                                   'samples_per_worker': 5, 'sample_seconds': 30})
    deadline = time.monotonic() + 6.5 * 3600

    def save():
        write_json(root / 'progress.json', progress)

    def run_block(condition, block, order):
        for position, index in enumerate(order, 1):
            if time.monotonic() > deadline:
                raise TimeoutError('Investigation reached its 6.5-hour measurement deadline')
            name = condition['pair'][index]
            identifier = f"{condition['name']}-{block}-{position:02d}-{name}"
            template_variant = 'clifft-previous' if name == 'previous-wheel' else 'clifft-current'
            case = next(c for c in suite.cases if c.workload.id == condition['workload'] and c.definition['variant_id'] == template_variant)
            definition = deepcopy(case.definition)
            definition.update(id=identifier, variant_id=name, implementation_id=name)
            definition['execution']['batch_size'] = condition['batch']
            implementation = deepcopy(case.implementation.definition)
            implementation.update(id=name, version=environment[name]['version'],
                                  display_version=environment[name]['version'], commit_sha=PINS[name])
            if name.endswith('source'):
                implementation.pop('source_tag', None)
                implementation['build']['compiler_flags'] = ['CLIFFT_CPU_BASELINE=x86-64-v2',
                    'CMAKE_BUILD_TYPE=Release', 'CMAKE_INTERPROCEDURAL_OPTIMIZATION=OFF',
                    'CLIFFT_OPENMP=AUTO', 'CC=/usr/bin/gcc', 'CXX=/usr/bin/g++']
            case = replace(case, definition=definition, implementation=Implementation(implementation, root))
            run = deepcopy(suite.run)
            run.pop('variants', None)
            run.update(profile_id=identifier, title='Reference-host regression investigation',
                       cases=[definition], comparisons=[])
            one = replace(suite, run=run, cases=(case,))
            out = root / 'workers' / condition['name'] / block / f'{position:02d}-{name}'
            progress['active'] = {'worker': identifier, 'started_at': utc_now()}
            save()
            print('START', identifier, flush=True)
            run_suite(one, output_dir=out, cpu=0, require_ec2=True)
            document = read_result(out / 'raw.json')
            result = document['cases'][0]
            if result['status'] != 'success':
                raise RuntimeError(f"{identifier}: {result['error']}")
            assert len(result['samples']) == 5
            assert result['setup']['affinity']['available_after'] == [0]
            assert result['execution']['threads_effective'] == 1
            assert result['setup']['runtime_metadata']['address_space_limit_bytes'] == 12 * (1 << 30)
            assert result['simulator']['dependencies']['numpy'] == '2.5.4'
            rates = [s['throughput_attempted_shots_per_second'] for s in result['samples']]
            progress['records'].append(dict(condition=condition['name'], block=block,
                order=position, implementation=name, raw=str((out/'raw.json').relative_to(root)),
                median_rate=statistics.median(rates), sample_rates=rates,
                selected_batch=result['execution']['batch_size_effective']))
            progress['active'] = None
            save()
            print('FINISHED', identifier, 'median', statistics.median(rates), flush=True)
        summary = summarize(progress['records'], condition, block)
        progress['summaries'].append(summary)
        save()
        print('BLOCK', json.dumps(summary), flush=True)
        return summary

    save()
    try:
        repeat = []
        for condition in conditions:
            summary = run_block(condition, 'abba', (0, 1, 1, 0))
            if condition['repeat'] or summary['ratio'] < 0.989 or summary['largest_independent_worker_spread'] > 0.011:
                repeat.append(condition)
        progress['repeat_conditions'] = [c['name'] for c in repeat]
        save()
        for condition in repeat:
            run_block(condition, 'baab', (1, 0, 0, 1))
        progress['state'] = 'complete'
    except BaseException as error:
        progress['state'] = 'failed'
        progress['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        progress['finished_at'] = utc_now()
        save()


if __name__ == '__main__':
    main()
