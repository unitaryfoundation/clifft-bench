import json
from pathlib import Path
import struct
import sys

pid, address, count = map(int, sys.argv[1:])
with Path(f'/proc/{pid}/pagemap').open('rb') as stream:
    stream.seek(address // 4096 * 8)
    entries = struct.unpack(f'{count}Q', stream.read(count * 8))
print(json.dumps({'pid':pid,'address':hex(address),
                  'pfns':[v & ((1 << 55) - 1) for v in entries],
                  'present':[bool(v >> 63) for v in entries]}))
