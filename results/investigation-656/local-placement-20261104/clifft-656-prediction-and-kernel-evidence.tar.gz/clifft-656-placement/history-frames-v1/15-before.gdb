set pagination off
set confirm off
attach 3983657
break *0x7ffff1deb420
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
disable 1
python
import json,subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
evidence = json.loads(subprocess.check_output(['sudo','-n','python3','/tmp/clifft-656-placement/page_frames.py',str(inferior.pid),str(address),'6'],text=True))
evidence['state'] = hex(int(gdb.parse_and_eval('$rdi')))
evidence['imag'] = hex(int(gdb.parse_and_eval('$r8')))
evidence['rotation'] = hex(int(gdb.parse_and_eval('$rsi')))
evidence['stack'] = hex(int(gdb.parse_and_eval('$rsp')))
assert all(evidence['present'])
Path('/tmp/clifft-656-placement/history-frames-v1/15-before.backing.json').write_text(json.dumps(evidence,indent=2))
end
detach
quit
end
python open('/tmp/clifft-656-placement/history-frames-v1/15-before.ready','w').write('ready')
continue
