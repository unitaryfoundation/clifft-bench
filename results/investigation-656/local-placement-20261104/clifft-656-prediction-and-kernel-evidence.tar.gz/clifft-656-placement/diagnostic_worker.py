"""Reuse the pinned worker; negative durations request a fixed number of API calls."""
import resource
import time

from clifft_bench import worker

original_aggregate = worker.aggregate_sample


def aggregate(prepared, *, min_seconds, **kwargs):
    cpu_start = time.process_time()
    if min_seconds >= 0:
        result = original_aggregate(prepared, min_seconds=min_seconds, **kwargs)
    else:
        calls = int(-min_seconds)
        assert 0 < calls <= kwargs["max_api_calls"]
        start = worker.utc_now()
        setup = worker.begin_sample(prepared, kwargs["seed"])
        totals = worker.Counts(0, 0, 0, 0)
        elapsed = 0.0
        for index in range(calls):
            counts, duration = worker.timed_sample(
                prepared, kwargs["shots_per_call"], kwargs["seed"] + index
            )
            assert not worker.validate_counts(counts, postselect=kwargs["postselect"])
            totals = worker.Counts(
                totals.attempted_shots + counts.attempted_shots,
                totals.accepted_shots + counts.accepted_shots,
                totals.discarded_shots + counts.discarded_shots,
                totals.logical_errors + counts.logical_errors,
            )
            elapsed += duration
        result = {
            "started_at": start,
            "duration_seconds": elapsed,
            "stream_setup_seconds": setup,
            "api_calls": calls,
            **totals.as_dict(),
            "throughput_attempted_shots_per_second": totals.attempted_shots / elapsed,
            "seed_first": kwargs["seed"],
            "seed_last": kwargs["seed"] + calls - 1,
            "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            "diagnostic_fixed_calls": True,
        }
    result["process_cpu_seconds"] = time.process_time() - cpu_start
    return result


worker.aggregate_sample = aggregate
raise SystemExit(worker.main())
