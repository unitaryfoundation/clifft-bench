"""Local diagnostic, not the release harness: fixed work and live-process profiling."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time

ROOT = Path('/tmp/clifft-656-placement')
PREVIOUS = Path('/tmp/clifft-rc-investigation')
BENCH = PREVIOUS / 'bench'
PERF = '/usr/lib/linux-tools/6.8.0-106-generic/perf'
sys.path.insert(0, str(BENCH / 'src'))
from clifft_bench.system import restricted_environment

parser = argparse.ArgumentParser()
parser.add_argument('--name', default='direct-rc1')
parser.add_argument('--version', default='sys013')
parser.add_argument('--workers', type=int, default=8)
parser.add_argument('--history', choices=['direct','calibrate'], default='direct')
parser.add_argument('--no-aslr', action='store_true')
parser.add_argument('--cpu', type=int, default=0)
parser.add_argument('--extra-counters', action='store_true')
parser.add_argument('--hash-seed')
parser.add_argument('--debug-addresses', action='store_true')
parser.add_argument('--only-addresses', action='store_true')
parser.add_argument('--screen-calls', type=int, default=50)
parser.add_argument('--repage', action='store_true')
parser.add_argument('--swap-pages', action='store_true')
args = parser.parse_args()
if args.version == 'sys013':
    extension = PREVIOUS / 'sys013/lib/python3.12/site-packages/clifft/_clifft_core.abi3.so'
    assert hashlib.sha256(extension.read_bytes()).hexdigest() == '75b71fd3f1f6c2a22141f3f965bd02958f0a68a2d4d08be7b406e006ee2207b4'
if args.debug_addresses or args.swap_pages or args.repage:
    assert args.version == 'sys013', 'Debugger offsets are specific to the pinned RC1 wheel'
OUT = ROOT / args.name
OUT.mkdir()
raw = json.loads((BENCH / 'results/release-v1/0.13.0rc1-20261103-183623/raw.json').read_text())
case = next(c for c in raw['cases'] if c['case_id'].startswith('msc-d5') and c['variant_id'] == ('clifft-previous' if args.version == 'sys012' else 'clifft-current'))
output = (OUT / 'results.jsonl').open('w')
processes = []


def save(event):
    output.write(json.dumps(event) + '\n')
    output.flush()


class Worker:
    def __init__(self, index):
        self.index = index
        env = restricted_environment()
        env['PYTHONPATH'] = str(BENCH / 'src')
        if args.hash_seed is not None:
            env['PYTHONHASHSEED'] = args.hash_seed
        command = [str(PREVIOUS / args.version / 'bin/python'), str(ROOT / 'diagnostic_worker.py')]
        if args.no_aslr:
            command = ['setarch', 'x86_64', '-R', *command]
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=(OUT / f'{index}.stderr').open('w'), text=True, env=env)
        processes.append(self.process)
        self.request({'command':'prepare','adapter':'clifft',
            'artifact_path':str(BENCH / 'workloads/circuits' / Path(case['workload']['artifact']['path']).name),
            'workload':case['workload'],
            'execution':{'batch_size':1 if args.history=='direct' else 'calibrate', 'options':case['execution']['options']},
            'shots_per_call':20000,'seed':520270819,'sampling_seed':20260818,
            'expected_version':case['simulator']['version'],'expected_commit':case['simulator']['commit_sha'],
            'source_url':case['simulator']['source_url'],'dependency_distributions':['numpy'],
            'logical_cpu':args.cpu,'memory_limit_gib':12,'timeout_seconds':180})
        self.request({'command':'warmup','shots':1,'seed':20260818})
        result = self.request({'command':'correctness','shots':8,'seed':20260819})
        assert not result['contract_errors']
        (OUT / f'{index}.maps').write_text(Path(f'/proc/{self.process.pid}/maps').read_text())

    def request(self, request, phase='setup'):
        self.process.stdin.write(json.dumps(request) + '\n')
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError(f'worker {self.index} exited: {(OUT / f"{self.index}.stderr").read_text()}')
        result = json.loads(line)
        assert result['ok'], result
        save({'worker':self.index,'pid':self.process.pid,'phase':phase,'request':request,'result':result})
        return result

    def sample(self, phase, calls=50):
        return self.request({'command':'sample','shots_per_call':20000,'min_seconds':-calls,
                             'seed':20270819,'max_api_calls':100000000},phase)

    def profile(self, phase, events=None, record=False):
        prefix = OUT / f'{self.index}-{phase}'
        command = [PERF, 'record' if record else 'stat', '-p', str(self.process.pid)]
        if record:
            command += ['-e','cycles:u','-F','997','-o',str(prefix)+'.data']
        else:
            command += ['-x',',','-e',events,'-o',str(prefix)+'.csv']
        with open(str(prefix)+'.perf.log','w') as log:
            profiler = subprocess.Popen(command, stdout=log, stderr=log)
            try:
                time.sleep(0.15)
                assert profiler.poll() is None, Path(str(prefix)+'.perf.log').read_text()
                result = self.sample(phase, 100)
            finally:
                profiler.send_signal(signal.SIGINT)
                profiler.wait(timeout=10)
        print(phase,self.index,round(result['throughput_attempted_shots_per_second']),
              'cpu/wall',round(result['process_cpu_seconds']/result['duration_seconds'],4),flush=True)
        if record:
            with open(str(prefix)+'.report','w') as report:
                subprocess.run([PERF,'report','--stdio','--no-children','--sort','dso,symbol',
                                '-i',str(prefix)+'.data'],stdout=report,stderr=subprocess.STDOUT,check=True)

    def addresses(self, repage=False, swap=False, suffix=''):
        lines = Path(f'/proc/{self.process.pid}/maps').read_text().splitlines()
        mapping = next(line.split() for line in lines if '_clifft_core.abi3.so' in line and 'r-xp' in line)
        # perf reports file offsets for this stripped ELF; its executable segment's
        # virtual address is file offset + 0x1000. Resolve using the live mapping.
        pc = int(mapping[0].split('-')[0],16) + 0x1c5420 - int(mapping[2],16)
        ready = OUT / f'{self.index}{suffix}.gdb-ready'
        ready.unlink(missing_ok=True)
        commands = OUT / f'{self.index}{suffix}.gdb'
        intervention = '''disable 1
python
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
print('REPAGE address', hex(address))
gdb.execute('call (int)madvise((void*)%d, 24576, 4)' % address)
inferior.write_memory(address, saved)
print('REPAGE restored', bytes(inferior.read_memory(address, 24576)) == saved)
end
''' if repage else ''
        if swap:
            slots = OUT / f'{self.index}-swap-slots.json'
            intervention = f'''disable 1
python
import json, subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
def frames():
    return subprocess.check_output(['sudo','-n','python3',{str(ROOT/'page_frames.py')!r},str(inferior.pid),str(address),'6'],text=True).strip()
def call(expression):
    value=int(gdb.parse_and_eval(expression))
    assert value != -1 and value != (1<<64)-1, expression
    return value
print('SWAP before', frames())
slots=Path({str(slots)!r})
if not slots.exists():
    parked=call('(long)mmap((void*)0,24576,3,34,-1,0)')
    temporary=call('(long)mmap((void*)0,24576,3,34,-1,0)')
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address,parked))==parked
    assert call('(long)mmap((void*)%d,24576,3,50,-1,0)' % address)==address
    slots.write_text(json.dumps({{'parked':parked,'temporary':temporary}}))
else:
    locations=json.loads(slots.read_text())
    parked,temporary=locations['parked'],locations['temporary']
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address,temporary))==temporary
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (parked,address))==address
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (temporary,parked))==parked
inferior.write_memory(address,saved)
assert bytes(inferior.read_memory(address,24576))==saved
print('SWAP after', frames())
print('SWAP restored bytes',len(saved))
end
'''
        commands.write_text(f'''set pagination off
set confirm off
attach {self.process.pid}
break *{pc:#x}
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
{intervention}
detach
quit
end
python open({str(ready)!r},'w').write('ready')
continue
''')
        with (OUT / f'{self.index}{suffix}.gdb-log').open('w') as log:
            debugger = subprocess.Popen(['gdb','-q','-nx','-batch','-x',str(commands)],stdout=log,stderr=subprocess.STDOUT)
            until = time.monotonic()+15
            while not ready.exists() and debugger.poll() is None and time.monotonic()<until:
                time.sleep(0.05)
            if not ready.exists():
                debugger.terminate();debugger.wait(timeout=5)
                raise RuntimeError(f'debugger did not attach to worker {self.index}')
            self.sample('debug-addresses',1)
            debugger.wait(timeout=15)
            assert debugger.returncode == 0, f'debugger failed for worker {self.index}'
        print('debugged',self.index,(OUT/f'{self.index}{suffix}.gdb-log').read_text()[-1300:],flush=True)

