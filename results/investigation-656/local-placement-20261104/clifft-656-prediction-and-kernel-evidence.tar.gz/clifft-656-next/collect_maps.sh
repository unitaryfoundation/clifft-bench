#!/usr/bin/env bash
set -euo pipefail
root=/tmp/clifft-656-next
workspace=/home/exedev/.codex/worktrees/bd34/clifft-codex
for variant in parent candidate; do
    if [ "$variant" = parent ]; then
        git -C "$workspace" show 7e83ec2823bf99c54aa1b90c54a092641c10c4b0:src/clifft/sampling/kernels_avx512.cc > "$root/source/src/clifft/sampling/kernels_avx512.cc"
    else
        cp "$workspace/src/clifft/sampling/kernels_avx512.cc" "$root/source/src/clifft/sampling/kernels_avx512.cc"
    fi
    for alignment in 16 32 64; do
        cmake -S "$root/source" -B "$root/build-$alignment" \
            -DCMAKE_MODULE_LINKER_FLAGS="-fuse-ld=lld -Wl,-Map=$root/$variant-$alignment.map"
        cmake --build "$root/build-$alignment" --parallel 2
        cmake --install "$root/build-$alignment" --prefix "$root/mapcheck/$variant-$alignment"
        python3 "$root/verify_map_build.py" "$variant" "$alignment"
    done
done
