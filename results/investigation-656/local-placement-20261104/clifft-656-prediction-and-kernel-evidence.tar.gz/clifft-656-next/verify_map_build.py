from pathlib import Path
import hashlib,shutil,sys
root=Path('/tmp/clifft-656-next');variant,alignment=sys.argv[1:]
target=root/f'{variant}-{alignment}/clifft/_clifft_core.abi3.so'
check=root/f'mapcheck/{variant}-{alignment}/clifft/_clifft_core.abi3.so'
expected=next(line.split()[0] for line in (root/'build-sha256.txt').read_text().splitlines() if line.split()[1]==str(target))
assert hashlib.sha256(check.read_bytes()).hexdigest()==expected,(variant,alignment,'map build differs')
if hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
    assert variant=='parent' and alignment=='16'
    # GNU objcopy rewrote non-code ELF content during an inspection. Recover
    # the exact original artifact before any timing, verifying its saved hash.
    shutil.copy2(target,root/'parent-16-after-objcopy.so')
    shutil.copy2(check,target)
assert hashlib.sha256(target.read_bytes()).hexdigest()==expected
print('verified exact original build',variant,alignment)
