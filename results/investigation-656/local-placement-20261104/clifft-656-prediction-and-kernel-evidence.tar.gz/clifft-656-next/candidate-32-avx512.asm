
/tmp/clifft-656-next/candidate-32/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001c7b60 <PyInit__clifft_core@@Base+0x179500>:
  1c7b60:	55                   	push   rbp
  1c7b61:	41 57                	push   r15
  1c7b63:	41 56                	push   r14
  1c7b65:	41 55                	push   r13
  1c7b67:	41 54                	push   r12
  1c7b69:	53                   	push   rbx
  1c7b6a:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1c7b6f:	c5 e1 57 05 a9 5d e4 	vxorpd xmm0,xmm3,XMMWORD PTR [rip+0xffffffffffe45da9]        # d920 <PyInit__clifft_core@@Base-0x40d40>
  1c7b76:	ff 
  1c7b77:	c5 f8 92 c9          	kmovw  k1,ecx
  1c7b7b:	62 f1 e7 09 10 d8    	vmovsd xmm3{k1},xmm3,xmm0
  1c7b81:	83 fa 03             	cmp    edx,0x3
  1c7b84:	0f 84 35 02 00 00    	je     1c7dbf <PyInit__clifft_core@@Base+0x17975f>
  1c7b8a:	83 fa 02             	cmp    edx,0x2
  1c7b8d:	0f 84 b0 00 00 00    	je     1c7c43 <PyInit__clifft_core@@Base+0x1795e3>
  1c7b93:	83 fa 01             	cmp    edx,0x1
  1c7b96:	0f 85 e2 04 00 00    	jne    1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7b9c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c7ba0:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c7ba4:	62 f2 fd 48 19 46 06 	vbroadcastsd zmm0,QWORD PTR [rsi+0x30]
  1c7bab:	c5 e1 57 0d 6d 5d e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe45d6d]        # d920 <PyInit__clifft_core@@Base-0x40d40>
  1c7bb2:	ff 
  1c7bb3:	31 d2                	xor    edx,edx
  1c7bb5:	4c 8d 05 04 ba e5 ff 	lea    r8,[rip+0xffffffffffe5ba04]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7bbc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  1c7bc0:	62 f1 fd 48 28 14 d0 	vmovapd zmm2,ZMMWORD PTR [rax+rdx*8]
  1c7bc7:	62 f1 fd 48 28 24 d1 	vmovapd zmm4,ZMMWORD PTR [rcx+rdx*8]
  1c7bce:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c7bd2:	4d 89 ca             	mov    r10,r9
  1c7bd5:	49 21 d2             	and    r10,rdx
  1c7bd8:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c7bdd:	41 83 e2 01          	and    r10d,0x1
  1c7be1:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c7be6:	c5 f9 28 eb          	vmovapd xmm5,xmm3
  1c7bea:	62 f1 d7 09 10 e9    	vmovsd xmm5{k1},xmm5,xmm1
  1c7bf0:	41 83 e1 07          	and    r9d,0x7
  1c7bf4:	41 c1 e1 06          	shl    r9d,0x6
  1c7bf8:	62 f2 fd 48 19 ed    	vbroadcastsd zmm5,xmm5
  1c7bfe:	62 91 d5 48 59 2c 01 	vmulpd zmm5,zmm5,ZMMWORD PTR [r9+r8*1]
  1c7c05:	62 f1 ed 48 59 f0    	vmulpd zmm6,zmm2,zmm0
  1c7c0b:	62 f2 d5 48 b8 f4    	vfmadd231pd zmm6,zmm5,zmm4
  1c7c11:	62 f1 dd 48 59 e0    	vmulpd zmm4,zmm4,zmm0
  1c7c17:	62 f2 d5 48 bc e2    	vfnmadd231pd zmm4,zmm5,zmm2
  1c7c1d:	62 f1 fd 48 29 34 d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm6
  1c7c24:	62 f1 fd 48 29 24 d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm4
  1c7c2b:	48 83 c2 08          	add    rdx,0x8
  1c7c2f:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c7c34:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c7c39:	4d 85 c9             	test   r9,r9
  1c7c3c:	74 82                	je     1c7bc0 <PyInit__clifft_core@@Base+0x179560>
  1c7c3e:	e9 3b 04 00 00       	jmp    1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7c43:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c7c48:	48 8b 46 08          	mov    rax,QWORD PTR [rsi+0x8]
  1c7c4c:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1c7c50:	48 8b 56 18          	mov    rdx,QWORD PTR [rsi+0x18]
  1c7c54:	4c 8d 04 12          	lea    r8,[rdx+rdx*1]
  1c7c58:	41 89 c3             	mov    r11d,eax
  1c7c5b:	41 83 e3 07          	and    r11d,0x7
  1c7c5f:	41 c1 e3 06          	shl    r11d,0x6
  1c7c63:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c7c67:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c7c6b:	4c 8b 4f 18          	mov    r9,QWORD PTR [rdi+0x18]
  1c7c6f:	4c 8b 57 20          	mov    r10,QWORD PTR [rdi+0x20]
  1c7c73:	8b 7f 54             	mov    edi,DWORD PTR [rdi+0x54]
  1c7c76:	48 8d 1d 43 bb e5 ff 	lea    rbx,[rip+0xffffffffffe5bb43]        # 237c0 <PyInit__clifft_core@@Base-0x2aea0>
  1c7c7d:	62 d1 fd 48 28 0c 1b 	vmovapd zmm1,ZMMWORD PTR [r11+rbx*1]
  1c7c84:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c7c8b:	0f 84 12 02 00 00    	je     1c7ea3 <PyInit__clifft_core@@Base+0x179843>
  1c7c91:	48 85 d2             	test   rdx,rdx
  1c7c94:	0f 84 e4 03 00 00    	je     1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7c9a:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7c9e:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7ca3:	89 ce                	mov    esi,ecx
  1c7ca5:	83 e6 07             	and    esi,0x7
  1c7ca8:	c1 e6 06             	shl    esi,0x6
  1c7cab:	4c 8d 1d 0e b9 e5 ff 	lea    r11,[rip+0xffffffffffe5b90e]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7cb2:	62 b1 fd 48 28 1c 1e 	vmovapd zmm3,ZMMWORD PTR [rsi+r11*1]
  1c7cb9:	48 89 d6             	mov    rsi,rdx
  1c7cbc:	48 c1 e6 04          	shl    rsi,0x4
  1c7cc0:	45 31 db             	xor    r11d,r11d
  1c7cc3:	48 bb f8 ff ff ff ff 	movabs rbx,0x1ffffffffffffff8
  1c7cca:	ff ff 1f 
  1c7ccd:	4d 89 ce             	mov    r14,r9
  1c7cd0:	4d 89 d7             	mov    r15,r10
  1c7cd3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c7cda:	84 00 00 00 00 00 
  1c7ce0:	45 31 e4             	xor    r12d,r12d
  1c7ce3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c7cea:	84 00 00 00 00 00 
  1c7cf0:	4b 8d 2c 23          	lea    rbp,[r11+r12*1]
  1c7cf4:	49 89 ed             	mov    r13,rbp
  1c7cf7:	49 31 c5             	xor    r13,rax
  1c7cfa:	49 21 dd             	and    r13,rbx
  1c7cfd:	62 91 fd 48 28 2c e6 	vmovapd zmm5,ZMMWORD PTR [r14+r12*8]
  1c7d04:	62 91 fd 48 28 34 e7 	vmovapd zmm6,ZMMWORD PTR [r15+r12*8]
  1c7d0b:	62 92 f5 48 16 3c e9 	vpermpd zmm7,zmm1,ZMMWORD PTR [r9+r13*8]
  1c7d12:	62 12 f5 48 16 04 ea 	vpermpd zmm8,zmm1,ZMMWORD PTR [r10+r13*8]
  1c7d19:	48 21 cd             	and    rbp,rcx
  1c7d1c:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c7d21:	83 e5 01             	and    ebp,0x1
  1c7d24:	c5 f8 92 cd          	kmovw  k1,ebp
  1c7d28:	c5 79 28 cc          	vmovapd xmm9,xmm4
  1c7d2c:	62 71 b7 09 10 c8    	vmovsd xmm9{k1},xmm9,xmm0
  1c7d32:	62 52 fd 48 19 c9    	vbroadcastsd zmm9,xmm9
  1c7d38:	62 71 b5 48 59 cb    	vmulpd zmm9,zmm9,zmm3
  1c7d3e:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c7d44:	62 52 b5 48 b8 d0    	vfmadd231pd zmm10,zmm9,zmm8
  1c7d4a:	62 71 cd 48 59 da    	vmulpd zmm11,zmm6,zmm2
  1c7d50:	62 72 b5 48 bc df    	vfnmadd231pd zmm11,zmm9,zmm7
  1c7d56:	62 f1 c5 48 59 fa    	vmulpd zmm7,zmm7,zmm2
  1c7d5c:	62 f2 b5 48 b8 fe    	vfmadd231pd zmm7,zmm9,zmm6
  1c7d62:	62 f1 bd 48 59 f2    	vmulpd zmm6,zmm8,zmm2
  1c7d68:	62 f2 b5 48 bc f5    	vfnmadd231pd zmm6,zmm9,zmm5
  1c7d6e:	62 11 fd 48 29 14 e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm10
  1c7d75:	62 11 fd 48 29 1c e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm11
  1c7d7c:	62 f2 f5 48 16 ef    	vpermpd zmm5,zmm1,zmm7
  1c7d82:	62 91 fd 48 29 2c e9 	vmovapd ZMMWORD PTR [r9+r13*8],zmm5
  1c7d89:	62 f2 f5 48 16 ee    	vpermpd zmm5,zmm1,zmm6
  1c7d8f:	62 91 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [r10+r13*8],zmm5
  1c7d96:	49 83 c4 08          	add    r12,0x8
  1c7d9a:	49 39 d4             	cmp    r12,rdx
  1c7d9d:	0f 82 4d ff ff ff    	jb     1c7cf0 <PyInit__clifft_core@@Base+0x179690>
  1c7da3:	4d 01 c3             	add    r11,r8
  1c7da6:	c4 42 c3 f7 e3       	shrx   r12,r11,rdi
  1c7dab:	49 01 f7             	add    r15,rsi
  1c7dae:	49 01 f6             	add    r14,rsi
  1c7db1:	4d 85 e4             	test   r12,r12
  1c7db4:	0f 84 26 ff ff ff    	je     1c7ce0 <PyInit__clifft_core@@Base+0x179680>
  1c7dba:	e9 bf 02 00 00       	jmp    1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7dbf:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c7dc4:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1c7dc7:	83 e2 07             	and    edx,0x7
  1c7dca:	c1 e2 06             	shl    edx,0x6
  1c7dcd:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c7dd1:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c7dd5:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c7dd9:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c7ddd:	4c 8d 05 dc b9 e5 ff 	lea    r8,[rip+0xffffffffffe5b9dc]        # 237c0 <PyInit__clifft_core@@Base-0x2aea0>
  1c7de4:	62 b1 fd 48 28 0c 02 	vmovapd zmm1,ZMMWORD PTR [rdx+r8*1]
  1c7deb:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c7df2:	0f 84 d7 01 00 00    	je     1c7fcf <PyInit__clifft_core@@Base+0x17996f>
  1c7df8:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7dfc:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7e01:	31 d2                	xor    edx,edx
  1c7e03:	4c 8d 05 b6 b7 e5 ff 	lea    r8,[rip+0xffffffffffe5b7b6]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7e0a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1c7e10:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c7e17:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c7e1e:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c7e24:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c7e2a:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c7e2e:	4d 89 ca             	mov    r10,r9
  1c7e31:	49 21 d2             	and    r10,rdx
  1c7e34:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c7e39:	41 83 e2 01          	and    r10d,0x1
  1c7e3d:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c7e42:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c7e46:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c7e4c:	41 83 e1 07          	and    r9d,0x7
  1c7e50:	41 c1 e1 06          	shl    r9d,0x6
  1c7e54:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c7e5a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c7e61:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c7e67:	62 f2 bd 48 b8 df    	vfmadd231pd zmm3,zmm8,zmm7
  1c7e6d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c7e73:	62 f2 bd 48 bc ee    	vfnmadd231pd zmm5,zmm8,zmm6
  1c7e79:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c7e80:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c7e87:	48 83 c2 08          	add    rdx,0x8
  1c7e8b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c7e90:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c7e95:	4d 85 c9             	test   r9,r9
  1c7e98:	0f 84 72 ff ff ff    	je     1c7e10 <PyInit__clifft_core@@Base+0x1797b0>
  1c7e9e:	e9 db 01 00 00       	jmp    1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7ea3:	48 85 d2             	test   rdx,rdx
  1c7ea6:	0f 84 d2 01 00 00    	je     1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7eac:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c7eb1:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7eb5:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7eba:	89 ce                	mov    esi,ecx
  1c7ebc:	83 e6 07             	and    esi,0x7
  1c7ebf:	c1 e6 06             	shl    esi,0x6
  1c7ec2:	4c 8d 1d f7 b6 e5 ff 	lea    r11,[rip+0xffffffffffe5b6f7]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7ec9:	62 b1 fd 48 28 1c 1e 	vmovapd zmm3,ZMMWORD PTR [rsi+r11*1]
  1c7ed0:	48 89 d6             	mov    rsi,rdx
  1c7ed3:	48 c1 e6 04          	shl    rsi,0x4
  1c7ed7:	45 31 db             	xor    r11d,r11d
  1c7eda:	48 bb f8 ff ff ff ff 	movabs rbx,0x1ffffffffffffff8
  1c7ee1:	ff ff 1f 
  1c7ee4:	4d 89 ce             	mov    r14,r9
  1c7ee7:	4d 89 d7             	mov    r15,r10
  1c7eea:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1c7ef0:	45 31 e4             	xor    r12d,r12d
  1c7ef3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c7efa:	84 00 00 00 00 00 
  1c7f00:	4b 8d 2c 23          	lea    rbp,[r11+r12*1]
  1c7f04:	49 89 ed             	mov    r13,rbp
  1c7f07:	49 31 c5             	xor    r13,rax
  1c7f0a:	49 21 dd             	and    r13,rbx
  1c7f0d:	62 91 fd 48 28 2c e6 	vmovapd zmm5,ZMMWORD PTR [r14+r12*8]
  1c7f14:	62 91 fd 48 28 34 e7 	vmovapd zmm6,ZMMWORD PTR [r15+r12*8]
  1c7f1b:	62 92 f5 48 16 3c e9 	vpermpd zmm7,zmm1,ZMMWORD PTR [r9+r13*8]
  1c7f22:	62 12 f5 48 16 04 ea 	vpermpd zmm8,zmm1,ZMMWORD PTR [r10+r13*8]
  1c7f29:	48 21 cd             	and    rbp,rcx
  1c7f2c:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c7f31:	83 e5 01             	and    ebp,0x1
  1c7f34:	c5 f8 92 cd          	kmovw  k1,ebp
  1c7f38:	c5 79 28 cc          	vmovapd xmm9,xmm4
  1c7f3c:	62 71 b7 09 10 c8    	vmovsd xmm9{k1},xmm9,xmm0
  1c7f42:	62 52 fd 48 19 c9    	vbroadcastsd zmm9,xmm9
  1c7f48:	62 71 b5 48 59 cb    	vmulpd zmm9,zmm9,zmm3
  1c7f4e:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c7f54:	62 72 b5 48 bc d7    	vfnmadd231pd zmm10,zmm9,zmm7
  1c7f5a:	62 71 cd 48 59 da    	vmulpd zmm11,zmm6,zmm2
  1c7f60:	62 52 b5 48 bc d8    	vfnmadd231pd zmm11,zmm9,zmm8
  1c7f66:	62 f1 c5 48 59 fa    	vmulpd zmm7,zmm7,zmm2
  1c7f6c:	62 f2 b5 48 b8 fd    	vfmadd231pd zmm7,zmm9,zmm5
  1c7f72:	62 f1 bd 48 59 ea    	vmulpd zmm5,zmm8,zmm2
  1c7f78:	62 f2 b5 48 b8 ee    	vfmadd231pd zmm5,zmm9,zmm6
  1c7f7e:	62 11 fd 48 29 14 e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm10
  1c7f85:	62 11 fd 48 29 1c e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm11
  1c7f8c:	62 f2 f5 48 16 f7    	vpermpd zmm6,zmm1,zmm7
  1c7f92:	62 91 fd 48 29 34 e9 	vmovapd ZMMWORD PTR [r9+r13*8],zmm6
  1c7f99:	62 f2 f5 48 16 ed    	vpermpd zmm5,zmm1,zmm5
  1c7f9f:	62 91 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [r10+r13*8],zmm5
  1c7fa6:	49 83 c4 08          	add    r12,0x8
  1c7faa:	49 39 d4             	cmp    r12,rdx
  1c7fad:	0f 82 4d ff ff ff    	jb     1c7f00 <PyInit__clifft_core@@Base+0x1798a0>
  1c7fb3:	4d 01 c3             	add    r11,r8
  1c7fb6:	c4 42 c3 f7 e3       	shrx   r12,r11,rdi
  1c7fbb:	49 01 f7             	add    r15,rsi
  1c7fbe:	49 01 f6             	add    r14,rsi
  1c7fc1:	4d 85 e4             	test   r12,r12
  1c7fc4:	0f 84 26 ff ff ff    	je     1c7ef0 <PyInit__clifft_core@@Base+0x179890>
  1c7fca:	e9 af 00 00 00       	jmp    1c807e <PyInit__clifft_core@@Base+0x179a1e>
  1c7fcf:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c7fd4:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7fd8:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7fdd:	31 d2                	xor    edx,edx
  1c7fdf:	4c 8d 05 da b5 e5 ff 	lea    r8,[rip+0xffffffffffe5b5da]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7fe6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c7fed:	00 00 00 
  1c7ff0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c7ff7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c7ffe:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c8004:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c800a:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c800e:	4d 89 ca             	mov    r10,r9
  1c8011:	49 21 d2             	and    r10,rdx
  1c8014:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c8019:	41 83 e2 01          	and    r10d,0x1
  1c801d:	41 83 e1 07          	and    r9d,0x7
  1c8021:	41 c1 e1 06          	shl    r9d,0x6
  1c8025:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c802a:	c5 79 28 c0          	vmovapd xmm8,xmm0
  1c802e:	62 71 bf 09 10 c4    	vmovsd xmm8{k1},xmm8,xmm4
  1c8034:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c803a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c8041:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c8047:	62 f2 bd 48 b8 de    	vfmadd231pd zmm3,zmm8,zmm6
  1c804d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c8053:	62 f2 bd 48 b8 ef    	vfmadd231pd zmm5,zmm8,zmm7
  1c8059:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c8060:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c8067:	48 83 c2 08          	add    rdx,0x8
  1c806b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c8070:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c8075:	4d 85 c9             	test   r9,r9
  1c8078:	0f 84 72 ff ff ff    	je     1c7ff0 <PyInit__clifft_core@@Base+0x179990>
  1c807e:	5b                   	pop    rbx
  1c807f:	41 5c                	pop    r12
  1c8081:	41 5d                	pop    r13
  1c8083:	41 5e                	pop    r14
  1c8085:	41 5f                	pop    r15
  1c8087:	5d                   	pop    rbp
  1c8088:	c5 f8 77             	vzeroupper
  1c808b:	c3                   	ret
