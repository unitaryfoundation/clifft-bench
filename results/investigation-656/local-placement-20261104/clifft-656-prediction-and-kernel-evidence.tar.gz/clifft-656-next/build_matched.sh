#!/usr/bin/env bash
set -euo pipefail
root=/tmp/clifft-656-next
workspace=/home/exedev/.codex/worktrees/bd34/clifft-codex
compiler=/tmp/clifft-620-toolchain/clang/bin
export PATH="$compiler:$PATH"
uv venv --python 3.12 "$root/build-env"
uv pip install --python "$root/build-env/bin/python" nanobind==2.11.0 numpy==2.5.4 pytest qiskit qiskit-aer stim
mkdir "$root/source" "$root/omp-include"
cp /usr/lib/llvm-18/lib/clang/18/include/omp.h "$root/omp-include/"
git -C "$workspace" archive 7e83ec2823bf99c54aa1b90c54a092641c10c4b0 | tar -x -C "$root/source"
git -C "$workspace" diff --binary > "$root/candidate.patch"
for alignment in 16 32 64; do
    build="$root/build-$alignment"
    cmake -S "$root/source" -B "$build" -G Ninja \
        -DCMAKE_CXX_COMPILER="$compiler/clang++" \
        -DCMAKE_BUILD_TYPE=Release -DCLIFFT_CPU_BASELINE=x86-64-v2 \
        -DCMAKE_INTERPROCEDURAL_OPTIMIZATION=ON -DCLIFFT_OPENMP=ON \
        -DOpenMP_CXX_FLAGS="-fopenmp=libomp -I$root/omp-include" \
        -DOpenMP_CXX_LIB_NAMES=omp \
        -DOpenMP_omp_LIBRARY=/usr/lib/llvm-18/lib/libomp.so \
        -DCMAKE_CXX_FLAGS="-falign-functions=$alignment" \
        -DCMAKE_SHARED_LINKER_FLAGS=-fuse-ld=lld \
        -DCMAKE_MODULE_LINKER_FLAGS=-fuse-ld=lld \
        -DSKBUILD=ON -DSKBUILD_PROJECT_VERSION_FULL=0.13.0.dev0+7e83ec2 \
        -DPython_EXECUTABLE="$root/build-env/bin/python" \
        -DFETCHCONTENT_SOURCE_DIR_FAST_FLOAT=/tmp/clifft-pr652-review-build/_deps/fast_float-src
    cmake --build "$build" --parallel 6
    cmake --install "$build" --prefix "$root/parent-$alignment"
done
cp "$workspace/src/clifft/sampling/kernels_avx512.cc" "$root/source/src/clifft/sampling/kernels_avx512.cc"
for alignment in 16 32 64; do
    cmake --build "$root/build-$alignment" --parallel 6
    cmake --install "$root/build-$alignment" --prefix "$root/candidate-$alignment"
done
sha256sum "$root"/{parent,candidate}-{16,32,64}/clifft/_clifft_core.abi3.so > "$root/build-sha256.txt"
