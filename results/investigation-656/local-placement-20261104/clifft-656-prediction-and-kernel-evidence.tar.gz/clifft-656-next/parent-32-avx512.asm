
/tmp/clifft-656-next/parent-32/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001c7b60 <PyInit__clifft_core@@Base+0x179500>:
  1c7b60:	55                   	push   rbp
  1c7b61:	41 57                	push   r15
  1c7b63:	41 56                	push   r14
  1c7b65:	41 55                	push   r13
  1c7b67:	41 54                	push   r12
  1c7b69:	53                   	push   rbx
  1c7b6a:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1c7b6f:	c5 e1 57 05 a9 5d e4 	vxorpd xmm0,xmm3,XMMWORD PTR [rip+0xffffffffffe45da9]        # d920 <PyInit__clifft_core@@Base-0x40d40>
  1c7b76:	ff 
  1c7b77:	c5 f8 92 c9          	kmovw  k1,ecx
  1c7b7b:	62 f1 e7 09 10 d8    	vmovsd xmm3{k1},xmm3,xmm0
  1c7b81:	83 fa 03             	cmp    edx,0x3
  1c7b84:	0f 84 28 02 00 00    	je     1c7db2 <PyInit__clifft_core@@Base+0x179752>
  1c7b8a:	83 fa 02             	cmp    edx,0x2
  1c7b8d:	0f 84 b0 00 00 00    	je     1c7c43 <PyInit__clifft_core@@Base+0x1795e3>
  1c7b93:	83 fa 01             	cmp    edx,0x1
  1c7b96:	0f 85 d2 04 00 00    	jne    1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7b9c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c7ba0:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c7ba4:	62 f2 fd 48 19 46 06 	vbroadcastsd zmm0,QWORD PTR [rsi+0x30]
  1c7bab:	c5 e1 57 0d 6d 5d e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe45d6d]        # d920 <PyInit__clifft_core@@Base-0x40d40>
  1c7bb2:	ff 
  1c7bb3:	31 d2                	xor    edx,edx
  1c7bb5:	4c 8d 05 04 ba e5 ff 	lea    r8,[rip+0xffffffffffe5ba04]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7bbc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  1c7bc0:	62 f1 fd 48 28 14 d0 	vmovapd zmm2,ZMMWORD PTR [rax+rdx*8]
  1c7bc7:	62 f1 fd 48 28 24 d1 	vmovapd zmm4,ZMMWORD PTR [rcx+rdx*8]
  1c7bce:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c7bd2:	4d 89 ca             	mov    r10,r9
  1c7bd5:	49 21 d2             	and    r10,rdx
  1c7bd8:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c7bdd:	41 83 e2 01          	and    r10d,0x1
  1c7be1:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c7be6:	c5 f9 28 eb          	vmovapd xmm5,xmm3
  1c7bea:	62 f1 d7 09 10 e9    	vmovsd xmm5{k1},xmm5,xmm1
  1c7bf0:	41 83 e1 07          	and    r9d,0x7
  1c7bf4:	41 c1 e1 06          	shl    r9d,0x6
  1c7bf8:	62 f2 fd 48 19 ed    	vbroadcastsd zmm5,xmm5
  1c7bfe:	62 91 d5 48 59 2c 01 	vmulpd zmm5,zmm5,ZMMWORD PTR [r9+r8*1]
  1c7c05:	62 f1 ed 48 59 f0    	vmulpd zmm6,zmm2,zmm0
  1c7c0b:	62 f2 d5 48 b8 f4    	vfmadd231pd zmm6,zmm5,zmm4
  1c7c11:	62 f1 dd 48 59 e0    	vmulpd zmm4,zmm4,zmm0
  1c7c17:	62 f2 d5 48 bc e2    	vfnmadd231pd zmm4,zmm5,zmm2
  1c7c1d:	62 f1 fd 48 29 34 d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm6
  1c7c24:	62 f1 fd 48 29 24 d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm4
  1c7c2b:	48 83 c2 08          	add    rdx,0x8
  1c7c2f:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c7c34:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c7c39:	4d 85 c9             	test   r9,r9
  1c7c3c:	74 82                	je     1c7bc0 <PyInit__clifft_core@@Base+0x179560>
  1c7c3e:	e9 2b 04 00 00       	jmp    1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7c43:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c7c48:	48 8b 46 18          	mov    rax,QWORD PTR [rsi+0x18]
  1c7c4c:	44 8b 4e 08          	mov    r9d,DWORD PTR [rsi+0x8]
  1c7c50:	41 83 e1 07          	and    r9d,0x7
  1c7c54:	41 c1 e1 06          	shl    r9d,0x6
  1c7c58:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c7c5c:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c7c60:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
  1c7c64:	4c 8b 47 20          	mov    r8,QWORD PTR [rdi+0x20]
  1c7c68:	4c 8d 15 51 bb e5 ff 	lea    r10,[rip+0xffffffffffe5bb51]        # 237c0 <PyInit__clifft_core@@Base-0x2aea0>
  1c7c6f:	62 91 fd 48 28 0c 11 	vmovapd zmm1,ZMMWORD PTR [r9+r10*1]
  1c7c76:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c7c7d:	0f 84 10 02 00 00    	je     1c7e93 <PyInit__clifft_core@@Base+0x179833>
  1c7c83:	48 85 c0             	test   rax,rax
  1c7c86:	0f 84 e2 03 00 00    	je     1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7c8c:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7c90:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7c95:	49 89 c1             	mov    r9,rax
  1c7c98:	49 c1 e1 04          	shl    r9,0x4
  1c7c9c:	45 31 d2             	xor    r10d,r10d
  1c7c9f:	49 bb f8 ff ff ff ff 	movabs r11,0x1ffffffffffffff8
  1c7ca6:	ff ff 1f 
  1c7ca9:	48 8d 1d 10 b9 e5 ff 	lea    rbx,[rip+0xffffffffffe5b910]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7cb0:	49 89 d6             	mov    r14,rdx
  1c7cb3:	4d 89 c7             	mov    r15,r8
  1c7cb6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c7cbd:	00 00 00 
  1c7cc0:	45 31 e4             	xor    r12d,r12d
  1c7cc3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c7cca:	84 00 00 00 00 00 
  1c7cd0:	4b 8d 2c 22          	lea    rbp,[r10+r12*1]
  1c7cd4:	4c 8b 6e 08          	mov    r13,QWORD PTR [rsi+0x8]
  1c7cd8:	49 31 ed             	xor    r13,rbp
  1c7cdb:	4d 21 dd             	and    r13,r11
  1c7cde:	62 91 fd 48 28 1c e6 	vmovapd zmm3,ZMMWORD PTR [r14+r12*8]
  1c7ce5:	62 91 fd 48 28 2c e7 	vmovapd zmm5,ZMMWORD PTR [r15+r12*8]
  1c7cec:	62 b2 f5 48 16 34 ea 	vpermpd zmm6,zmm1,ZMMWORD PTR [rdx+r13*8]
  1c7cf3:	62 92 f5 48 16 3c e8 	vpermpd zmm7,zmm1,ZMMWORD PTR [r8+r13*8]
  1c7cfa:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1c7cfe:	48 21 cd             	and    rbp,rcx
  1c7d01:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c7d06:	83 e5 01             	and    ebp,0x1
  1c7d09:	c5 f8 92 cd          	kmovw  k1,ebp
  1c7d0d:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c7d11:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c7d17:	83 e1 07             	and    ecx,0x7
  1c7d1a:	c1 e1 06             	shl    ecx,0x6
  1c7d1d:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c7d23:	62 71 bd 48 59 04 19 	vmulpd zmm8,zmm8,ZMMWORD PTR [rcx+rbx*1]
  1c7d2a:	62 71 e5 48 59 ca    	vmulpd zmm9,zmm3,zmm2
  1c7d30:	62 72 bd 48 b8 cf    	vfmadd231pd zmm9,zmm8,zmm7
  1c7d36:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c7d3c:	62 72 bd 48 bc d6    	vfnmadd231pd zmm10,zmm8,zmm6
  1c7d42:	62 f1 cd 48 59 f2    	vmulpd zmm6,zmm6,zmm2
  1c7d48:	62 f2 bd 48 b8 f5    	vfmadd231pd zmm6,zmm8,zmm5
  1c7d4e:	62 f1 c5 48 59 ea    	vmulpd zmm5,zmm7,zmm2
  1c7d54:	62 f2 bd 48 bc eb    	vfnmadd231pd zmm5,zmm8,zmm3
  1c7d5a:	62 11 fd 48 29 0c e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm9
  1c7d61:	62 11 fd 48 29 14 e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm10
  1c7d68:	62 f2 f5 48 16 de    	vpermpd zmm3,zmm1,zmm6
  1c7d6e:	62 b1 fd 48 29 1c ea 	vmovapd ZMMWORD PTR [rdx+r13*8],zmm3
  1c7d75:	62 f2 f5 48 16 dd    	vpermpd zmm3,zmm1,zmm5
  1c7d7b:	62 91 fd 48 29 1c e8 	vmovapd ZMMWORD PTR [r8+r13*8],zmm3
  1c7d82:	49 83 c4 08          	add    r12,0x8
  1c7d86:	49 39 c4             	cmp    r12,rax
  1c7d89:	0f 82 41 ff ff ff    	jb     1c7cd0 <PyInit__clifft_core@@Base+0x179670>
  1c7d8f:	49 01 c2             	add    r10,rax
  1c7d92:	49 01 c2             	add    r10,rax
  1c7d95:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c7d99:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c7d9e:	4d 01 cf             	add    r15,r9
  1c7da1:	4d 01 ce             	add    r14,r9
  1c7da4:	48 85 c9             	test   rcx,rcx
  1c7da7:	0f 84 13 ff ff ff    	je     1c7cc0 <PyInit__clifft_core@@Base+0x179660>
  1c7dad:	e9 bc 02 00 00       	jmp    1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7db2:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c7db7:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1c7dba:	83 e2 07             	and    edx,0x7
  1c7dbd:	c1 e2 06             	shl    edx,0x6
  1c7dc0:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c7dc4:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c7dc8:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c7dcc:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c7dd0:	4c 8d 05 e9 b9 e5 ff 	lea    r8,[rip+0xffffffffffe5b9e9]        # 237c0 <PyInit__clifft_core@@Base-0x2aea0>
  1c7dd7:	62 b1 fd 48 28 0c 02 	vmovapd zmm1,ZMMWORD PTR [rdx+r8*1]
  1c7dde:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c7de5:	0f 84 d8 01 00 00    	je     1c7fc3 <PyInit__clifft_core@@Base+0x179963>
  1c7deb:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7def:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7df4:	31 d2                	xor    edx,edx
  1c7df6:	4c 8d 05 c3 b7 e5 ff 	lea    r8,[rip+0xffffffffffe5b7c3]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7dfd:	0f 1f 00             	nop    DWORD PTR [rax]
  1c7e00:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c7e07:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c7e0e:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c7e14:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c7e1a:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c7e1e:	4d 89 ca             	mov    r10,r9
  1c7e21:	49 21 d2             	and    r10,rdx
  1c7e24:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c7e29:	41 83 e2 01          	and    r10d,0x1
  1c7e2d:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c7e32:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c7e36:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c7e3c:	41 83 e1 07          	and    r9d,0x7
  1c7e40:	41 c1 e1 06          	shl    r9d,0x6
  1c7e44:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c7e4a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c7e51:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c7e57:	62 f2 bd 48 b8 df    	vfmadd231pd zmm3,zmm8,zmm7
  1c7e5d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c7e63:	62 f2 bd 48 bc ee    	vfnmadd231pd zmm5,zmm8,zmm6
  1c7e69:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c7e70:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c7e77:	48 83 c2 08          	add    rdx,0x8
  1c7e7b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c7e80:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c7e85:	4d 85 c9             	test   r9,r9
  1c7e88:	0f 84 72 ff ff ff    	je     1c7e00 <PyInit__clifft_core@@Base+0x1797a0>
  1c7e8e:	e9 db 01 00 00       	jmp    1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7e93:	48 85 c0             	test   rax,rax
  1c7e96:	0f 84 d2 01 00 00    	je     1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7e9c:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c7ea1:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7ea5:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7eaa:	49 89 c1             	mov    r9,rax
  1c7ead:	49 c1 e1 04          	shl    r9,0x4
  1c7eb1:	45 31 d2             	xor    r10d,r10d
  1c7eb4:	49 bb f8 ff ff ff ff 	movabs r11,0x1ffffffffffffff8
  1c7ebb:	ff ff 1f 
  1c7ebe:	48 8d 1d fb b6 e5 ff 	lea    rbx,[rip+0xffffffffffe5b6fb]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7ec5:	49 89 d6             	mov    r14,rdx
  1c7ec8:	4d 89 c7             	mov    r15,r8
  1c7ecb:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
  1c7ed0:	45 31 e4             	xor    r12d,r12d
  1c7ed3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c7eda:	84 00 00 00 00 00 
  1c7ee0:	4b 8d 0c 22          	lea    rcx,[r10+r12*1]
  1c7ee4:	4c 8b 6e 08          	mov    r13,QWORD PTR [rsi+0x8]
  1c7ee8:	49 31 cd             	xor    r13,rcx
  1c7eeb:	4d 21 dd             	and    r13,r11
  1c7eee:	62 91 fd 48 28 1c e6 	vmovapd zmm3,ZMMWORD PTR [r14+r12*8]
  1c7ef5:	62 91 fd 48 28 2c e7 	vmovapd zmm5,ZMMWORD PTR [r15+r12*8]
  1c7efc:	62 b2 f5 48 16 34 ea 	vpermpd zmm6,zmm1,ZMMWORD PTR [rdx+r13*8]
  1c7f03:	62 92 f5 48 16 3c e8 	vpermpd zmm7,zmm1,ZMMWORD PTR [r8+r13*8]
  1c7f0a:	48 8b 6e 10          	mov    rbp,QWORD PTR [rsi+0x10]
  1c7f0e:	48 21 e9             	and    rcx,rbp
  1c7f11:	f3 48 0f b8 c9       	popcnt rcx,rcx
  1c7f16:	83 e1 01             	and    ecx,0x1
  1c7f19:	c5 f8 92 c9          	kmovw  k1,ecx
  1c7f1d:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c7f21:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c7f27:	83 e5 07             	and    ebp,0x7
  1c7f2a:	c1 e5 06             	shl    ebp,0x6
  1c7f2d:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c7f33:	62 71 bd 48 59 44 1d 	vmulpd zmm8,zmm8,ZMMWORD PTR [rbp+rbx*1+0x0]
  1c7f3a:	00 
  1c7f3b:	62 71 e5 48 59 ca    	vmulpd zmm9,zmm3,zmm2
  1c7f41:	62 72 bd 48 bc ce    	vfnmadd231pd zmm9,zmm8,zmm6
  1c7f47:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c7f4d:	62 72 bd 48 bc d7    	vfnmadd231pd zmm10,zmm8,zmm7
  1c7f53:	62 f1 cd 48 59 f2    	vmulpd zmm6,zmm6,zmm2
  1c7f59:	62 f2 bd 48 b8 f3    	vfmadd231pd zmm6,zmm8,zmm3
  1c7f5f:	62 f1 c5 48 59 da    	vmulpd zmm3,zmm7,zmm2
  1c7f65:	62 f2 bd 48 b8 dd    	vfmadd231pd zmm3,zmm8,zmm5
  1c7f6b:	62 11 fd 48 29 0c e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm9
  1c7f72:	62 11 fd 48 29 14 e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm10
  1c7f79:	62 f2 f5 48 16 ee    	vpermpd zmm5,zmm1,zmm6
  1c7f7f:	62 b1 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [rdx+r13*8],zmm5
  1c7f86:	62 f2 f5 48 16 db    	vpermpd zmm3,zmm1,zmm3
  1c7f8c:	62 91 fd 48 29 1c e8 	vmovapd ZMMWORD PTR [r8+r13*8],zmm3
  1c7f93:	49 83 c4 08          	add    r12,0x8
  1c7f97:	49 39 c4             	cmp    r12,rax
  1c7f9a:	0f 82 40 ff ff ff    	jb     1c7ee0 <PyInit__clifft_core@@Base+0x179880>
  1c7fa0:	49 01 c2             	add    r10,rax
  1c7fa3:	49 01 c2             	add    r10,rax
  1c7fa6:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c7faa:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c7faf:	4d 01 cf             	add    r15,r9
  1c7fb2:	4d 01 ce             	add    r14,r9
  1c7fb5:	48 85 c9             	test   rcx,rcx
  1c7fb8:	0f 84 12 ff ff ff    	je     1c7ed0 <PyInit__clifft_core@@Base+0x179870>
  1c7fbe:	e9 ab 00 00 00       	jmp    1c806e <PyInit__clifft_core@@Base+0x179a0e>
  1c7fc3:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c7fc8:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c7fcc:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c7fd1:	31 d2                	xor    edx,edx
  1c7fd3:	4c 8d 05 e6 b5 e5 ff 	lea    r8,[rip+0xffffffffffe5b5e6]        # 235c0 <PyInit__clifft_core@@Base-0x2b0a0>
  1c7fda:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1c7fe0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c7fe7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c7fee:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c7ff4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c7ffa:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c7ffe:	4d 89 ca             	mov    r10,r9
  1c8001:	49 21 d2             	and    r10,rdx
  1c8004:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c8009:	41 83 e2 01          	and    r10d,0x1
  1c800d:	41 83 e1 07          	and    r9d,0x7
  1c8011:	41 c1 e1 06          	shl    r9d,0x6
  1c8015:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c801a:	c5 79 28 c0          	vmovapd xmm8,xmm0
  1c801e:	62 71 bf 09 10 c4    	vmovsd xmm8{k1},xmm8,xmm4
  1c8024:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c802a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c8031:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c8037:	62 f2 bd 48 b8 de    	vfmadd231pd zmm3,zmm8,zmm6
  1c803d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c8043:	62 f2 bd 48 b8 ef    	vfmadd231pd zmm5,zmm8,zmm7
  1c8049:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c8050:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c8057:	48 83 c2 08          	add    rdx,0x8
  1c805b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c8060:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c8065:	4d 85 c9             	test   r9,r9
  1c8068:	0f 84 72 ff ff ff    	je     1c7fe0 <PyInit__clifft_core@@Base+0x179980>
  1c806e:	5b                   	pop    rbx
  1c806f:	41 5c                	pop    r12
  1c8071:	41 5d                	pop    r13
  1c8073:	41 5e                	pop    r14
  1c8075:	41 5f                	pop    r15
  1c8077:	5d                   	pop    rbp
  1c8078:	c5 f8 77             	vzeroupper
  1c807b:	c3                   	ret
