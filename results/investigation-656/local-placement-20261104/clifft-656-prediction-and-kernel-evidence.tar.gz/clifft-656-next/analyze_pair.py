import csv,json,statistics
from pathlib import Path
root=Path('/tmp/clifft-656-placement/pair-prediction-v1')
events=[json.loads(s) for s in (root/'results.jsonl').read_text().splitlines()]
rows=[]
for event in events:
    request=event.get('request',{})
    if request.get('command')!='sample':continue
    calls=-request['min_seconds'];result=event['result']
    expected=(2000000,287417,1712583,0) if calls==100 else (20000,2852,17148,0)
    assert tuple(result[k] for k in ['attempted_shots','accepted_shots','discarded_shots','logical_errors'])==expected
    if calls!=100:continue
    path=root/f"{event['worker']}-{event['phase']}.csv"
    counters={}
    for line in path.read_text().splitlines():
        columns=line.split(',')
        if len(columns)>5 and columns[2] in ['cycles:u','instructions:u']:
            assert float(columns[4])==100.0,columns
            counters[columns[2].split(':')[0]]=int(columns[0])
    assert len(counters)==2
    rows.append(dict(worker=event['worker'],phase=event['phase'],configuration=event['phase'][-1] if event['worker']<4 else 'control',**counters,seconds=result['duration_seconds'],cpu_seconds=result['process_cpu_seconds'],shots=result['attempted_shots'],throughput=result['throughput_attempted_shots_per_second']))
assert len(rows)==40
verified=[e for e in events if e.get('action')=='verified-measurement'];assert len(verified)==32
for event in verified:
    assert event['before']['pfns']==event['after']['pfns']
    assert all(event['before']['present']) and all(event['after']['present'])
configs=[e for e in events if e.get('action')=='configuration'];assert len(configs)==40
for event in configs:
    e=event['evidence'];assert e['after']==e['expected'] and e['restored_bytes']==24576
    assert len(set(e['after']))==6
    c=e['configuration'];a,b,d,f=[p%16 for p in e['after'][:4]]
    if c=='N':assert len(set([a,b,d,f]))==4
    elif c=='R':assert a==b and len(set([a,d,f]))==3
    elif c=='I':assert d==f and len(set([a,b,d]))==3
    elif c=='X':assert a==d and len(set([a,b,f]))==3
summaries=[]
for worker in range(4):
    med={}
    for conf in 'NRIX':
        values=[r['cycles'] for r in rows if r['worker']==worker and r['configuration']==conf]
        assert len(values)==2
        med[conf]=statistics.median(values)
    summaries.append(dict(worker=worker,cycles=med,percent={c:100*(med[c]/med['N']-1) for c in 'RIX'}))
percent={c:statistics.median(s['percent'][c] for s in summaries) for c in 'RIX'}
positive={c:sum(s['percent'][c]>0 for s in summaries) for c in 'RIX'}
x_abs=statistics.median(abs(s['percent']['X']) for s in summaries)
primary=all(percent[c]>=3 and positive[c]>=3 for c in 'RI')
negative=x_abs<=2 and percent['X']<min(percent['R'],percent['I'])
summary=dict(workers=summaries,median_percent=percent,positive_workers=positive,median_absolute_X_percent=x_abs,primary_rule_passed=primary,negative_control_passed=negative,profiled_passes=len(rows),measured_attempted_shots=sum(r['shots'] for r in rows),control_cycles=[r['cycles'] for r in rows if r['worker']==4],instruction_min=min(r['instructions'] for r in rows),instruction_max=max(r['instructions'] for r in rows))
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (root/'samples.csv').open('w') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,indent=2))
