#!/usr/bin/env bash
set -euo pipefail
cmake --build /tmp/clifft-rc-investigation/test-build --parallel 6
ctest --test-dir /tmp/clifft-rc-investigation/test-build --output-on-failure --parallel 6
uv run --frozen --only-group dev pre-commit run --all-files --show-diff-on-failure
