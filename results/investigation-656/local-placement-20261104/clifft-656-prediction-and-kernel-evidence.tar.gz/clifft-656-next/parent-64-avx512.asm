
/tmp/clifft-656-next/parent-64/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001cf840 <PyInit__clifft_core@@Base+0x181180>:
  1cf840:	55                   	push   rbp
  1cf841:	41 57                	push   r15
  1cf843:	41 56                	push   r14
  1cf845:	41 55                	push   r13
  1cf847:	41 54                	push   r12
  1cf849:	53                   	push   rbx
  1cf84a:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1cf84f:	c5 e1 57 05 c9 e0 e3 	vxorpd xmm0,xmm3,XMMWORD PTR [rip+0xffffffffffe3e0c9]        # d920 <PyInit__clifft_core@@Base-0x40da0>
  1cf856:	ff 
  1cf857:	c5 f8 92 c9          	kmovw  k1,ecx
  1cf85b:	62 f1 e7 09 10 d8    	vmovsd xmm3{k1},xmm3,xmm0
  1cf861:	83 fa 03             	cmp    edx,0x3
  1cf864:	0f 84 28 02 00 00    	je     1cfa92 <PyInit__clifft_core@@Base+0x1813d2>
  1cf86a:	83 fa 02             	cmp    edx,0x2
  1cf86d:	0f 84 b0 00 00 00    	je     1cf923 <PyInit__clifft_core@@Base+0x181263>
  1cf873:	83 fa 01             	cmp    edx,0x1
  1cf876:	0f 85 d2 04 00 00    	jne    1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cf87c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1cf880:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1cf884:	62 f2 fd 48 19 46 06 	vbroadcastsd zmm0,QWORD PTR [rsi+0x30]
  1cf88b:	c5 e1 57 0d 8d e0 e3 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe3e08d]        # d920 <PyInit__clifft_core@@Base-0x40da0>
  1cf892:	ff 
  1cf893:	31 d2                	xor    edx,edx
  1cf895:	4c 8d 05 24 3d e5 ff 	lea    r8,[rip+0xffffffffffe53d24]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cf89c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  1cf8a0:	62 f1 fd 48 28 14 d0 	vmovapd zmm2,ZMMWORD PTR [rax+rdx*8]
  1cf8a7:	62 f1 fd 48 28 24 d1 	vmovapd zmm4,ZMMWORD PTR [rcx+rdx*8]
  1cf8ae:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cf8b2:	4d 89 ca             	mov    r10,r9
  1cf8b5:	49 21 d2             	and    r10,rdx
  1cf8b8:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cf8bd:	41 83 e2 01          	and    r10d,0x1
  1cf8c1:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1cf8c6:	c5 f9 28 eb          	vmovapd xmm5,xmm3
  1cf8ca:	62 f1 d7 09 10 e9    	vmovsd xmm5{k1},xmm5,xmm1
  1cf8d0:	41 83 e1 07          	and    r9d,0x7
  1cf8d4:	41 c1 e1 06          	shl    r9d,0x6
  1cf8d8:	62 f2 fd 48 19 ed    	vbroadcastsd zmm5,xmm5
  1cf8de:	62 91 d5 48 59 2c 01 	vmulpd zmm5,zmm5,ZMMWORD PTR [r9+r8*1]
  1cf8e5:	62 f1 ed 48 59 f0    	vmulpd zmm6,zmm2,zmm0
  1cf8eb:	62 f2 d5 48 b8 f4    	vfmadd231pd zmm6,zmm5,zmm4
  1cf8f1:	62 f1 dd 48 59 e0    	vmulpd zmm4,zmm4,zmm0
  1cf8f7:	62 f2 d5 48 bc e2    	vfnmadd231pd zmm4,zmm5,zmm2
  1cf8fd:	62 f1 fd 48 29 34 d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm6
  1cf904:	62 f1 fd 48 29 24 d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm4
  1cf90b:	48 83 c2 08          	add    rdx,0x8
  1cf90f:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cf914:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cf919:	4d 85 c9             	test   r9,r9
  1cf91c:	74 82                	je     1cf8a0 <PyInit__clifft_core@@Base+0x1811e0>
  1cf91e:	e9 2b 04 00 00       	jmp    1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cf923:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1cf928:	48 8b 46 18          	mov    rax,QWORD PTR [rsi+0x18]
  1cf92c:	44 8b 4e 08          	mov    r9d,DWORD PTR [rsi+0x8]
  1cf930:	41 83 e1 07          	and    r9d,0x7
  1cf934:	41 c1 e1 06          	shl    r9d,0x6
  1cf938:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1cf93c:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1cf940:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
  1cf944:	4c 8b 47 20          	mov    r8,QWORD PTR [rdi+0x20]
  1cf948:	4c 8d 15 71 3e e5 ff 	lea    r10,[rip+0xffffffffffe53e71]        # 237c0 <PyInit__clifft_core@@Base-0x2af00>
  1cf94f:	62 91 fd 48 28 0c 11 	vmovapd zmm1,ZMMWORD PTR [r9+r10*1]
  1cf956:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1cf95d:	0f 84 10 02 00 00    	je     1cfb73 <PyInit__clifft_core@@Base+0x1814b3>
  1cf963:	48 85 c0             	test   rax,rax
  1cf966:	0f 84 e2 03 00 00    	je     1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cf96c:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cf970:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cf975:	49 89 c1             	mov    r9,rax
  1cf978:	49 c1 e1 04          	shl    r9,0x4
  1cf97c:	45 31 d2             	xor    r10d,r10d
  1cf97f:	49 bb f8 ff ff ff ff 	movabs r11,0x1ffffffffffffff8
  1cf986:	ff ff 1f 
  1cf989:	48 8d 1d 30 3c e5 ff 	lea    rbx,[rip+0xffffffffffe53c30]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cf990:	49 89 d6             	mov    r14,rdx
  1cf993:	4d 89 c7             	mov    r15,r8
  1cf996:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1cf99d:	00 00 00 
  1cf9a0:	45 31 e4             	xor    r12d,r12d
  1cf9a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cf9aa:	84 00 00 00 00 00 
  1cf9b0:	4b 8d 2c 22          	lea    rbp,[r10+r12*1]
  1cf9b4:	4c 8b 6e 08          	mov    r13,QWORD PTR [rsi+0x8]
  1cf9b8:	49 31 ed             	xor    r13,rbp
  1cf9bb:	4d 21 dd             	and    r13,r11
  1cf9be:	62 91 fd 48 28 1c e6 	vmovapd zmm3,ZMMWORD PTR [r14+r12*8]
  1cf9c5:	62 91 fd 48 28 2c e7 	vmovapd zmm5,ZMMWORD PTR [r15+r12*8]
  1cf9cc:	62 b2 f5 48 16 34 ea 	vpermpd zmm6,zmm1,ZMMWORD PTR [rdx+r13*8]
  1cf9d3:	62 92 f5 48 16 3c e8 	vpermpd zmm7,zmm1,ZMMWORD PTR [r8+r13*8]
  1cf9da:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1cf9de:	48 21 cd             	and    rbp,rcx
  1cf9e1:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1cf9e6:	83 e5 01             	and    ebp,0x1
  1cf9e9:	c5 f8 92 cd          	kmovw  k1,ebp
  1cf9ed:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1cf9f1:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1cf9f7:	83 e1 07             	and    ecx,0x7
  1cf9fa:	c1 e1 06             	shl    ecx,0x6
  1cf9fd:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1cfa03:	62 71 bd 48 59 04 19 	vmulpd zmm8,zmm8,ZMMWORD PTR [rcx+rbx*1]
  1cfa0a:	62 71 e5 48 59 ca    	vmulpd zmm9,zmm3,zmm2
  1cfa10:	62 72 bd 48 b8 cf    	vfmadd231pd zmm9,zmm8,zmm7
  1cfa16:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1cfa1c:	62 72 bd 48 bc d6    	vfnmadd231pd zmm10,zmm8,zmm6
  1cfa22:	62 f1 cd 48 59 f2    	vmulpd zmm6,zmm6,zmm2
  1cfa28:	62 f2 bd 48 b8 f5    	vfmadd231pd zmm6,zmm8,zmm5
  1cfa2e:	62 f1 c5 48 59 ea    	vmulpd zmm5,zmm7,zmm2
  1cfa34:	62 f2 bd 48 bc eb    	vfnmadd231pd zmm5,zmm8,zmm3
  1cfa3a:	62 11 fd 48 29 0c e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm9
  1cfa41:	62 11 fd 48 29 14 e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm10
  1cfa48:	62 f2 f5 48 16 de    	vpermpd zmm3,zmm1,zmm6
  1cfa4e:	62 b1 fd 48 29 1c ea 	vmovapd ZMMWORD PTR [rdx+r13*8],zmm3
  1cfa55:	62 f2 f5 48 16 dd    	vpermpd zmm3,zmm1,zmm5
  1cfa5b:	62 91 fd 48 29 1c e8 	vmovapd ZMMWORD PTR [r8+r13*8],zmm3
  1cfa62:	49 83 c4 08          	add    r12,0x8
  1cfa66:	49 39 c4             	cmp    r12,rax
  1cfa69:	0f 82 41 ff ff ff    	jb     1cf9b0 <PyInit__clifft_core@@Base+0x1812f0>
  1cfa6f:	49 01 c2             	add    r10,rax
  1cfa72:	49 01 c2             	add    r10,rax
  1cfa75:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1cfa79:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1cfa7e:	4d 01 cf             	add    r15,r9
  1cfa81:	4d 01 ce             	add    r14,r9
  1cfa84:	48 85 c9             	test   rcx,rcx
  1cfa87:	0f 84 13 ff ff ff    	je     1cf9a0 <PyInit__clifft_core@@Base+0x1812e0>
  1cfa8d:	e9 bc 02 00 00       	jmp    1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cfa92:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1cfa97:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1cfa9a:	83 e2 07             	and    edx,0x7
  1cfa9d:	c1 e2 06             	shl    edx,0x6
  1cfaa0:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1cfaa4:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1cfaa8:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1cfaac:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1cfab0:	4c 8d 05 09 3d e5 ff 	lea    r8,[rip+0xffffffffffe53d09]        # 237c0 <PyInit__clifft_core@@Base-0x2af00>
  1cfab7:	62 b1 fd 48 28 0c 02 	vmovapd zmm1,ZMMWORD PTR [rdx+r8*1]
  1cfabe:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1cfac5:	0f 84 d8 01 00 00    	je     1cfca3 <PyInit__clifft_core@@Base+0x1815e3>
  1cfacb:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cfacf:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cfad4:	31 d2                	xor    edx,edx
  1cfad6:	4c 8d 05 e3 3a e5 ff 	lea    r8,[rip+0xffffffffffe53ae3]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cfadd:	0f 1f 00             	nop    DWORD PTR [rax]
  1cfae0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1cfae7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1cfaee:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1cfaf4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1cfafa:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cfafe:	4d 89 ca             	mov    r10,r9
  1cfb01:	49 21 d2             	and    r10,rdx
  1cfb04:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cfb09:	41 83 e2 01          	and    r10d,0x1
  1cfb0d:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1cfb12:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1cfb16:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1cfb1c:	41 83 e1 07          	and    r9d,0x7
  1cfb20:	41 c1 e1 06          	shl    r9d,0x6
  1cfb24:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1cfb2a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1cfb31:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1cfb37:	62 f2 bd 48 b8 df    	vfmadd231pd zmm3,zmm8,zmm7
  1cfb3d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1cfb43:	62 f2 bd 48 bc ee    	vfnmadd231pd zmm5,zmm8,zmm6
  1cfb49:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1cfb50:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1cfb57:	48 83 c2 08          	add    rdx,0x8
  1cfb5b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cfb60:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cfb65:	4d 85 c9             	test   r9,r9
  1cfb68:	0f 84 72 ff ff ff    	je     1cfae0 <PyInit__clifft_core@@Base+0x181420>
  1cfb6e:	e9 db 01 00 00       	jmp    1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cfb73:	48 85 c0             	test   rax,rax
  1cfb76:	0f 84 d2 01 00 00    	je     1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cfb7c:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1cfb81:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cfb85:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cfb8a:	49 89 c1             	mov    r9,rax
  1cfb8d:	49 c1 e1 04          	shl    r9,0x4
  1cfb91:	45 31 d2             	xor    r10d,r10d
  1cfb94:	49 bb f8 ff ff ff ff 	movabs r11,0x1ffffffffffffff8
  1cfb9b:	ff ff 1f 
  1cfb9e:	48 8d 1d 1b 3a e5 ff 	lea    rbx,[rip+0xffffffffffe53a1b]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cfba5:	49 89 d6             	mov    r14,rdx
  1cfba8:	4d 89 c7             	mov    r15,r8
  1cfbab:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
  1cfbb0:	45 31 e4             	xor    r12d,r12d
  1cfbb3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cfbba:	84 00 00 00 00 00 
  1cfbc0:	4b 8d 0c 22          	lea    rcx,[r10+r12*1]
  1cfbc4:	4c 8b 6e 08          	mov    r13,QWORD PTR [rsi+0x8]
  1cfbc8:	49 31 cd             	xor    r13,rcx
  1cfbcb:	4d 21 dd             	and    r13,r11
  1cfbce:	62 91 fd 48 28 1c e6 	vmovapd zmm3,ZMMWORD PTR [r14+r12*8]
  1cfbd5:	62 91 fd 48 28 2c e7 	vmovapd zmm5,ZMMWORD PTR [r15+r12*8]
  1cfbdc:	62 b2 f5 48 16 34 ea 	vpermpd zmm6,zmm1,ZMMWORD PTR [rdx+r13*8]
  1cfbe3:	62 92 f5 48 16 3c e8 	vpermpd zmm7,zmm1,ZMMWORD PTR [r8+r13*8]
  1cfbea:	48 8b 6e 10          	mov    rbp,QWORD PTR [rsi+0x10]
  1cfbee:	48 21 e9             	and    rcx,rbp
  1cfbf1:	f3 48 0f b8 c9       	popcnt rcx,rcx
  1cfbf6:	83 e1 01             	and    ecx,0x1
  1cfbf9:	c5 f8 92 c9          	kmovw  k1,ecx
  1cfbfd:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1cfc01:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1cfc07:	83 e5 07             	and    ebp,0x7
  1cfc0a:	c1 e5 06             	shl    ebp,0x6
  1cfc0d:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1cfc13:	62 71 bd 48 59 44 1d 	vmulpd zmm8,zmm8,ZMMWORD PTR [rbp+rbx*1+0x0]
  1cfc1a:	00 
  1cfc1b:	62 71 e5 48 59 ca    	vmulpd zmm9,zmm3,zmm2
  1cfc21:	62 72 bd 48 bc ce    	vfnmadd231pd zmm9,zmm8,zmm6
  1cfc27:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1cfc2d:	62 72 bd 48 bc d7    	vfnmadd231pd zmm10,zmm8,zmm7
  1cfc33:	62 f1 cd 48 59 f2    	vmulpd zmm6,zmm6,zmm2
  1cfc39:	62 f2 bd 48 b8 f3    	vfmadd231pd zmm6,zmm8,zmm3
  1cfc3f:	62 f1 c5 48 59 da    	vmulpd zmm3,zmm7,zmm2
  1cfc45:	62 f2 bd 48 b8 dd    	vfmadd231pd zmm3,zmm8,zmm5
  1cfc4b:	62 11 fd 48 29 0c e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm9
  1cfc52:	62 11 fd 48 29 14 e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm10
  1cfc59:	62 f2 f5 48 16 ee    	vpermpd zmm5,zmm1,zmm6
  1cfc5f:	62 b1 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [rdx+r13*8],zmm5
  1cfc66:	62 f2 f5 48 16 db    	vpermpd zmm3,zmm1,zmm3
  1cfc6c:	62 91 fd 48 29 1c e8 	vmovapd ZMMWORD PTR [r8+r13*8],zmm3
  1cfc73:	49 83 c4 08          	add    r12,0x8
  1cfc77:	49 39 c4             	cmp    r12,rax
  1cfc7a:	0f 82 40 ff ff ff    	jb     1cfbc0 <PyInit__clifft_core@@Base+0x181500>
  1cfc80:	49 01 c2             	add    r10,rax
  1cfc83:	49 01 c2             	add    r10,rax
  1cfc86:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1cfc8a:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1cfc8f:	4d 01 cf             	add    r15,r9
  1cfc92:	4d 01 ce             	add    r14,r9
  1cfc95:	48 85 c9             	test   rcx,rcx
  1cfc98:	0f 84 12 ff ff ff    	je     1cfbb0 <PyInit__clifft_core@@Base+0x1814f0>
  1cfc9e:	e9 ab 00 00 00       	jmp    1cfd4e <PyInit__clifft_core@@Base+0x18168e>
  1cfca3:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1cfca8:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cfcac:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cfcb1:	31 d2                	xor    edx,edx
  1cfcb3:	4c 8d 05 06 39 e5 ff 	lea    r8,[rip+0xffffffffffe53906]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cfcba:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1cfcc0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1cfcc7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1cfcce:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1cfcd4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1cfcda:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cfcde:	4d 89 ca             	mov    r10,r9
  1cfce1:	49 21 d2             	and    r10,rdx
  1cfce4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cfce9:	41 83 e2 01          	and    r10d,0x1
  1cfced:	41 83 e1 07          	and    r9d,0x7
  1cfcf1:	41 c1 e1 06          	shl    r9d,0x6
  1cfcf5:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1cfcfa:	c5 79 28 c0          	vmovapd xmm8,xmm0
  1cfcfe:	62 71 bf 09 10 c4    	vmovsd xmm8{k1},xmm8,xmm4
  1cfd04:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1cfd0a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1cfd11:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1cfd17:	62 f2 bd 48 b8 de    	vfmadd231pd zmm3,zmm8,zmm6
  1cfd1d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1cfd23:	62 f2 bd 48 b8 ef    	vfmadd231pd zmm5,zmm8,zmm7
  1cfd29:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1cfd30:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1cfd37:	48 83 c2 08          	add    rdx,0x8
  1cfd3b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cfd40:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cfd45:	4d 85 c9             	test   r9,r9
  1cfd48:	0f 84 72 ff ff ff    	je     1cfcc0 <PyInit__clifft_core@@Base+0x181600>
  1cfd4e:	5b                   	pop    rbx
  1cfd4f:	41 5c                	pop    r12
  1cfd51:	41 5d                	pop    r13
  1cfd53:	41 5e                	pop    r14
  1cfd55:	41 5f                	pop    r15
  1cfd57:	5d                   	pop    rbp
  1cfd58:	c5 f8 77             	vzeroupper
  1cfd5b:	c3                   	ret
