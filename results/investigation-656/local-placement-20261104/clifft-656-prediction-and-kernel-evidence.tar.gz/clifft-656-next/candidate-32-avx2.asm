
/tmp/clifft-656-next/candidate-32/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001c42a0 <PyInit__clifft_core@@Base+0x175c40>:
  1c42a0:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1c42a5:	85 c9                	test   ecx,ecx
  1c42a7:	74 08                	je     1c42b1 <PyInit__clifft_core@@Base+0x175c51>
  1c42a9:	c5 e1 57 1d 6f 96 e4 	vxorpd xmm3,xmm3,XMMWORD PTR [rip+0xffffffffffe4966f]        # d920 <PyInit__clifft_core@@Base-0x40d40>
  1c42b0:	ff 
  1c42b1:	55                   	push   rbp
  1c42b2:	41 57                	push   r15
  1c42b4:	41 56                	push   r14
  1c42b6:	41 55                	push   r13
  1c42b8:	41 54                	push   r12
  1c42ba:	53                   	push   rbx
  1c42bb:	83 fa 03             	cmp    edx,0x3
  1c42be:	0f 84 08 02 00 00    	je     1c44cc <PyInit__clifft_core@@Base+0x175e6c>
  1c42c4:	83 fa 02             	cmp    edx,0x2
  1c42c7:	0f 84 a2 00 00 00    	je     1c436f <PyInit__clifft_core@@Base+0x175d0f>
  1c42cd:	83 fa 01             	cmp    edx,0x1
  1c42d0:	0f 85 7f 04 00 00    	jne    1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c42d6:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c42da:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c42de:	c4 e2 7d 19 46 30    	vbroadcastsd ymm0,QWORD PTR [rsi+0x30]
  1c42e4:	c5 e1 57 0d 34 96 e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe49634]        # d920 <PyInit__clifft_core@@Base-0x40d40>
  1c42eb:	ff 
  1c42ec:	31 d2                	xor    edx,edx
  1c42ee:	4c 8d 05 2b ee e5 ff 	lea    r8,[rip+0xffffffffffe5ee2b]        # 23120 <PyInit__clifft_core@@Base-0x2b540>
  1c42f5:	eb 59                	jmp    1c4350 <PyInit__clifft_core@@Base+0x175cf0>
  1c42f7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1c42fe:	00 00 
  1c4300:	c5 fd 28 24 d0       	vmovapd ymm4,YMMWORD PTR [rax+rdx*8]
  1c4305:	c5 fd 28 2c d1       	vmovapd ymm5,YMMWORD PTR [rcx+rdx*8]
  1c430a:	41 83 e1 03          	and    r9d,0x3
  1c430e:	41 c1 e1 05          	shl    r9d,0x5
  1c4312:	c4 e2 7d 19 d2       	vbroadcastsd ymm2,xmm2
  1c4317:	c4 81 6d 59 14 01    	vmulpd ymm2,ymm2,YMMWORD PTR [r9+r8*1]
  1c431d:	c5 dd 59 f0          	vmulpd ymm6,ymm4,ymm0
  1c4321:	c4 e2 ed b8 f5       	vfmadd231pd ymm6,ymm2,ymm5
  1c4326:	c5 d5 59 e8          	vmulpd ymm5,ymm5,ymm0
  1c432a:	c4 e2 ed bc ec       	vfnmadd231pd ymm5,ymm2,ymm4
  1c432f:	c5 fd 29 34 d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm6
  1c4334:	c5 fd 29 2c d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm5
  1c4339:	48 83 c2 04          	add    rdx,0x4
  1c433d:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c4342:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4347:	4d 85 c9             	test   r9,r9
  1c434a:	0f 85 05 04 00 00    	jne    1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c4350:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c4354:	4d 89 ca             	mov    r10,r9
  1c4357:	49 21 d2             	and    r10,rdx
  1c435a:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c435f:	c5 f9 28 d3          	vmovapd xmm2,xmm3
  1c4363:	41 f6 c2 01          	test   r10b,0x1
  1c4367:	74 97                	je     1c4300 <PyInit__clifft_core@@Base+0x175ca0>
  1c4369:	c5 f9 28 d1          	vmovapd xmm2,xmm1
  1c436d:	eb 91                	jmp    1c4300 <PyInit__clifft_core@@Base+0x175ca0>
  1c436f:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c4374:	48 8b 46 18          	mov    rax,QWORD PTR [rsi+0x18]
  1c4378:	44 8b 4e 08          	mov    r9d,DWORD PTR [rsi+0x8]
  1c437c:	41 83 e1 03          	and    r9d,0x3
  1c4380:	41 c1 e1 05          	shl    r9d,0x5
  1c4384:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c4388:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c438c:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
  1c4390:	4c 8b 47 20          	mov    r8,QWORD PTR [rdi+0x20]
  1c4394:	4c 8d 15 05 ee e5 ff 	lea    r10,[rip+0xffffffffffe5ee05]        # 231a0 <PyInit__clifft_core@@Base-0x2b4c0>
  1c439b:	c4 81 7d 28 0c 11    	vmovapd ymm1,YMMWORD PTR [r9+r10*1]
  1c43a1:	c4 e2 7d 19 56 30    	vbroadcastsd ymm2,QWORD PTR [rsi+0x30]
  1c43a7:	0f 84 ec 01 00 00    	je     1c4599 <PyInit__clifft_core@@Base+0x175f39>
  1c43ad:	48 85 c0             	test   rax,rax
  1c43b0:	0f 84 9f 03 00 00    	je     1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c43b6:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c43ba:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c43bf:	49 89 c1             	mov    r9,rax
  1c43c2:	49 c1 e1 04          	shl    r9,0x4
  1c43c6:	45 31 d2             	xor    r10d,r10d
  1c43c9:	49 bb fc ff ff ff ff 	movabs r11,0x1ffffffffffffffc
  1c43d0:	ff ff 1f 
  1c43d3:	48 8d 1d 46 ed e5 ff 	lea    rbx,[rip+0xffffffffffe5ed46]        # 23120 <PyInit__clifft_core@@Base-0x2b540>
  1c43da:	49 89 d6             	mov    r14,rdx
  1c43dd:	4d 89 c7             	mov    r15,r8
  1c43e0:	eb 2c                	jmp    1c440e <PyInit__clifft_core@@Base+0x175dae>
  1c43e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c43e9:	1f 84 00 00 00 00 00 
  1c43f0:	49 01 c2             	add    r10,rax
  1c43f3:	49 01 c2             	add    r10,rax
  1c43f6:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c43fa:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c43ff:	4d 01 cf             	add    r15,r9
  1c4402:	4d 01 ce             	add    r14,r9
  1c4405:	48 85 c9             	test   rcx,rcx
  1c4408:	0f 85 47 03 00 00    	jne    1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c440e:	45 31 e4             	xor    r12d,r12d
  1c4411:	e9 8c 00 00 00       	jmp    1c44a2 <PyInit__clifft_core@@Base+0x175e42>
  1c4416:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c441d:	00 00 00 
  1c4420:	4c 33 6e 08          	xor    r13,QWORD PTR [rsi+0x8]
  1c4424:	4d 21 dd             	and    r13,r11
  1c4427:	c4 81 7d 28 2c e6    	vmovapd ymm5,YMMWORD PTR [r14+r12*8]
  1c442d:	c4 a2 75 16 34 ea    	vpermps ymm6,ymm1,YMMWORD PTR [rdx+r13*8]
  1c4433:	c4 81 7d 28 3c e7    	vmovapd ymm7,YMMWORD PTR [r15+r12*8]
  1c4439:	c4 02 75 16 04 e8    	vpermps ymm8,ymm1,YMMWORD PTR [r8+r13*8]
  1c443f:	83 e1 03             	and    ecx,0x3
  1c4442:	c1 e1 05             	shl    ecx,0x5
  1c4445:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c444a:	c5 e5 59 1c 19       	vmulpd ymm3,ymm3,YMMWORD PTR [rcx+rbx*1]
  1c444f:	c5 55 59 ca          	vmulpd ymm9,ymm5,ymm2
  1c4453:	c4 42 e5 b8 c8       	vfmadd231pd ymm9,ymm3,ymm8
  1c4458:	c5 45 59 d2          	vmulpd ymm10,ymm7,ymm2
  1c445c:	c4 62 e5 bc d6       	vfnmadd231pd ymm10,ymm3,ymm6
  1c4461:	c5 ed 59 f6          	vmulpd ymm6,ymm2,ymm6
  1c4465:	c4 e2 e5 b8 f7       	vfmadd231pd ymm6,ymm3,ymm7
  1c446a:	c5 bd 59 fa          	vmulpd ymm7,ymm8,ymm2
  1c446e:	c4 e2 e5 bc fd       	vfnmadd231pd ymm7,ymm3,ymm5
  1c4473:	c4 01 7d 29 0c e6    	vmovapd YMMWORD PTR [r14+r12*8],ymm9
  1c4479:	c4 01 7d 29 14 e7    	vmovapd YMMWORD PTR [r15+r12*8],ymm10
  1c447f:	c4 e2 75 16 de       	vpermps ymm3,ymm1,ymm6
  1c4484:	c4 a1 7d 29 1c ea    	vmovapd YMMWORD PTR [rdx+r13*8],ymm3
  1c448a:	c4 e2 75 16 df       	vpermps ymm3,ymm1,ymm7
  1c448f:	c4 81 7d 29 1c e8    	vmovapd YMMWORD PTR [r8+r13*8],ymm3
  1c4495:	49 83 c4 04          	add    r12,0x4
  1c4499:	49 39 c4             	cmp    r12,rax
  1c449c:	0f 83 4e ff ff ff    	jae    1c43f0 <PyInit__clifft_core@@Base+0x175d90>
  1c44a2:	4f 8d 2c 22          	lea    r13,[r10+r12*1]
  1c44a6:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1c44aa:	48 89 cd             	mov    rbp,rcx
  1c44ad:	4c 21 ed             	and    rbp,r13
  1c44b0:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c44b5:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c44b9:	40 f6 c5 01          	test   bpl,0x1
  1c44bd:	0f 84 5d ff ff ff    	je     1c4420 <PyInit__clifft_core@@Base+0x175dc0>
  1c44c3:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c44c7:	e9 54 ff ff ff       	jmp    1c4420 <PyInit__clifft_core@@Base+0x175dc0>
  1c44cc:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c44d1:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1c44d4:	83 e2 03             	and    edx,0x3
  1c44d7:	c1 e2 05             	shl    edx,0x5
  1c44da:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c44de:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c44e2:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c44e6:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c44ea:	4c 8d 05 af ec e5 ff 	lea    r8,[rip+0xffffffffffe5ecaf]        # 231a0 <PyInit__clifft_core@@Base-0x2b4c0>
  1c44f1:	c4 a1 7d 28 0c 02    	vmovapd ymm1,YMMWORD PTR [rdx+r8*1]
  1c44f7:	c4 e2 7d 19 56 30    	vbroadcastsd ymm2,QWORD PTR [rsi+0x30]
  1c44fd:	0f 84 b9 01 00 00    	je     1c46bc <PyInit__clifft_core@@Base+0x17605c>
  1c4503:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c4507:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c450c:	31 d2                	xor    edx,edx
  1c450e:	4c 8d 05 0b ec e5 ff 	lea    r8,[rip+0xffffffffffe5ec0b]        # 23120 <PyInit__clifft_core@@Base-0x2b540>
  1c4515:	eb 63                	jmp    1c457a <PyInit__clifft_core@@Base+0x175f1a>
  1c4517:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1c451e:	00 00 
  1c4520:	c5 fd 28 2c d0       	vmovapd ymm5,YMMWORD PTR [rax+rdx*8]
  1c4525:	c5 fd 28 34 d1       	vmovapd ymm6,YMMWORD PTR [rcx+rdx*8]
  1c452a:	c4 e2 75 16 fd       	vpermps ymm7,ymm1,ymm5
  1c452f:	c4 62 75 16 c6       	vpermps ymm8,ymm1,ymm6
  1c4534:	41 83 e1 03          	and    r9d,0x3
  1c4538:	41 c1 e1 05          	shl    r9d,0x5
  1c453c:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c4541:	c4 81 65 59 1c 01    	vmulpd ymm3,ymm3,YMMWORD PTR [r9+r8*1]
  1c4547:	c5 d5 59 ea          	vmulpd ymm5,ymm5,ymm2
  1c454b:	c4 c2 e5 b8 e8       	vfmadd231pd ymm5,ymm3,ymm8
  1c4550:	c5 cd 59 f2          	vmulpd ymm6,ymm6,ymm2
  1c4554:	c4 e2 e5 bc f7       	vfnmadd231pd ymm6,ymm3,ymm7
  1c4559:	c5 fd 29 2c d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm5
  1c455e:	c5 fd 29 34 d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm6
  1c4563:	48 83 c2 04          	add    rdx,0x4
  1c4567:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c456c:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4571:	4d 85 c9             	test   r9,r9
  1c4574:	0f 85 db 01 00 00    	jne    1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c457a:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c457e:	4d 89 ca             	mov    r10,r9
  1c4581:	49 21 d2             	and    r10,rdx
  1c4584:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c4589:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c458d:	41 f6 c2 01          	test   r10b,0x1
  1c4591:	74 8d                	je     1c4520 <PyInit__clifft_core@@Base+0x175ec0>
  1c4593:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c4597:	eb 87                	jmp    1c4520 <PyInit__clifft_core@@Base+0x175ec0>
  1c4599:	48 85 c0             	test   rax,rax
  1c459c:	0f 84 b3 01 00 00    	je     1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c45a2:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c45a7:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c45ab:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c45b0:	49 89 c1             	mov    r9,rax
  1c45b3:	49 c1 e1 04          	shl    r9,0x4
  1c45b7:	45 31 d2             	xor    r10d,r10d
  1c45ba:	49 bb fc ff ff ff ff 	movabs r11,0x1ffffffffffffffc
  1c45c1:	ff ff 1f 
  1c45c4:	48 8d 1d 55 eb e5 ff 	lea    rbx,[rip+0xffffffffffe5eb55]        # 23120 <PyInit__clifft_core@@Base-0x2b540>
  1c45cb:	49 89 d6             	mov    r14,rdx
  1c45ce:	4d 89 c7             	mov    r15,r8
  1c45d1:	eb 2b                	jmp    1c45fe <PyInit__clifft_core@@Base+0x175f9e>
  1c45d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c45da:	84 00 00 00 00 00 
  1c45e0:	49 01 c2             	add    r10,rax
  1c45e3:	49 01 c2             	add    r10,rax
  1c45e6:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c45ea:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c45ef:	4d 01 cf             	add    r15,r9
  1c45f2:	4d 01 ce             	add    r14,r9
  1c45f5:	48 85 c9             	test   rcx,rcx
  1c45f8:	0f 85 57 01 00 00    	jne    1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c45fe:	45 31 e4             	xor    r12d,r12d
  1c4601:	e9 8d 00 00 00       	jmp    1c4693 <PyInit__clifft_core@@Base+0x176033>
  1c4606:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c460d:	00 00 00 
  1c4610:	4c 33 6e 08          	xor    r13,QWORD PTR [rsi+0x8]
  1c4614:	4d 21 dd             	and    r13,r11
  1c4617:	c4 81 7d 28 2c e6    	vmovapd ymm5,YMMWORD PTR [r14+r12*8]
  1c461d:	c4 a2 75 16 34 ea    	vpermps ymm6,ymm1,YMMWORD PTR [rdx+r13*8]
  1c4623:	c4 81 7d 28 3c e7    	vmovapd ymm7,YMMWORD PTR [r15+r12*8]
  1c4629:	c4 02 75 16 04 e8    	vpermps ymm8,ymm1,YMMWORD PTR [r8+r13*8]
  1c462f:	83 e5 03             	and    ebp,0x3
  1c4632:	c1 e5 05             	shl    ebp,0x5
  1c4635:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c463a:	c5 e5 59 5c 1d 00    	vmulpd ymm3,ymm3,YMMWORD PTR [rbp+rbx*1+0x0]
  1c4640:	c5 55 59 ca          	vmulpd ymm9,ymm5,ymm2
  1c4644:	c4 62 e5 bc ce       	vfnmadd231pd ymm9,ymm3,ymm6
  1c4649:	c5 45 59 d2          	vmulpd ymm10,ymm7,ymm2
  1c464d:	c4 42 e5 bc d0       	vfnmadd231pd ymm10,ymm3,ymm8
  1c4652:	c5 ed 59 f6          	vmulpd ymm6,ymm2,ymm6
  1c4656:	c4 e2 e5 b8 f5       	vfmadd231pd ymm6,ymm3,ymm5
  1c465b:	c5 bd 59 ea          	vmulpd ymm5,ymm8,ymm2
  1c465f:	c4 e2 e5 b8 ef       	vfmadd231pd ymm5,ymm3,ymm7
  1c4664:	c4 01 7d 29 0c e6    	vmovapd YMMWORD PTR [r14+r12*8],ymm9
  1c466a:	c4 01 7d 29 14 e7    	vmovapd YMMWORD PTR [r15+r12*8],ymm10
  1c4670:	c4 e2 75 16 de       	vpermps ymm3,ymm1,ymm6
  1c4675:	c4 a1 7d 29 1c ea    	vmovapd YMMWORD PTR [rdx+r13*8],ymm3
  1c467b:	c4 e2 75 16 dd       	vpermps ymm3,ymm1,ymm5
  1c4680:	c4 81 7d 29 1c e8    	vmovapd YMMWORD PTR [r8+r13*8],ymm3
  1c4686:	49 83 c4 04          	add    r12,0x4
  1c468a:	49 39 c4             	cmp    r12,rax
  1c468d:	0f 83 4d ff ff ff    	jae    1c45e0 <PyInit__clifft_core@@Base+0x175f80>
  1c4693:	4f 8d 2c 22          	lea    r13,[r10+r12*1]
  1c4697:	48 8b 6e 10          	mov    rbp,QWORD PTR [rsi+0x10]
  1c469b:	48 89 e9             	mov    rcx,rbp
  1c469e:	4c 21 e9             	and    rcx,r13
  1c46a1:	f3 48 0f b8 c9       	popcnt rcx,rcx
  1c46a6:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c46aa:	f6 c1 01             	test   cl,0x1
  1c46ad:	0f 84 5d ff ff ff    	je     1c4610 <PyInit__clifft_core@@Base+0x175fb0>
  1c46b3:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c46b7:	e9 54 ff ff ff       	jmp    1c4610 <PyInit__clifft_core@@Base+0x175fb0>
  1c46bc:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c46c1:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c46c5:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c46ca:	31 d2                	xor    edx,edx
  1c46cc:	4c 8d 05 4d ea e5 ff 	lea    r8,[rip+0xffffffffffe5ea4d]        # 23120 <PyInit__clifft_core@@Base-0x2b540>
  1c46d3:	eb 61                	jmp    1c4736 <PyInit__clifft_core@@Base+0x1760d6>
  1c46d5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c46dc:	00 00 00 00 
  1c46e0:	c5 fd 28 2c d0       	vmovapd ymm5,YMMWORD PTR [rax+rdx*8]
  1c46e5:	c5 fd 28 34 d1       	vmovapd ymm6,YMMWORD PTR [rcx+rdx*8]
  1c46ea:	c4 e2 75 16 fd       	vpermps ymm7,ymm1,ymm5
  1c46ef:	c4 62 75 16 c6       	vpermps ymm8,ymm1,ymm6
  1c46f4:	41 83 e1 03          	and    r9d,0x3
  1c46f8:	41 c1 e1 05          	shl    r9d,0x5
  1c46fc:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c4701:	c4 81 65 59 1c 01    	vmulpd ymm3,ymm3,YMMWORD PTR [r9+r8*1]
  1c4707:	c5 d5 59 ea          	vmulpd ymm5,ymm5,ymm2
  1c470b:	c4 e2 e5 b8 ef       	vfmadd231pd ymm5,ymm3,ymm7
  1c4710:	c5 cd 59 f2          	vmulpd ymm6,ymm6,ymm2
  1c4714:	c4 c2 e5 b8 f0       	vfmadd231pd ymm6,ymm3,ymm8
  1c4719:	c5 fd 29 2c d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm5
  1c471e:	c5 fd 29 34 d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm6
  1c4723:	48 83 c2 04          	add    rdx,0x4
  1c4727:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c472c:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4731:	4d 85 c9             	test   r9,r9
  1c4734:	75 1f                	jne    1c4755 <PyInit__clifft_core@@Base+0x1760f5>
  1c4736:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c473a:	4d 89 ca             	mov    r10,r9
  1c473d:	49 21 d2             	and    r10,rdx
  1c4740:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c4745:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c4749:	41 f6 c2 01          	test   r10b,0x1
  1c474d:	74 91                	je     1c46e0 <PyInit__clifft_core@@Base+0x176080>
  1c474f:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c4753:	eb 8b                	jmp    1c46e0 <PyInit__clifft_core@@Base+0x176080>
  1c4755:	5b                   	pop    rbx
  1c4756:	41 5c                	pop    r12
  1c4758:	41 5d                	pop    r13
  1c475a:	41 5e                	pop    r14
  1c475c:	41 5f                	pop    r15
  1c475e:	5d                   	pop    rbp
  1c475f:	c5 f8 77             	vzeroupper
  1c4762:	c3                   	ret
