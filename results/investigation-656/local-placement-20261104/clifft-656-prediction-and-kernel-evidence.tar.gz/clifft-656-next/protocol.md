## Predeclared local address-pair test

This protocol is recorded before collecting new timings. It tests a hypothesis suggested by the existing data; it does not assume guest physical address bits identify a host hardware structure.

Evidence already used to form the hypothesis:
- The retained 16-combination coefficient matrix has slower combinations when coefficient page 0/1 or 2/3 share PFN modulo 16.
- The earlier reversible A/B test agrees with that pattern.
- An earlier verified fast worker has coefficient digits D,1,D,1. Therefore the broad rule "any two coefficient pages sharing the low digit are slow" is false; cross-array matches must be distinguished.

Primary controlled test:
- Exact published RC1 wheel and pinned workload/harness from the preceding evidence; direct batch 1, CPU 0, ASLR disabled, Python hash seed 0, unchanged thread/memory limits and fixed seeds.
- Four fresh experimental workers, selected by creation order, plus one unmodified reference worker. No selection by speed.
- At a separate diagnostic breakpoint, allocate and fault a 256-page pool. Select distinct physical pages using only PFNs, with deterministic color order varying by worker. Retain the original State pages. Keep all virtual addresses, bytes, code, descriptor storage and both scratch pages fixed.
- Four coefficient configurations: N=[a,b,c,d], R=[a,a,c,d], I=[a,b,c,c], X=[a,b,a,d], with distinct a,b,c,d (PFN modulo 16). Each repeat uses the same actual selected PFNs. R/I/X each changes only one coefficient page relative to N. Shared digits never mean shared full PFNs.
- Worker orders: NRIXXIRN; RXNIINXR; INXRRXNI; XIRNNRIX (spaces ignored). These are balanced forward/reverse orders; rotate worker execution order each round. The reference worker runs once each round.
- Each measured pass has 100 API calls x 20,000 attempted shots, seeds 20270819..20270918. Two measurements of each configuration per experimental worker, plus eight reference passes: 40 profiled passes. Measure cycles/instructions only. Separately validate exact seeded counts, restored bytes and the six PFNs before/after every measured pass.
- Primary quantities: per-worker median cycle ratios R/N and I/N. Evidence supporting a practically meaningful same-array rule requires each contrast's across-worker median increase >=3%, with positive direction in at least 3/4 workers. A weaker or inconsistent result is reported as such; do not change the rule using these outcomes.
- Negative-control prediction: X/N should have an across-worker median absolute change <=2% and a smaller penalty than either same-array contrast. Report failures rather than retroactively broadening the claim.
- This is a bounded diagnostic, not a release percentage or a population confidence interval. Do not compile or run correctness suites concurrently with timing.

Preparation-history follow-up:
- Record actual State virtual addresses/PFNs using a read-only breakpoint during a separate diagnostic call, without exchanging pages. Both histories get the same diagnostic call. This avoids assuming a freed allocation remains at the same address after calibration.
- Interleave eight direct and eight fully calibrated fresh workers of the same RC1 wheel, each with two fixed-work cycle passes. All calibrated workers must report their selected batch. Record PFNs around measured work and distinguish within-array and cross-array matches; retain workers that contradict the rule.
- The history study is observational. It cannot establish the same causal claim as a reversible exchange. If the controlled prediction fails, interpret correlations cautiously and do not proceed to a huge-page mitigation on the assumption that the rule is proven.

Kernel validation is independent:
- A minimal high-pivot AVX-512 change snapshots the immutable X/Z masks and State size before the loops. Preserve arithmetic, RNG and hot-execution invariants.
- Build parent and candidate with matched compiler/options, test exact seeded output comparisons plus existing SIMD/conformance checks, and evaluate relevant workloads under three function-alignment settings and fresh workers.
- Inspect sibling kernels before expanding scope. No huge-page allocator change or EC2 launch is part of the initial validation; a huge-page prototype is conditional on predictive evidence and must verify actual backing and total API/memory costs.
