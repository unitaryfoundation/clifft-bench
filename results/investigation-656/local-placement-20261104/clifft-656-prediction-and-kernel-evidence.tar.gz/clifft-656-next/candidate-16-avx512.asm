
/tmp/clifft-656-next/candidate-16/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001c4320 <PyInit__clifft_core@@Base+0x175d00>:
  1c4320:	55                   	push   rbp
  1c4321:	41 57                	push   r15
  1c4323:	41 56                	push   r14
  1c4325:	41 55                	push   r13
  1c4327:	41 54                	push   r12
  1c4329:	53                   	push   rbx
  1c432a:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1c432f:	c5 e1 57 05 e9 95 e4 	vxorpd xmm0,xmm3,XMMWORD PTR [rip+0xffffffffffe495e9]        # d920 <PyInit__clifft_core@@Base-0x40d00>
  1c4336:	ff 
  1c4337:	c5 f8 92 c9          	kmovw  k1,ecx
  1c433b:	62 f1 e7 09 10 d8    	vmovsd xmm3{k1},xmm3,xmm0
  1c4341:	83 fa 03             	cmp    edx,0x3
  1c4344:	0f 84 35 02 00 00    	je     1c457f <PyInit__clifft_core@@Base+0x175f5f>
  1c434a:	83 fa 02             	cmp    edx,0x2
  1c434d:	0f 84 b0 00 00 00    	je     1c4403 <PyInit__clifft_core@@Base+0x175de3>
  1c4353:	83 fa 01             	cmp    edx,0x1
  1c4356:	0f 85 e2 04 00 00    	jne    1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c435c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c4360:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c4364:	62 f2 fd 48 19 46 06 	vbroadcastsd zmm0,QWORD PTR [rsi+0x30]
  1c436b:	c5 e1 57 0d ad 95 e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe495ad]        # d920 <PyInit__clifft_core@@Base-0x40d00>
  1c4372:	ff 
  1c4373:	31 d2                	xor    edx,edx
  1c4375:	4c 8d 05 44 f2 e5 ff 	lea    r8,[rip+0xffffffffffe5f244]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c437c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  1c4380:	62 f1 fd 48 28 14 d0 	vmovapd zmm2,ZMMWORD PTR [rax+rdx*8]
  1c4387:	62 f1 fd 48 28 24 d1 	vmovapd zmm4,ZMMWORD PTR [rcx+rdx*8]
  1c438e:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c4392:	4d 89 ca             	mov    r10,r9
  1c4395:	49 21 d2             	and    r10,rdx
  1c4398:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c439d:	41 83 e2 01          	and    r10d,0x1
  1c43a1:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c43a6:	c5 f9 28 eb          	vmovapd xmm5,xmm3
  1c43aa:	62 f1 d7 09 10 e9    	vmovsd xmm5{k1},xmm5,xmm1
  1c43b0:	41 83 e1 07          	and    r9d,0x7
  1c43b4:	41 c1 e1 06          	shl    r9d,0x6
  1c43b8:	62 f2 fd 48 19 ed    	vbroadcastsd zmm5,xmm5
  1c43be:	62 91 d5 48 59 2c 01 	vmulpd zmm5,zmm5,ZMMWORD PTR [r9+r8*1]
  1c43c5:	62 f1 ed 48 59 f0    	vmulpd zmm6,zmm2,zmm0
  1c43cb:	62 f2 d5 48 b8 f4    	vfmadd231pd zmm6,zmm5,zmm4
  1c43d1:	62 f1 dd 48 59 e0    	vmulpd zmm4,zmm4,zmm0
  1c43d7:	62 f2 d5 48 bc e2    	vfnmadd231pd zmm4,zmm5,zmm2
  1c43dd:	62 f1 fd 48 29 34 d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm6
  1c43e4:	62 f1 fd 48 29 24 d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm4
  1c43eb:	48 83 c2 08          	add    rdx,0x8
  1c43ef:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c43f4:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c43f9:	4d 85 c9             	test   r9,r9
  1c43fc:	74 82                	je     1c4380 <PyInit__clifft_core@@Base+0x175d60>
  1c43fe:	e9 3b 04 00 00       	jmp    1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c4403:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c4408:	48 8b 46 08          	mov    rax,QWORD PTR [rsi+0x8]
  1c440c:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1c4410:	48 8b 56 18          	mov    rdx,QWORD PTR [rsi+0x18]
  1c4414:	4c 8d 04 12          	lea    r8,[rdx+rdx*1]
  1c4418:	41 89 c3             	mov    r11d,eax
  1c441b:	41 83 e3 07          	and    r11d,0x7
  1c441f:	41 c1 e3 06          	shl    r11d,0x6
  1c4423:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c4427:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c442b:	4c 8b 4f 18          	mov    r9,QWORD PTR [rdi+0x18]
  1c442f:	4c 8b 57 20          	mov    r10,QWORD PTR [rdi+0x20]
  1c4433:	8b 7f 54             	mov    edi,DWORD PTR [rdi+0x54]
  1c4436:	48 8d 1d 83 f3 e5 ff 	lea    rbx,[rip+0xffffffffffe5f383]        # 237c0 <PyInit__clifft_core@@Base-0x2ae60>
  1c443d:	62 d1 fd 48 28 0c 1b 	vmovapd zmm1,ZMMWORD PTR [r11+rbx*1]
  1c4444:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c444b:	0f 84 12 02 00 00    	je     1c4663 <PyInit__clifft_core@@Base+0x176043>
  1c4451:	48 85 d2             	test   rdx,rdx
  1c4454:	0f 84 e4 03 00 00    	je     1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c445a:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c445e:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c4463:	89 ce                	mov    esi,ecx
  1c4465:	83 e6 07             	and    esi,0x7
  1c4468:	c1 e6 06             	shl    esi,0x6
  1c446b:	4c 8d 1d 4e f1 e5 ff 	lea    r11,[rip+0xffffffffffe5f14e]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c4472:	62 b1 fd 48 28 1c 1e 	vmovapd zmm3,ZMMWORD PTR [rsi+r11*1]
  1c4479:	48 89 d6             	mov    rsi,rdx
  1c447c:	48 c1 e6 04          	shl    rsi,0x4
  1c4480:	45 31 db             	xor    r11d,r11d
  1c4483:	48 bb f8 ff ff ff ff 	movabs rbx,0x1ffffffffffffff8
  1c448a:	ff ff 1f 
  1c448d:	4d 89 ce             	mov    r14,r9
  1c4490:	4d 89 d7             	mov    r15,r10
  1c4493:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c449a:	84 00 00 00 00 00 
  1c44a0:	45 31 e4             	xor    r12d,r12d
  1c44a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c44aa:	84 00 00 00 00 00 
  1c44b0:	4b 8d 2c 23          	lea    rbp,[r11+r12*1]
  1c44b4:	49 89 ed             	mov    r13,rbp
  1c44b7:	49 31 c5             	xor    r13,rax
  1c44ba:	49 21 dd             	and    r13,rbx
  1c44bd:	62 91 fd 48 28 2c e6 	vmovapd zmm5,ZMMWORD PTR [r14+r12*8]
  1c44c4:	62 91 fd 48 28 34 e7 	vmovapd zmm6,ZMMWORD PTR [r15+r12*8]
  1c44cb:	62 92 f5 48 16 3c e9 	vpermpd zmm7,zmm1,ZMMWORD PTR [r9+r13*8]
  1c44d2:	62 12 f5 48 16 04 ea 	vpermpd zmm8,zmm1,ZMMWORD PTR [r10+r13*8]
  1c44d9:	48 21 cd             	and    rbp,rcx
  1c44dc:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c44e1:	83 e5 01             	and    ebp,0x1
  1c44e4:	c5 f8 92 cd          	kmovw  k1,ebp
  1c44e8:	c5 79 28 cc          	vmovapd xmm9,xmm4
  1c44ec:	62 71 b7 09 10 c8    	vmovsd xmm9{k1},xmm9,xmm0
  1c44f2:	62 52 fd 48 19 c9    	vbroadcastsd zmm9,xmm9
  1c44f8:	62 71 b5 48 59 cb    	vmulpd zmm9,zmm9,zmm3
  1c44fe:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c4504:	62 52 b5 48 b8 d0    	vfmadd231pd zmm10,zmm9,zmm8
  1c450a:	62 71 cd 48 59 da    	vmulpd zmm11,zmm6,zmm2
  1c4510:	62 72 b5 48 bc df    	vfnmadd231pd zmm11,zmm9,zmm7
  1c4516:	62 f1 c5 48 59 fa    	vmulpd zmm7,zmm7,zmm2
  1c451c:	62 f2 b5 48 b8 fe    	vfmadd231pd zmm7,zmm9,zmm6
  1c4522:	62 f1 bd 48 59 f2    	vmulpd zmm6,zmm8,zmm2
  1c4528:	62 f2 b5 48 bc f5    	vfnmadd231pd zmm6,zmm9,zmm5
  1c452e:	62 11 fd 48 29 14 e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm10
  1c4535:	62 11 fd 48 29 1c e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm11
  1c453c:	62 f2 f5 48 16 ef    	vpermpd zmm5,zmm1,zmm7
  1c4542:	62 91 fd 48 29 2c e9 	vmovapd ZMMWORD PTR [r9+r13*8],zmm5
  1c4549:	62 f2 f5 48 16 ee    	vpermpd zmm5,zmm1,zmm6
  1c454f:	62 91 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [r10+r13*8],zmm5
  1c4556:	49 83 c4 08          	add    r12,0x8
  1c455a:	49 39 d4             	cmp    r12,rdx
  1c455d:	0f 82 4d ff ff ff    	jb     1c44b0 <PyInit__clifft_core@@Base+0x175e90>
  1c4563:	4d 01 c3             	add    r11,r8
  1c4566:	c4 42 c3 f7 e3       	shrx   r12,r11,rdi
  1c456b:	49 01 f7             	add    r15,rsi
  1c456e:	49 01 f6             	add    r14,rsi
  1c4571:	4d 85 e4             	test   r12,r12
  1c4574:	0f 84 26 ff ff ff    	je     1c44a0 <PyInit__clifft_core@@Base+0x175e80>
  1c457a:	e9 bf 02 00 00       	jmp    1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c457f:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c4584:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1c4587:	83 e2 07             	and    edx,0x7
  1c458a:	c1 e2 06             	shl    edx,0x6
  1c458d:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c4591:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c4595:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c4599:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c459d:	4c 8d 05 1c f2 e5 ff 	lea    r8,[rip+0xffffffffffe5f21c]        # 237c0 <PyInit__clifft_core@@Base-0x2ae60>
  1c45a4:	62 b1 fd 48 28 0c 02 	vmovapd zmm1,ZMMWORD PTR [rdx+r8*1]
  1c45ab:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c45b2:	0f 84 d7 01 00 00    	je     1c478f <PyInit__clifft_core@@Base+0x17616f>
  1c45b8:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c45bc:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c45c1:	31 d2                	xor    edx,edx
  1c45c3:	4c 8d 05 f6 ef e5 ff 	lea    r8,[rip+0xffffffffffe5eff6]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c45ca:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1c45d0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c45d7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c45de:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c45e4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c45ea:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c45ee:	4d 89 ca             	mov    r10,r9
  1c45f1:	49 21 d2             	and    r10,rdx
  1c45f4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c45f9:	41 83 e2 01          	and    r10d,0x1
  1c45fd:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c4602:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c4606:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c460c:	41 83 e1 07          	and    r9d,0x7
  1c4610:	41 c1 e1 06          	shl    r9d,0x6
  1c4614:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c461a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c4621:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c4627:	62 f2 bd 48 b8 df    	vfmadd231pd zmm3,zmm8,zmm7
  1c462d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c4633:	62 f2 bd 48 bc ee    	vfnmadd231pd zmm5,zmm8,zmm6
  1c4639:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c4640:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c4647:	48 83 c2 08          	add    rdx,0x8
  1c464b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c4650:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4655:	4d 85 c9             	test   r9,r9
  1c4658:	0f 84 72 ff ff ff    	je     1c45d0 <PyInit__clifft_core@@Base+0x175fb0>
  1c465e:	e9 db 01 00 00       	jmp    1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c4663:	48 85 d2             	test   rdx,rdx
  1c4666:	0f 84 d2 01 00 00    	je     1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c466c:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c4671:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c4675:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c467a:	89 ce                	mov    esi,ecx
  1c467c:	83 e6 07             	and    esi,0x7
  1c467f:	c1 e6 06             	shl    esi,0x6
  1c4682:	4c 8d 1d 37 ef e5 ff 	lea    r11,[rip+0xffffffffffe5ef37]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c4689:	62 b1 fd 48 28 1c 1e 	vmovapd zmm3,ZMMWORD PTR [rsi+r11*1]
  1c4690:	48 89 d6             	mov    rsi,rdx
  1c4693:	48 c1 e6 04          	shl    rsi,0x4
  1c4697:	45 31 db             	xor    r11d,r11d
  1c469a:	48 bb f8 ff ff ff ff 	movabs rbx,0x1ffffffffffffff8
  1c46a1:	ff ff 1f 
  1c46a4:	4d 89 ce             	mov    r14,r9
  1c46a7:	4d 89 d7             	mov    r15,r10
  1c46aa:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1c46b0:	45 31 e4             	xor    r12d,r12d
  1c46b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c46ba:	84 00 00 00 00 00 
  1c46c0:	4b 8d 2c 23          	lea    rbp,[r11+r12*1]
  1c46c4:	49 89 ed             	mov    r13,rbp
  1c46c7:	49 31 c5             	xor    r13,rax
  1c46ca:	49 21 dd             	and    r13,rbx
  1c46cd:	62 91 fd 48 28 2c e6 	vmovapd zmm5,ZMMWORD PTR [r14+r12*8]
  1c46d4:	62 91 fd 48 28 34 e7 	vmovapd zmm6,ZMMWORD PTR [r15+r12*8]
  1c46db:	62 92 f5 48 16 3c e9 	vpermpd zmm7,zmm1,ZMMWORD PTR [r9+r13*8]
  1c46e2:	62 12 f5 48 16 04 ea 	vpermpd zmm8,zmm1,ZMMWORD PTR [r10+r13*8]
  1c46e9:	48 21 cd             	and    rbp,rcx
  1c46ec:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c46f1:	83 e5 01             	and    ebp,0x1
  1c46f4:	c5 f8 92 cd          	kmovw  k1,ebp
  1c46f8:	c5 79 28 cc          	vmovapd xmm9,xmm4
  1c46fc:	62 71 b7 09 10 c8    	vmovsd xmm9{k1},xmm9,xmm0
  1c4702:	62 52 fd 48 19 c9    	vbroadcastsd zmm9,xmm9
  1c4708:	62 71 b5 48 59 cb    	vmulpd zmm9,zmm9,zmm3
  1c470e:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c4714:	62 72 b5 48 bc d7    	vfnmadd231pd zmm10,zmm9,zmm7
  1c471a:	62 71 cd 48 59 da    	vmulpd zmm11,zmm6,zmm2
  1c4720:	62 52 b5 48 bc d8    	vfnmadd231pd zmm11,zmm9,zmm8
  1c4726:	62 f1 c5 48 59 fa    	vmulpd zmm7,zmm7,zmm2
  1c472c:	62 f2 b5 48 b8 fd    	vfmadd231pd zmm7,zmm9,zmm5
  1c4732:	62 f1 bd 48 59 ea    	vmulpd zmm5,zmm8,zmm2
  1c4738:	62 f2 b5 48 b8 ee    	vfmadd231pd zmm5,zmm9,zmm6
  1c473e:	62 11 fd 48 29 14 e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm10
  1c4745:	62 11 fd 48 29 1c e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm11
  1c474c:	62 f2 f5 48 16 f7    	vpermpd zmm6,zmm1,zmm7
  1c4752:	62 91 fd 48 29 34 e9 	vmovapd ZMMWORD PTR [r9+r13*8],zmm6
  1c4759:	62 f2 f5 48 16 ed    	vpermpd zmm5,zmm1,zmm5
  1c475f:	62 91 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [r10+r13*8],zmm5
  1c4766:	49 83 c4 08          	add    r12,0x8
  1c476a:	49 39 d4             	cmp    r12,rdx
  1c476d:	0f 82 4d ff ff ff    	jb     1c46c0 <PyInit__clifft_core@@Base+0x1760a0>
  1c4773:	4d 01 c3             	add    r11,r8
  1c4776:	c4 42 c3 f7 e3       	shrx   r12,r11,rdi
  1c477b:	49 01 f7             	add    r15,rsi
  1c477e:	49 01 f6             	add    r14,rsi
  1c4781:	4d 85 e4             	test   r12,r12
  1c4784:	0f 84 26 ff ff ff    	je     1c46b0 <PyInit__clifft_core@@Base+0x176090>
  1c478a:	e9 af 00 00 00       	jmp    1c483e <PyInit__clifft_core@@Base+0x17621e>
  1c478f:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c4794:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c4798:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c479d:	31 d2                	xor    edx,edx
  1c479f:	4c 8d 05 1a ee e5 ff 	lea    r8,[rip+0xffffffffffe5ee1a]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c47a6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c47ad:	00 00 00 
  1c47b0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c47b7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c47be:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c47c4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c47ca:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c47ce:	4d 89 ca             	mov    r10,r9
  1c47d1:	49 21 d2             	and    r10,rdx
  1c47d4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c47d9:	41 83 e2 01          	and    r10d,0x1
  1c47dd:	41 83 e1 07          	and    r9d,0x7
  1c47e1:	41 c1 e1 06          	shl    r9d,0x6
  1c47e5:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c47ea:	c5 79 28 c0          	vmovapd xmm8,xmm0
  1c47ee:	62 71 bf 09 10 c4    	vmovsd xmm8{k1},xmm8,xmm4
  1c47f4:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c47fa:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c4801:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c4807:	62 f2 bd 48 b8 de    	vfmadd231pd zmm3,zmm8,zmm6
  1c480d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c4813:	62 f2 bd 48 b8 ef    	vfmadd231pd zmm5,zmm8,zmm7
  1c4819:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c4820:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c4827:	48 83 c2 08          	add    rdx,0x8
  1c482b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c4830:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4835:	4d 85 c9             	test   r9,r9
  1c4838:	0f 84 72 ff ff ff    	je     1c47b0 <PyInit__clifft_core@@Base+0x176190>
  1c483e:	5b                   	pop    rbx
  1c483f:	41 5c                	pop    r12
  1c4841:	41 5d                	pop    r13
  1c4843:	41 5e                	pop    r14
  1c4845:	41 5f                	pop    r15
  1c4847:	5d                   	pop    rbp
  1c4848:	c5 f8 77             	vzeroupper
  1c484b:	c3                   	ret
