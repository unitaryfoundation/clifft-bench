import csv,json,statistics
from pathlib import Path
root=Path('/tmp/clifft-656-placement/history-frames-v1')
events=[json.loads(line) for line in (root/'results.jsonl').read_text().splitlines()]
start={e['worker']:e['history'] for e in events if e.get('action')=='starting-worker'}
preps={e['worker']:e['result']['runtime_metadata'] for e in events if e.get('request',{}).get('command')=='prepare'}
observations={e['worker']:e['evidence'] for e in events if e.get('action')=='observed-backing' and e['phase']=='before'}
finals={e['worker']:e for e in events if e.get('action')=='worker-backing-summary'}
assert len(start)==len(preps)==len(observations)==len(finals)==16
samples=[e for e in events if e.get('request',{}).get('command')=='sample' and e['request']['min_seconds']==-100]
assert len(samples)==32
backings=[e for e in events if e.get('action')=='measurement-backing'];assert len(backings)==32
rows=[]
for index in range(16):
    meta=preps[index];assert meta['effective_batch_size']==1
    if start[index]=='calibrate':
        calibration=meta['batch_calibration'];assert calibration['selected_batch_size']==1
        trials=calibration['results']
        assert [t['batch_size'] for t in trials if t['status']=='success']==[1,32,64,256,1024,2048]
    pfns=observations[index]['pfns'];colors=[p%16 for p in pfns[:4]]
    cycles=[];instructions=[];rates=[]
    for e in samples:
        if e['worker']!=index:continue
        result=e['result'];assert (result['attempted_shots'],result['accepted_shots'],result['discarded_shots'],result['logical_errors'])==(2000000,287417,1712583,0)
        path=root/f"{index}-{e['phase']}.csv"
        for line in path.read_text().splitlines():
            fields=line.split(',')
            if len(fields)>5 and fields[2] in ['cycles:u','instructions:u']:
                assert float(fields[4])==100
                (cycles if fields[2]=='cycles:u' else instructions).append(int(fields[0]))
        rates.append(result['throughput_attempted_shots_per_second'])
    assert len(cycles)==len(instructions)==2
    stable=all(e['matches_observation'] and all(e['before']['present']) and all(e['after']['present']) for e in backings if e['worker']==index) and finals[index]['same_live_address_and_frames']
    rows.append(dict(worker=index,history=start[index],state=observations[index]['state'],real=observations[index]['address'],pfns=pfns,colors=colors,real_match=colors[0]==colors[1],imag_match=colors[2]==colors[3],cross_match=bool(set(colors[:2])&set(colors[2:])),frames_stable=stable,median_cycles=statistics.median(cycles),cycles=cycles,median_instructions=statistics.median(instructions),median_throughput=statistics.median(rates)))
summary=dict(rows=rows,all_frames_stable=all(r['frames_stable'] for r in rows),histories={h:dict(workers=sum(r['history']==h for r in rows),median_cycles=statistics.median(r['median_cycles'] for r in rows if r['history']==h),min_cycles=min(r['median_cycles'] for r in rows if r['history']==h),max_cycles=max(r['median_cycles'] for r in rows if r['history']==h),same_array_matches=sum(r['real_match'] or r['imag_match'] for r in rows if r['history']==h)) for h in ['direct','calibrate']})
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (root/'workers.csv').open('w') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,indent=2))
