import csv,json,statistics
from pathlib import Path
root=Path('/tmp/clifft-656-next/normal-performance')
events=[json.loads(line) for line in (root/'results.jsonl').read_text().splitlines()]
rows=[]
for event in events:
    if event['action']!='sample':continue
    counters={}
    for line in (root/f"{event['label']}-{event['repetition']}.csv").read_text().splitlines():
        fields=line.split(',')
        if len(fields)>5 and fields[2] in ['cycles:u','instructions:u']:
            assert float(fields[4])==100,fields
            counters[fields[2].split(':')[0]]=int(fields[0])
    assert len(counters)==2
    rows.append(dict(alignment=event['alignment'],workload=event['workload'],fresh=event['fresh'],variant=event['variant'],repetition=event['repetition'],**counters,seconds=event['result']['seconds'],cpu_seconds=event['result']['cpu_seconds'],shots=event['result']['totals'][0],throughput=event['result']['totals'][0]/event['result']['seconds']))
assert len(rows)==144,len(rows)
summary=[]
for workload in sorted({r['workload'] for r in rows}):
    layouts=[]
    for alignment in [16,32,64]:
        medians={}
        for variant in ['parent','candidate']:
            workers=[]
            for fresh in range(2):
                found=[r for r in rows if r['workload']==workload and r['alignment']==alignment and r['variant']==variant and r['fresh']==fresh]
                assert len(found)==2
                workers.append({key:statistics.median(r[key] for r in found) for key in ['cycles','instructions','throughput']})
            medians[variant]={key:statistics.median(w[key] for w in workers) for key in ['cycles','instructions','throughput']}
            medians[variant]['worker_cycles']=[w['cycles'] for w in workers]
        delta={key:100*(medians['candidate'][key]/medians['parent'][key]-1) for key in ['cycles','instructions','throughput']}
        layouts.append(dict(alignment=alignment,builds=medians,percent_change=delta))
    summary.append(dict(workload=workload,layouts=layouts,median_layout_cycle_change=statistics.median(l['percent_change']['cycles'] for l in layouts),median_layout_instruction_change=statistics.median(l['percent_change']['instructions'] for l in layouts)))
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (root/'samples.csv').open('w') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
for s in summary:
    print(s['workload'],'cycles',*[round(l['percent_change']['cycles'],3) for l in s['layouts']],'instructions',*[round(l['percent_change']['instructions'],3) for l in s['layouts']])
