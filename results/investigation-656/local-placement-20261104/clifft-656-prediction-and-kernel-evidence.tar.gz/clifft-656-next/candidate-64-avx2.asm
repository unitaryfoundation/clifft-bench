
/tmp/clifft-656-next/candidate-64/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001cbe80 <PyInit__clifft_core@@Base+0x17d7c0>:
  1cbe80:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1cbe85:	85 c9                	test   ecx,ecx
  1cbe87:	74 08                	je     1cbe91 <PyInit__clifft_core@@Base+0x17d7d1>
  1cbe89:	c5 e1 57 1d 8f 1a e4 	vxorpd xmm3,xmm3,XMMWORD PTR [rip+0xffffffffffe41a8f]        # d920 <PyInit__clifft_core@@Base-0x40da0>
  1cbe90:	ff 
  1cbe91:	55                   	push   rbp
  1cbe92:	41 57                	push   r15
  1cbe94:	41 56                	push   r14
  1cbe96:	41 55                	push   r13
  1cbe98:	41 54                	push   r12
  1cbe9a:	53                   	push   rbx
  1cbe9b:	83 fa 03             	cmp    edx,0x3
  1cbe9e:	0f 84 08 02 00 00    	je     1cc0ac <PyInit__clifft_core@@Base+0x17d9ec>
  1cbea4:	83 fa 02             	cmp    edx,0x2
  1cbea7:	0f 84 a2 00 00 00    	je     1cbf4f <PyInit__clifft_core@@Base+0x17d88f>
  1cbead:	83 fa 01             	cmp    edx,0x1
  1cbeb0:	0f 85 7f 04 00 00    	jne    1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cbeb6:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1cbeba:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1cbebe:	c4 e2 7d 19 46 30    	vbroadcastsd ymm0,QWORD PTR [rsi+0x30]
  1cbec4:	c5 e1 57 0d 54 1a e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe41a54]        # d920 <PyInit__clifft_core@@Base-0x40da0>
  1cbecb:	ff 
  1cbecc:	31 d2                	xor    edx,edx
  1cbece:	4c 8d 05 4b 72 e5 ff 	lea    r8,[rip+0xffffffffffe5724b]        # 23120 <PyInit__clifft_core@@Base-0x2b5a0>
  1cbed5:	eb 59                	jmp    1cbf30 <PyInit__clifft_core@@Base+0x17d870>
  1cbed7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1cbede:	00 00 
  1cbee0:	c5 fd 28 24 d0       	vmovapd ymm4,YMMWORD PTR [rax+rdx*8]
  1cbee5:	c5 fd 28 2c d1       	vmovapd ymm5,YMMWORD PTR [rcx+rdx*8]
  1cbeea:	41 83 e1 03          	and    r9d,0x3
  1cbeee:	41 c1 e1 05          	shl    r9d,0x5
  1cbef2:	c4 e2 7d 19 d2       	vbroadcastsd ymm2,xmm2
  1cbef7:	c4 81 6d 59 14 01    	vmulpd ymm2,ymm2,YMMWORD PTR [r9+r8*1]
  1cbefd:	c5 dd 59 f0          	vmulpd ymm6,ymm4,ymm0
  1cbf01:	c4 e2 ed b8 f5       	vfmadd231pd ymm6,ymm2,ymm5
  1cbf06:	c5 d5 59 e8          	vmulpd ymm5,ymm5,ymm0
  1cbf0a:	c4 e2 ed bc ec       	vfnmadd231pd ymm5,ymm2,ymm4
  1cbf0f:	c5 fd 29 34 d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm6
  1cbf14:	c5 fd 29 2c d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm5
  1cbf19:	48 83 c2 04          	add    rdx,0x4
  1cbf1d:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cbf22:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cbf27:	4d 85 c9             	test   r9,r9
  1cbf2a:	0f 85 05 04 00 00    	jne    1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cbf30:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cbf34:	4d 89 ca             	mov    r10,r9
  1cbf37:	49 21 d2             	and    r10,rdx
  1cbf3a:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cbf3f:	c5 f9 28 d3          	vmovapd xmm2,xmm3
  1cbf43:	41 f6 c2 01          	test   r10b,0x1
  1cbf47:	74 97                	je     1cbee0 <PyInit__clifft_core@@Base+0x17d820>
  1cbf49:	c5 f9 28 d1          	vmovapd xmm2,xmm1
  1cbf4d:	eb 91                	jmp    1cbee0 <PyInit__clifft_core@@Base+0x17d820>
  1cbf4f:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1cbf54:	48 8b 46 18          	mov    rax,QWORD PTR [rsi+0x18]
  1cbf58:	44 8b 4e 08          	mov    r9d,DWORD PTR [rsi+0x8]
  1cbf5c:	41 83 e1 03          	and    r9d,0x3
  1cbf60:	41 c1 e1 05          	shl    r9d,0x5
  1cbf64:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1cbf68:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1cbf6c:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
  1cbf70:	4c 8b 47 20          	mov    r8,QWORD PTR [rdi+0x20]
  1cbf74:	4c 8d 15 25 72 e5 ff 	lea    r10,[rip+0xffffffffffe57225]        # 231a0 <PyInit__clifft_core@@Base-0x2b520>
  1cbf7b:	c4 81 7d 28 0c 11    	vmovapd ymm1,YMMWORD PTR [r9+r10*1]
  1cbf81:	c4 e2 7d 19 56 30    	vbroadcastsd ymm2,QWORD PTR [rsi+0x30]
  1cbf87:	0f 84 ec 01 00 00    	je     1cc179 <PyInit__clifft_core@@Base+0x17dab9>
  1cbf8d:	48 85 c0             	test   rax,rax
  1cbf90:	0f 84 9f 03 00 00    	je     1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cbf96:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cbf9a:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cbf9f:	49 89 c1             	mov    r9,rax
  1cbfa2:	49 c1 e1 04          	shl    r9,0x4
  1cbfa6:	45 31 d2             	xor    r10d,r10d
  1cbfa9:	49 bb fc ff ff ff ff 	movabs r11,0x1ffffffffffffffc
  1cbfb0:	ff ff 1f 
  1cbfb3:	48 8d 1d 66 71 e5 ff 	lea    rbx,[rip+0xffffffffffe57166]        # 23120 <PyInit__clifft_core@@Base-0x2b5a0>
  1cbfba:	49 89 d6             	mov    r14,rdx
  1cbfbd:	4d 89 c7             	mov    r15,r8
  1cbfc0:	eb 2c                	jmp    1cbfee <PyInit__clifft_core@@Base+0x17d92e>
  1cbfc2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cbfc9:	1f 84 00 00 00 00 00 
  1cbfd0:	49 01 c2             	add    r10,rax
  1cbfd3:	49 01 c2             	add    r10,rax
  1cbfd6:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1cbfda:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1cbfdf:	4d 01 cf             	add    r15,r9
  1cbfe2:	4d 01 ce             	add    r14,r9
  1cbfe5:	48 85 c9             	test   rcx,rcx
  1cbfe8:	0f 85 47 03 00 00    	jne    1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cbfee:	45 31 e4             	xor    r12d,r12d
  1cbff1:	e9 8c 00 00 00       	jmp    1cc082 <PyInit__clifft_core@@Base+0x17d9c2>
  1cbff6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1cbffd:	00 00 00 
  1cc000:	4c 33 6e 08          	xor    r13,QWORD PTR [rsi+0x8]
  1cc004:	4d 21 dd             	and    r13,r11
  1cc007:	c4 81 7d 28 2c e6    	vmovapd ymm5,YMMWORD PTR [r14+r12*8]
  1cc00d:	c4 a2 75 16 34 ea    	vpermps ymm6,ymm1,YMMWORD PTR [rdx+r13*8]
  1cc013:	c4 81 7d 28 3c e7    	vmovapd ymm7,YMMWORD PTR [r15+r12*8]
  1cc019:	c4 02 75 16 04 e8    	vpermps ymm8,ymm1,YMMWORD PTR [r8+r13*8]
  1cc01f:	83 e1 03             	and    ecx,0x3
  1cc022:	c1 e1 05             	shl    ecx,0x5
  1cc025:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1cc02a:	c5 e5 59 1c 19       	vmulpd ymm3,ymm3,YMMWORD PTR [rcx+rbx*1]
  1cc02f:	c5 55 59 ca          	vmulpd ymm9,ymm5,ymm2
  1cc033:	c4 42 e5 b8 c8       	vfmadd231pd ymm9,ymm3,ymm8
  1cc038:	c5 45 59 d2          	vmulpd ymm10,ymm7,ymm2
  1cc03c:	c4 62 e5 bc d6       	vfnmadd231pd ymm10,ymm3,ymm6
  1cc041:	c5 ed 59 f6          	vmulpd ymm6,ymm2,ymm6
  1cc045:	c4 e2 e5 b8 f7       	vfmadd231pd ymm6,ymm3,ymm7
  1cc04a:	c5 bd 59 fa          	vmulpd ymm7,ymm8,ymm2
  1cc04e:	c4 e2 e5 bc fd       	vfnmadd231pd ymm7,ymm3,ymm5
  1cc053:	c4 01 7d 29 0c e6    	vmovapd YMMWORD PTR [r14+r12*8],ymm9
  1cc059:	c4 01 7d 29 14 e7    	vmovapd YMMWORD PTR [r15+r12*8],ymm10
  1cc05f:	c4 e2 75 16 de       	vpermps ymm3,ymm1,ymm6
  1cc064:	c4 a1 7d 29 1c ea    	vmovapd YMMWORD PTR [rdx+r13*8],ymm3
  1cc06a:	c4 e2 75 16 df       	vpermps ymm3,ymm1,ymm7
  1cc06f:	c4 81 7d 29 1c e8    	vmovapd YMMWORD PTR [r8+r13*8],ymm3
  1cc075:	49 83 c4 04          	add    r12,0x4
  1cc079:	49 39 c4             	cmp    r12,rax
  1cc07c:	0f 83 4e ff ff ff    	jae    1cbfd0 <PyInit__clifft_core@@Base+0x17d910>
  1cc082:	4f 8d 2c 22          	lea    r13,[r10+r12*1]
  1cc086:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1cc08a:	48 89 cd             	mov    rbp,rcx
  1cc08d:	4c 21 ed             	and    rbp,r13
  1cc090:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1cc095:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1cc099:	40 f6 c5 01          	test   bpl,0x1
  1cc09d:	0f 84 5d ff ff ff    	je     1cc000 <PyInit__clifft_core@@Base+0x17d940>
  1cc0a3:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1cc0a7:	e9 54 ff ff ff       	jmp    1cc000 <PyInit__clifft_core@@Base+0x17d940>
  1cc0ac:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1cc0b1:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1cc0b4:	83 e2 03             	and    edx,0x3
  1cc0b7:	c1 e2 05             	shl    edx,0x5
  1cc0ba:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1cc0be:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1cc0c2:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1cc0c6:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1cc0ca:	4c 8d 05 cf 70 e5 ff 	lea    r8,[rip+0xffffffffffe570cf]        # 231a0 <PyInit__clifft_core@@Base-0x2b520>
  1cc0d1:	c4 a1 7d 28 0c 02    	vmovapd ymm1,YMMWORD PTR [rdx+r8*1]
  1cc0d7:	c4 e2 7d 19 56 30    	vbroadcastsd ymm2,QWORD PTR [rsi+0x30]
  1cc0dd:	0f 84 b9 01 00 00    	je     1cc29c <PyInit__clifft_core@@Base+0x17dbdc>
  1cc0e3:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cc0e7:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cc0ec:	31 d2                	xor    edx,edx
  1cc0ee:	4c 8d 05 2b 70 e5 ff 	lea    r8,[rip+0xffffffffffe5702b]        # 23120 <PyInit__clifft_core@@Base-0x2b5a0>
  1cc0f5:	eb 63                	jmp    1cc15a <PyInit__clifft_core@@Base+0x17da9a>
  1cc0f7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1cc0fe:	00 00 
  1cc100:	c5 fd 28 2c d0       	vmovapd ymm5,YMMWORD PTR [rax+rdx*8]
  1cc105:	c5 fd 28 34 d1       	vmovapd ymm6,YMMWORD PTR [rcx+rdx*8]
  1cc10a:	c4 e2 75 16 fd       	vpermps ymm7,ymm1,ymm5
  1cc10f:	c4 62 75 16 c6       	vpermps ymm8,ymm1,ymm6
  1cc114:	41 83 e1 03          	and    r9d,0x3
  1cc118:	41 c1 e1 05          	shl    r9d,0x5
  1cc11c:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1cc121:	c4 81 65 59 1c 01    	vmulpd ymm3,ymm3,YMMWORD PTR [r9+r8*1]
  1cc127:	c5 d5 59 ea          	vmulpd ymm5,ymm5,ymm2
  1cc12b:	c4 c2 e5 b8 e8       	vfmadd231pd ymm5,ymm3,ymm8
  1cc130:	c5 cd 59 f2          	vmulpd ymm6,ymm6,ymm2
  1cc134:	c4 e2 e5 bc f7       	vfnmadd231pd ymm6,ymm3,ymm7
  1cc139:	c5 fd 29 2c d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm5
  1cc13e:	c5 fd 29 34 d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm6
  1cc143:	48 83 c2 04          	add    rdx,0x4
  1cc147:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cc14c:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cc151:	4d 85 c9             	test   r9,r9
  1cc154:	0f 85 db 01 00 00    	jne    1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cc15a:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cc15e:	4d 89 ca             	mov    r10,r9
  1cc161:	49 21 d2             	and    r10,rdx
  1cc164:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cc169:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1cc16d:	41 f6 c2 01          	test   r10b,0x1
  1cc171:	74 8d                	je     1cc100 <PyInit__clifft_core@@Base+0x17da40>
  1cc173:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1cc177:	eb 87                	jmp    1cc100 <PyInit__clifft_core@@Base+0x17da40>
  1cc179:	48 85 c0             	test   rax,rax
  1cc17c:	0f 84 b3 01 00 00    	je     1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cc182:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1cc187:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cc18b:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cc190:	49 89 c1             	mov    r9,rax
  1cc193:	49 c1 e1 04          	shl    r9,0x4
  1cc197:	45 31 d2             	xor    r10d,r10d
  1cc19a:	49 bb fc ff ff ff ff 	movabs r11,0x1ffffffffffffffc
  1cc1a1:	ff ff 1f 
  1cc1a4:	48 8d 1d 75 6f e5 ff 	lea    rbx,[rip+0xffffffffffe56f75]        # 23120 <PyInit__clifft_core@@Base-0x2b5a0>
  1cc1ab:	49 89 d6             	mov    r14,rdx
  1cc1ae:	4d 89 c7             	mov    r15,r8
  1cc1b1:	eb 2b                	jmp    1cc1de <PyInit__clifft_core@@Base+0x17db1e>
  1cc1b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cc1ba:	84 00 00 00 00 00 
  1cc1c0:	49 01 c2             	add    r10,rax
  1cc1c3:	49 01 c2             	add    r10,rax
  1cc1c6:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1cc1ca:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1cc1cf:	4d 01 cf             	add    r15,r9
  1cc1d2:	4d 01 ce             	add    r14,r9
  1cc1d5:	48 85 c9             	test   rcx,rcx
  1cc1d8:	0f 85 57 01 00 00    	jne    1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cc1de:	45 31 e4             	xor    r12d,r12d
  1cc1e1:	e9 8d 00 00 00       	jmp    1cc273 <PyInit__clifft_core@@Base+0x17dbb3>
  1cc1e6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1cc1ed:	00 00 00 
  1cc1f0:	4c 33 6e 08          	xor    r13,QWORD PTR [rsi+0x8]
  1cc1f4:	4d 21 dd             	and    r13,r11
  1cc1f7:	c4 81 7d 28 2c e6    	vmovapd ymm5,YMMWORD PTR [r14+r12*8]
  1cc1fd:	c4 a2 75 16 34 ea    	vpermps ymm6,ymm1,YMMWORD PTR [rdx+r13*8]
  1cc203:	c4 81 7d 28 3c e7    	vmovapd ymm7,YMMWORD PTR [r15+r12*8]
  1cc209:	c4 02 75 16 04 e8    	vpermps ymm8,ymm1,YMMWORD PTR [r8+r13*8]
  1cc20f:	83 e5 03             	and    ebp,0x3
  1cc212:	c1 e5 05             	shl    ebp,0x5
  1cc215:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1cc21a:	c5 e5 59 5c 1d 00    	vmulpd ymm3,ymm3,YMMWORD PTR [rbp+rbx*1+0x0]
  1cc220:	c5 55 59 ca          	vmulpd ymm9,ymm5,ymm2
  1cc224:	c4 62 e5 bc ce       	vfnmadd231pd ymm9,ymm3,ymm6
  1cc229:	c5 45 59 d2          	vmulpd ymm10,ymm7,ymm2
  1cc22d:	c4 42 e5 bc d0       	vfnmadd231pd ymm10,ymm3,ymm8
  1cc232:	c5 ed 59 f6          	vmulpd ymm6,ymm2,ymm6
  1cc236:	c4 e2 e5 b8 f5       	vfmadd231pd ymm6,ymm3,ymm5
  1cc23b:	c5 bd 59 ea          	vmulpd ymm5,ymm8,ymm2
  1cc23f:	c4 e2 e5 b8 ef       	vfmadd231pd ymm5,ymm3,ymm7
  1cc244:	c4 01 7d 29 0c e6    	vmovapd YMMWORD PTR [r14+r12*8],ymm9
  1cc24a:	c4 01 7d 29 14 e7    	vmovapd YMMWORD PTR [r15+r12*8],ymm10
  1cc250:	c4 e2 75 16 de       	vpermps ymm3,ymm1,ymm6
  1cc255:	c4 a1 7d 29 1c ea    	vmovapd YMMWORD PTR [rdx+r13*8],ymm3
  1cc25b:	c4 e2 75 16 dd       	vpermps ymm3,ymm1,ymm5
  1cc260:	c4 81 7d 29 1c e8    	vmovapd YMMWORD PTR [r8+r13*8],ymm3
  1cc266:	49 83 c4 04          	add    r12,0x4
  1cc26a:	49 39 c4             	cmp    r12,rax
  1cc26d:	0f 83 4d ff ff ff    	jae    1cc1c0 <PyInit__clifft_core@@Base+0x17db00>
  1cc273:	4f 8d 2c 22          	lea    r13,[r10+r12*1]
  1cc277:	48 8b 6e 10          	mov    rbp,QWORD PTR [rsi+0x10]
  1cc27b:	48 89 e9             	mov    rcx,rbp
  1cc27e:	4c 21 e9             	and    rcx,r13
  1cc281:	f3 48 0f b8 c9       	popcnt rcx,rcx
  1cc286:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1cc28a:	f6 c1 01             	test   cl,0x1
  1cc28d:	0f 84 5d ff ff ff    	je     1cc1f0 <PyInit__clifft_core@@Base+0x17db30>
  1cc293:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1cc297:	e9 54 ff ff ff       	jmp    1cc1f0 <PyInit__clifft_core@@Base+0x17db30>
  1cc29c:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1cc2a1:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cc2a5:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cc2aa:	31 d2                	xor    edx,edx
  1cc2ac:	4c 8d 05 6d 6e e5 ff 	lea    r8,[rip+0xffffffffffe56e6d]        # 23120 <PyInit__clifft_core@@Base-0x2b5a0>
  1cc2b3:	eb 61                	jmp    1cc316 <PyInit__clifft_core@@Base+0x17dc56>
  1cc2b5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cc2bc:	00 00 00 00 
  1cc2c0:	c5 fd 28 2c d0       	vmovapd ymm5,YMMWORD PTR [rax+rdx*8]
  1cc2c5:	c5 fd 28 34 d1       	vmovapd ymm6,YMMWORD PTR [rcx+rdx*8]
  1cc2ca:	c4 e2 75 16 fd       	vpermps ymm7,ymm1,ymm5
  1cc2cf:	c4 62 75 16 c6       	vpermps ymm8,ymm1,ymm6
  1cc2d4:	41 83 e1 03          	and    r9d,0x3
  1cc2d8:	41 c1 e1 05          	shl    r9d,0x5
  1cc2dc:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1cc2e1:	c4 81 65 59 1c 01    	vmulpd ymm3,ymm3,YMMWORD PTR [r9+r8*1]
  1cc2e7:	c5 d5 59 ea          	vmulpd ymm5,ymm5,ymm2
  1cc2eb:	c4 e2 e5 b8 ef       	vfmadd231pd ymm5,ymm3,ymm7
  1cc2f0:	c5 cd 59 f2          	vmulpd ymm6,ymm6,ymm2
  1cc2f4:	c4 c2 e5 b8 f0       	vfmadd231pd ymm6,ymm3,ymm8
  1cc2f9:	c5 fd 29 2c d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm5
  1cc2fe:	c5 fd 29 34 d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm6
  1cc303:	48 83 c2 04          	add    rdx,0x4
  1cc307:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cc30c:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cc311:	4d 85 c9             	test   r9,r9
  1cc314:	75 1f                	jne    1cc335 <PyInit__clifft_core@@Base+0x17dc75>
  1cc316:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cc31a:	4d 89 ca             	mov    r10,r9
  1cc31d:	49 21 d2             	and    r10,rdx
  1cc320:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cc325:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1cc329:	41 f6 c2 01          	test   r10b,0x1
  1cc32d:	74 91                	je     1cc2c0 <PyInit__clifft_core@@Base+0x17dc00>
  1cc32f:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1cc333:	eb 8b                	jmp    1cc2c0 <PyInit__clifft_core@@Base+0x17dc00>
  1cc335:	5b                   	pop    rbx
  1cc336:	41 5c                	pop    r12
  1cc338:	41 5d                	pop    r13
  1cc33a:	41 5e                	pop    r14
  1cc33c:	41 5f                	pop    r15
  1cc33e:	5d                   	pop    rbp
  1cc33f:	c5 f8 77             	vzeroupper
  1cc342:	c3                   	ret
