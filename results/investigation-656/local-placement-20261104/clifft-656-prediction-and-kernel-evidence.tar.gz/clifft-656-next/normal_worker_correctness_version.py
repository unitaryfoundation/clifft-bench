"""Normal-build diagnostic using pinned adapter preparation and output semantics."""
import hashlib,json,os,resource,sys,time
from pathlib import Path
from clifft_bench.adapters.clifft import ClifftAdapter
from clifft_bench.system import apply_affinity,apply_address_space_limit
import clifft


def emit(value):
    print(json.dumps(value),flush=True)


def digest_array(value):
    if value is None:return None
    return dict(shape=list(value.shape),dtype=str(value.dtype),sha256=hashlib.sha256(value.tobytes()).hexdigest())


prepared=None
for line in sys.stdin:
    request=json.loads(line)
    if request['command']=='prepare':
        assert apply_affinity(0)['applied']
        apply_address_space_limit(12)
        case=request['case']
        prepared=ClifftAdapter().prepare(artifact_path=Path(request['artifact']),workload=case['workload'],execution={'batch_size':request['batch_size'],'options':case['execution']['options']})
        extension=Path(clifft._clifft_core.__file__)
        prepared.sample(1,20260818)
        emit(dict(ok=True,metadata=prepared.runtime_metadata,extension=str(extension),extension_sha256=hashlib.sha256(extension.read_bytes()).hexdigest(),pid=os.getpid()))
    elif request['command']=='sample':
        totals=[0,0,0,0];elapsed=0.0;cpu=time.process_time()
        for index in range(request['calls']):
            start=time.perf_counter()
            counts=prepared.sample(request['shots'],20270819+index)
            elapsed+=time.perf_counter()-start
            values=counts.as_dict()
            assert values['attempted_shots']==values['accepted_shots']+values['discarded_shots']
            for n,key in enumerate(['attempted_shots','accepted_shots','discarded_shots','logical_errors']):totals[n]+=values[key]
        emit(dict(ok=True,totals=totals,seconds=elapsed,cpu_seconds=time.process_time()-cpu,peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024))
    elif request['command']=='correctness':
        rows=[]
        for batch in sorted(set([1,prepared._batch_size])):
            for seed in [20260819,20270819,1234567]:
                result=clifft.sample_survivors(prepared._program,request['shots'],seed=seed,keep_records=True,threads=1,batch_size=batch)
                rows.append(dict(batch=batch,seed=seed,total=result.total_shots,passed=result.passed_shots,discards=result.discards,arrays={key:digest_array(getattr(result,key)) for key in ['measurements','detectors','observables','observable_ones','exp_vals']}))
        emit(dict(ok=True,rows=rows))
    else:raise ValueError(request)
