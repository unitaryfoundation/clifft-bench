
/tmp/clifft-656-next/candidate-16/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001c0ae0 <PyInit__clifft_core@@Base+0x1724c0>:
  1c0ae0:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1c0ae5:	85 c9                	test   ecx,ecx
  1c0ae7:	74 08                	je     1c0af1 <PyInit__clifft_core@@Base+0x1724d1>
  1c0ae9:	c5 e1 57 1d 2f ce e4 	vxorpd xmm3,xmm3,XMMWORD PTR [rip+0xffffffffffe4ce2f]        # d920 <PyInit__clifft_core@@Base-0x40d00>
  1c0af0:	ff 
  1c0af1:	55                   	push   rbp
  1c0af2:	41 57                	push   r15
  1c0af4:	41 56                	push   r14
  1c0af6:	41 55                	push   r13
  1c0af8:	41 54                	push   r12
  1c0afa:	53                   	push   rbx
  1c0afb:	83 fa 03             	cmp    edx,0x3
  1c0afe:	0f 84 08 02 00 00    	je     1c0d0c <PyInit__clifft_core@@Base+0x1726ec>
  1c0b04:	83 fa 02             	cmp    edx,0x2
  1c0b07:	0f 84 a2 00 00 00    	je     1c0baf <PyInit__clifft_core@@Base+0x17258f>
  1c0b0d:	83 fa 01             	cmp    edx,0x1
  1c0b10:	0f 85 7f 04 00 00    	jne    1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0b16:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c0b1a:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c0b1e:	c4 e2 7d 19 46 30    	vbroadcastsd ymm0,QWORD PTR [rsi+0x30]
  1c0b24:	c5 e1 57 0d f4 cd e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe4cdf4]        # d920 <PyInit__clifft_core@@Base-0x40d00>
  1c0b2b:	ff 
  1c0b2c:	31 d2                	xor    edx,edx
  1c0b2e:	4c 8d 05 eb 25 e6 ff 	lea    r8,[rip+0xffffffffffe625eb]        # 23120 <PyInit__clifft_core@@Base-0x2b500>
  1c0b35:	eb 59                	jmp    1c0b90 <PyInit__clifft_core@@Base+0x172570>
  1c0b37:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1c0b3e:	00 00 
  1c0b40:	c5 fd 28 24 d0       	vmovapd ymm4,YMMWORD PTR [rax+rdx*8]
  1c0b45:	c5 fd 28 2c d1       	vmovapd ymm5,YMMWORD PTR [rcx+rdx*8]
  1c0b4a:	41 83 e1 03          	and    r9d,0x3
  1c0b4e:	41 c1 e1 05          	shl    r9d,0x5
  1c0b52:	c4 e2 7d 19 d2       	vbroadcastsd ymm2,xmm2
  1c0b57:	c4 81 6d 59 14 01    	vmulpd ymm2,ymm2,YMMWORD PTR [r9+r8*1]
  1c0b5d:	c5 dd 59 f0          	vmulpd ymm6,ymm4,ymm0
  1c0b61:	c4 e2 ed b8 f5       	vfmadd231pd ymm6,ymm2,ymm5
  1c0b66:	c5 d5 59 e8          	vmulpd ymm5,ymm5,ymm0
  1c0b6a:	c4 e2 ed bc ec       	vfnmadd231pd ymm5,ymm2,ymm4
  1c0b6f:	c5 fd 29 34 d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm6
  1c0b74:	c5 fd 29 2c d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm5
  1c0b79:	48 83 c2 04          	add    rdx,0x4
  1c0b7d:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c0b82:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c0b87:	4d 85 c9             	test   r9,r9
  1c0b8a:	0f 85 05 04 00 00    	jne    1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0b90:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c0b94:	4d 89 ca             	mov    r10,r9
  1c0b97:	49 21 d2             	and    r10,rdx
  1c0b9a:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c0b9f:	c5 f9 28 d3          	vmovapd xmm2,xmm3
  1c0ba3:	41 f6 c2 01          	test   r10b,0x1
  1c0ba7:	74 97                	je     1c0b40 <PyInit__clifft_core@@Base+0x172520>
  1c0ba9:	c5 f9 28 d1          	vmovapd xmm2,xmm1
  1c0bad:	eb 91                	jmp    1c0b40 <PyInit__clifft_core@@Base+0x172520>
  1c0baf:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c0bb4:	48 8b 46 18          	mov    rax,QWORD PTR [rsi+0x18]
  1c0bb8:	44 8b 4e 08          	mov    r9d,DWORD PTR [rsi+0x8]
  1c0bbc:	41 83 e1 03          	and    r9d,0x3
  1c0bc0:	41 c1 e1 05          	shl    r9d,0x5
  1c0bc4:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c0bc8:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c0bcc:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
  1c0bd0:	4c 8b 47 20          	mov    r8,QWORD PTR [rdi+0x20]
  1c0bd4:	4c 8d 15 c5 25 e6 ff 	lea    r10,[rip+0xffffffffffe625c5]        # 231a0 <PyInit__clifft_core@@Base-0x2b480>
  1c0bdb:	c4 81 7d 28 0c 11    	vmovapd ymm1,YMMWORD PTR [r9+r10*1]
  1c0be1:	c4 e2 7d 19 56 30    	vbroadcastsd ymm2,QWORD PTR [rsi+0x30]
  1c0be7:	0f 84 ec 01 00 00    	je     1c0dd9 <PyInit__clifft_core@@Base+0x1727b9>
  1c0bed:	48 85 c0             	test   rax,rax
  1c0bf0:	0f 84 9f 03 00 00    	je     1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0bf6:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c0bfa:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c0bff:	49 89 c1             	mov    r9,rax
  1c0c02:	49 c1 e1 04          	shl    r9,0x4
  1c0c06:	45 31 d2             	xor    r10d,r10d
  1c0c09:	49 bb fc ff ff ff ff 	movabs r11,0x1ffffffffffffffc
  1c0c10:	ff ff 1f 
  1c0c13:	48 8d 1d 06 25 e6 ff 	lea    rbx,[rip+0xffffffffffe62506]        # 23120 <PyInit__clifft_core@@Base-0x2b500>
  1c0c1a:	49 89 d6             	mov    r14,rdx
  1c0c1d:	4d 89 c7             	mov    r15,r8
  1c0c20:	eb 2c                	jmp    1c0c4e <PyInit__clifft_core@@Base+0x17262e>
  1c0c22:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c0c29:	1f 84 00 00 00 00 00 
  1c0c30:	49 01 c2             	add    r10,rax
  1c0c33:	49 01 c2             	add    r10,rax
  1c0c36:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c0c3a:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c0c3f:	4d 01 cf             	add    r15,r9
  1c0c42:	4d 01 ce             	add    r14,r9
  1c0c45:	48 85 c9             	test   rcx,rcx
  1c0c48:	0f 85 47 03 00 00    	jne    1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0c4e:	45 31 e4             	xor    r12d,r12d
  1c0c51:	e9 8c 00 00 00       	jmp    1c0ce2 <PyInit__clifft_core@@Base+0x1726c2>
  1c0c56:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c0c5d:	00 00 00 
  1c0c60:	4c 33 6e 08          	xor    r13,QWORD PTR [rsi+0x8]
  1c0c64:	4d 21 dd             	and    r13,r11
  1c0c67:	c4 81 7d 28 2c e6    	vmovapd ymm5,YMMWORD PTR [r14+r12*8]
  1c0c6d:	c4 a2 75 16 34 ea    	vpermps ymm6,ymm1,YMMWORD PTR [rdx+r13*8]
  1c0c73:	c4 81 7d 28 3c e7    	vmovapd ymm7,YMMWORD PTR [r15+r12*8]
  1c0c79:	c4 02 75 16 04 e8    	vpermps ymm8,ymm1,YMMWORD PTR [r8+r13*8]
  1c0c7f:	83 e1 03             	and    ecx,0x3
  1c0c82:	c1 e1 05             	shl    ecx,0x5
  1c0c85:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c0c8a:	c5 e5 59 1c 19       	vmulpd ymm3,ymm3,YMMWORD PTR [rcx+rbx*1]
  1c0c8f:	c5 55 59 ca          	vmulpd ymm9,ymm5,ymm2
  1c0c93:	c4 42 e5 b8 c8       	vfmadd231pd ymm9,ymm3,ymm8
  1c0c98:	c5 45 59 d2          	vmulpd ymm10,ymm7,ymm2
  1c0c9c:	c4 62 e5 bc d6       	vfnmadd231pd ymm10,ymm3,ymm6
  1c0ca1:	c5 ed 59 f6          	vmulpd ymm6,ymm2,ymm6
  1c0ca5:	c4 e2 e5 b8 f7       	vfmadd231pd ymm6,ymm3,ymm7
  1c0caa:	c5 bd 59 fa          	vmulpd ymm7,ymm8,ymm2
  1c0cae:	c4 e2 e5 bc fd       	vfnmadd231pd ymm7,ymm3,ymm5
  1c0cb3:	c4 01 7d 29 0c e6    	vmovapd YMMWORD PTR [r14+r12*8],ymm9
  1c0cb9:	c4 01 7d 29 14 e7    	vmovapd YMMWORD PTR [r15+r12*8],ymm10
  1c0cbf:	c4 e2 75 16 de       	vpermps ymm3,ymm1,ymm6
  1c0cc4:	c4 a1 7d 29 1c ea    	vmovapd YMMWORD PTR [rdx+r13*8],ymm3
  1c0cca:	c4 e2 75 16 df       	vpermps ymm3,ymm1,ymm7
  1c0ccf:	c4 81 7d 29 1c e8    	vmovapd YMMWORD PTR [r8+r13*8],ymm3
  1c0cd5:	49 83 c4 04          	add    r12,0x4
  1c0cd9:	49 39 c4             	cmp    r12,rax
  1c0cdc:	0f 83 4e ff ff ff    	jae    1c0c30 <PyInit__clifft_core@@Base+0x172610>
  1c0ce2:	4f 8d 2c 22          	lea    r13,[r10+r12*1]
  1c0ce6:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1c0cea:	48 89 cd             	mov    rbp,rcx
  1c0ced:	4c 21 ed             	and    rbp,r13
  1c0cf0:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c0cf5:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c0cf9:	40 f6 c5 01          	test   bpl,0x1
  1c0cfd:	0f 84 5d ff ff ff    	je     1c0c60 <PyInit__clifft_core@@Base+0x172640>
  1c0d03:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c0d07:	e9 54 ff ff ff       	jmp    1c0c60 <PyInit__clifft_core@@Base+0x172640>
  1c0d0c:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c0d11:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1c0d14:	83 e2 03             	and    edx,0x3
  1c0d17:	c1 e2 05             	shl    edx,0x5
  1c0d1a:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c0d1e:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c0d22:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c0d26:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c0d2a:	4c 8d 05 6f 24 e6 ff 	lea    r8,[rip+0xffffffffffe6246f]        # 231a0 <PyInit__clifft_core@@Base-0x2b480>
  1c0d31:	c4 a1 7d 28 0c 02    	vmovapd ymm1,YMMWORD PTR [rdx+r8*1]
  1c0d37:	c4 e2 7d 19 56 30    	vbroadcastsd ymm2,QWORD PTR [rsi+0x30]
  1c0d3d:	0f 84 b9 01 00 00    	je     1c0efc <PyInit__clifft_core@@Base+0x1728dc>
  1c0d43:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c0d47:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c0d4c:	31 d2                	xor    edx,edx
  1c0d4e:	4c 8d 05 cb 23 e6 ff 	lea    r8,[rip+0xffffffffffe623cb]        # 23120 <PyInit__clifft_core@@Base-0x2b500>
  1c0d55:	eb 63                	jmp    1c0dba <PyInit__clifft_core@@Base+0x17279a>
  1c0d57:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1c0d5e:	00 00 
  1c0d60:	c5 fd 28 2c d0       	vmovapd ymm5,YMMWORD PTR [rax+rdx*8]
  1c0d65:	c5 fd 28 34 d1       	vmovapd ymm6,YMMWORD PTR [rcx+rdx*8]
  1c0d6a:	c4 e2 75 16 fd       	vpermps ymm7,ymm1,ymm5
  1c0d6f:	c4 62 75 16 c6       	vpermps ymm8,ymm1,ymm6
  1c0d74:	41 83 e1 03          	and    r9d,0x3
  1c0d78:	41 c1 e1 05          	shl    r9d,0x5
  1c0d7c:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c0d81:	c4 81 65 59 1c 01    	vmulpd ymm3,ymm3,YMMWORD PTR [r9+r8*1]
  1c0d87:	c5 d5 59 ea          	vmulpd ymm5,ymm5,ymm2
  1c0d8b:	c4 c2 e5 b8 e8       	vfmadd231pd ymm5,ymm3,ymm8
  1c0d90:	c5 cd 59 f2          	vmulpd ymm6,ymm6,ymm2
  1c0d94:	c4 e2 e5 bc f7       	vfnmadd231pd ymm6,ymm3,ymm7
  1c0d99:	c5 fd 29 2c d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm5
  1c0d9e:	c5 fd 29 34 d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm6
  1c0da3:	48 83 c2 04          	add    rdx,0x4
  1c0da7:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c0dac:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c0db1:	4d 85 c9             	test   r9,r9
  1c0db4:	0f 85 db 01 00 00    	jne    1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0dba:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c0dbe:	4d 89 ca             	mov    r10,r9
  1c0dc1:	49 21 d2             	and    r10,rdx
  1c0dc4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c0dc9:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c0dcd:	41 f6 c2 01          	test   r10b,0x1
  1c0dd1:	74 8d                	je     1c0d60 <PyInit__clifft_core@@Base+0x172740>
  1c0dd3:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c0dd7:	eb 87                	jmp    1c0d60 <PyInit__clifft_core@@Base+0x172740>
  1c0dd9:	48 85 c0             	test   rax,rax
  1c0ddc:	0f 84 b3 01 00 00    	je     1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0de2:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c0de7:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c0deb:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c0df0:	49 89 c1             	mov    r9,rax
  1c0df3:	49 c1 e1 04          	shl    r9,0x4
  1c0df7:	45 31 d2             	xor    r10d,r10d
  1c0dfa:	49 bb fc ff ff ff ff 	movabs r11,0x1ffffffffffffffc
  1c0e01:	ff ff 1f 
  1c0e04:	48 8d 1d 15 23 e6 ff 	lea    rbx,[rip+0xffffffffffe62315]        # 23120 <PyInit__clifft_core@@Base-0x2b500>
  1c0e0b:	49 89 d6             	mov    r14,rdx
  1c0e0e:	4d 89 c7             	mov    r15,r8
  1c0e11:	eb 2b                	jmp    1c0e3e <PyInit__clifft_core@@Base+0x17281e>
  1c0e13:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c0e1a:	84 00 00 00 00 00 
  1c0e20:	49 01 c2             	add    r10,rax
  1c0e23:	49 01 c2             	add    r10,rax
  1c0e26:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c0e2a:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c0e2f:	4d 01 cf             	add    r15,r9
  1c0e32:	4d 01 ce             	add    r14,r9
  1c0e35:	48 85 c9             	test   rcx,rcx
  1c0e38:	0f 85 57 01 00 00    	jne    1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0e3e:	45 31 e4             	xor    r12d,r12d
  1c0e41:	e9 8d 00 00 00       	jmp    1c0ed3 <PyInit__clifft_core@@Base+0x1728b3>
  1c0e46:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c0e4d:	00 00 00 
  1c0e50:	4c 33 6e 08          	xor    r13,QWORD PTR [rsi+0x8]
  1c0e54:	4d 21 dd             	and    r13,r11
  1c0e57:	c4 81 7d 28 2c e6    	vmovapd ymm5,YMMWORD PTR [r14+r12*8]
  1c0e5d:	c4 a2 75 16 34 ea    	vpermps ymm6,ymm1,YMMWORD PTR [rdx+r13*8]
  1c0e63:	c4 81 7d 28 3c e7    	vmovapd ymm7,YMMWORD PTR [r15+r12*8]
  1c0e69:	c4 02 75 16 04 e8    	vpermps ymm8,ymm1,YMMWORD PTR [r8+r13*8]
  1c0e6f:	83 e5 03             	and    ebp,0x3
  1c0e72:	c1 e5 05             	shl    ebp,0x5
  1c0e75:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c0e7a:	c5 e5 59 5c 1d 00    	vmulpd ymm3,ymm3,YMMWORD PTR [rbp+rbx*1+0x0]
  1c0e80:	c5 55 59 ca          	vmulpd ymm9,ymm5,ymm2
  1c0e84:	c4 62 e5 bc ce       	vfnmadd231pd ymm9,ymm3,ymm6
  1c0e89:	c5 45 59 d2          	vmulpd ymm10,ymm7,ymm2
  1c0e8d:	c4 42 e5 bc d0       	vfnmadd231pd ymm10,ymm3,ymm8
  1c0e92:	c5 ed 59 f6          	vmulpd ymm6,ymm2,ymm6
  1c0e96:	c4 e2 e5 b8 f5       	vfmadd231pd ymm6,ymm3,ymm5
  1c0e9b:	c5 bd 59 ea          	vmulpd ymm5,ymm8,ymm2
  1c0e9f:	c4 e2 e5 b8 ef       	vfmadd231pd ymm5,ymm3,ymm7
  1c0ea4:	c4 01 7d 29 0c e6    	vmovapd YMMWORD PTR [r14+r12*8],ymm9
  1c0eaa:	c4 01 7d 29 14 e7    	vmovapd YMMWORD PTR [r15+r12*8],ymm10
  1c0eb0:	c4 e2 75 16 de       	vpermps ymm3,ymm1,ymm6
  1c0eb5:	c4 a1 7d 29 1c ea    	vmovapd YMMWORD PTR [rdx+r13*8],ymm3
  1c0ebb:	c4 e2 75 16 dd       	vpermps ymm3,ymm1,ymm5
  1c0ec0:	c4 81 7d 29 1c e8    	vmovapd YMMWORD PTR [r8+r13*8],ymm3
  1c0ec6:	49 83 c4 04          	add    r12,0x4
  1c0eca:	49 39 c4             	cmp    r12,rax
  1c0ecd:	0f 83 4d ff ff ff    	jae    1c0e20 <PyInit__clifft_core@@Base+0x172800>
  1c0ed3:	4f 8d 2c 22          	lea    r13,[r10+r12*1]
  1c0ed7:	48 8b 6e 10          	mov    rbp,QWORD PTR [rsi+0x10]
  1c0edb:	48 89 e9             	mov    rcx,rbp
  1c0ede:	4c 21 e9             	and    rcx,r13
  1c0ee1:	f3 48 0f b8 c9       	popcnt rcx,rcx
  1c0ee6:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c0eea:	f6 c1 01             	test   cl,0x1
  1c0eed:	0f 84 5d ff ff ff    	je     1c0e50 <PyInit__clifft_core@@Base+0x172830>
  1c0ef3:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c0ef7:	e9 54 ff ff ff       	jmp    1c0e50 <PyInit__clifft_core@@Base+0x172830>
  1c0efc:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c0f01:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c0f05:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c0f0a:	31 d2                	xor    edx,edx
  1c0f0c:	4c 8d 05 0d 22 e6 ff 	lea    r8,[rip+0xffffffffffe6220d]        # 23120 <PyInit__clifft_core@@Base-0x2b500>
  1c0f13:	eb 61                	jmp    1c0f76 <PyInit__clifft_core@@Base+0x172956>
  1c0f15:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c0f1c:	00 00 00 00 
  1c0f20:	c5 fd 28 2c d0       	vmovapd ymm5,YMMWORD PTR [rax+rdx*8]
  1c0f25:	c5 fd 28 34 d1       	vmovapd ymm6,YMMWORD PTR [rcx+rdx*8]
  1c0f2a:	c4 e2 75 16 fd       	vpermps ymm7,ymm1,ymm5
  1c0f2f:	c4 62 75 16 c6       	vpermps ymm8,ymm1,ymm6
  1c0f34:	41 83 e1 03          	and    r9d,0x3
  1c0f38:	41 c1 e1 05          	shl    r9d,0x5
  1c0f3c:	c4 e2 7d 19 db       	vbroadcastsd ymm3,xmm3
  1c0f41:	c4 81 65 59 1c 01    	vmulpd ymm3,ymm3,YMMWORD PTR [r9+r8*1]
  1c0f47:	c5 d5 59 ea          	vmulpd ymm5,ymm5,ymm2
  1c0f4b:	c4 e2 e5 b8 ef       	vfmadd231pd ymm5,ymm3,ymm7
  1c0f50:	c5 cd 59 f2          	vmulpd ymm6,ymm6,ymm2
  1c0f54:	c4 c2 e5 b8 f0       	vfmadd231pd ymm6,ymm3,ymm8
  1c0f59:	c5 fd 29 2c d0       	vmovapd YMMWORD PTR [rax+rdx*8],ymm5
  1c0f5e:	c5 fd 29 34 d1       	vmovapd YMMWORD PTR [rcx+rdx*8],ymm6
  1c0f63:	48 83 c2 04          	add    rdx,0x4
  1c0f67:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c0f6c:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c0f71:	4d 85 c9             	test   r9,r9
  1c0f74:	75 1f                	jne    1c0f95 <PyInit__clifft_core@@Base+0x172975>
  1c0f76:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c0f7a:	4d 89 ca             	mov    r10,r9
  1c0f7d:	49 21 d2             	and    r10,rdx
  1c0f80:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c0f85:	c5 f9 28 d8          	vmovapd xmm3,xmm0
  1c0f89:	41 f6 c2 01          	test   r10b,0x1
  1c0f8d:	74 91                	je     1c0f20 <PyInit__clifft_core@@Base+0x172900>
  1c0f8f:	c5 f9 28 dc          	vmovapd xmm3,xmm4
  1c0f93:	eb 8b                	jmp    1c0f20 <PyInit__clifft_core@@Base+0x172900>
  1c0f95:	5b                   	pop    rbx
  1c0f96:	41 5c                	pop    r12
  1c0f98:	41 5d                	pop    r13
  1c0f9a:	41 5e                	pop    r14
  1c0f9c:	41 5f                	pop    r15
  1c0f9e:	5d                   	pop    rbp
  1c0f9f:	c5 f8 77             	vzeroupper
  1c0fa2:	c3                   	ret
