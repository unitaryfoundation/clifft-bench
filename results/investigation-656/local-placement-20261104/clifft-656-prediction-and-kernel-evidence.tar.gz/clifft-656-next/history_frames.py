"""Observe preparation history and actual State backing without exchanges."""
import sys
sys.path.insert(0, '/tmp/clifft-656-placement')
from followup_support import *

assert args.workers == 16 and args.no_aslr and args.hash_seed == '0'

class CheckedWorker(Worker):
    def request(self, request, phase='setup'):
        result = super().request(request, phase)
        if request['command'] == 'prepare':
            self.preparation = result
        if request['command'] == 'sample':
            calls = -request['min_seconds']
            expected = (2000000,287417,1712583,0) if calls == 100 else (20000,2852,17148,0)
            assert tuple(result[k] for k in ['attempted_shots','accepted_shots','discarded_shots','logical_errors']) == expected
        return result


def frames(worker, address):
    return json.loads(subprocess.check_output(['sudo','-n','python3',str(ROOT/'page_frames.py'),str(worker.process.pid),str(address),'6'],text=True))


def observe(worker, label):
    mapping = next(line.split() for line in Path(f'/proc/{worker.process.pid}/maps').read_text().splitlines() if '_clifft_core.abi3.so' in line and 'r-xp' in line)
    pc = int(mapping[0].split('-')[0],16) + 0x1c5420 - int(mapping[2],16)
    prefix = OUT/f'{worker.index}-{label}'
    ready = Path(str(prefix)+'.ready')
    commands = f'''set pagination off
set confirm off
attach {worker.process.pid}
break *{pc:#x}
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
disable 1
python
import json,subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
evidence = json.loads(subprocess.check_output(['sudo','-n','python3',{str(ROOT/'page_frames.py')!r},str(inferior.pid),str(address),'6'],text=True))
evidence['state'] = hex(int(gdb.parse_and_eval('$rdi')))
evidence['imag'] = hex(int(gdb.parse_and_eval('$r8')))
evidence['rotation'] = hex(int(gdb.parse_and_eval('$rsi')))
evidence['stack'] = hex(int(gdb.parse_and_eval('$rsp')))
assert all(evidence['present'])
Path({str(prefix)+'.backing.json'!r}).write_text(json.dumps(evidence,indent=2))
end
detach
quit
end
python open({str(ready)!r},'w').write('ready')
continue
'''
    Path(str(prefix)+'.gdb').write_text(commands)
    with Path(str(prefix)+'.gdb-log').open('w') as log:
        debugger = subprocess.Popen(['gdb','-q','-nx','-batch','-x',str(prefix)+'.gdb'],stdout=log,stderr=subprocess.STDOUT)
        until = time.monotonic()+15
        while not ready.exists() and debugger.poll() is None and time.monotonic()<until:
            time.sleep(.05)
        if not ready.exists():
            debugger.terminate();debugger.wait(timeout=5)
            raise RuntimeError(Path(str(prefix)+'.gdb-log').read_text())
        worker.sample('diagnostic-'+label,1)
        debugger.wait(timeout=20)
        assert debugger.returncode == 0, Path(str(prefix)+'.gdb-log').read_text()
    evidence = json.loads(Path(str(prefix)+'.backing.json').read_text())
    save({'action':'observed-backing','worker':worker.index,'history':args.history,'phase':label,'evidence':evidence})
    return evidence


try:
    for index in range(16):
        # Four DCCD blocks balance history against chronological position.
        args.history = ['direct','calibrate','calibrate','direct'][index%4]
        save({'action':'starting-worker','worker':index,'history':args.history})
        worker = CheckedWorker(index)
        meta = worker.preparation['runtime_metadata']
        print('prepared',index,args.history,'batch',meta['effective_batch_size'],flush=True)
        if meta['effective_batch_size'] == 1:
            observation = observe(worker,'before')
            address = int(observation['address'],16)
            for repetition in range(2):
                before = frames(worker,address)
                worker.profile(f'{args.history}-{repetition}','cycles:u,instructions:u')
                after = frames(worker,address)
                save({'action':'measurement-backing','worker':index,'history':args.history,'repetition':repetition,'before':before,'after':after,'matches_observation':before['pfns']==after['pfns']==observation['pfns']})
            final = observe(worker,'after')
            save({'action':'worker-backing-summary','worker':index,'history':args.history,'same_live_address_and_frames':final['address']==observation['address'] and final['pfns']==observation['pfns']})
        else:
            save({'action':'non-scalar-selection','worker':index,'history':args.history,'batch':meta['effective_batch_size']})
        worker.process.stdin.close();worker.process.wait(timeout=5)
finally:
    for process in processes:
        if process.poll() is None:
            process.stdin.close()
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired: process.terminate();process.wait(timeout=5)
    output.close()
