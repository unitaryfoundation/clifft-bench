
/tmp/clifft-656-next/parent-16/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001c4320 <PyInit__clifft_core@@Base+0x175d00>:
  1c4320:	55                   	push   rbp
  1c4321:	41 57                	push   r15
  1c4323:	41 56                	push   r14
  1c4325:	41 55                	push   r13
  1c4327:	41 54                	push   r12
  1c4329:	53                   	push   rbx
  1c432a:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1c432f:	c5 e1 57 05 e9 95 e4 	vxorpd xmm0,xmm3,XMMWORD PTR [rip+0xffffffffffe495e9]        # d920 <PyInit__clifft_core@@Base-0x40d00>
  1c4336:	ff 
  1c4337:	c5 f8 92 c9          	kmovw  k1,ecx
  1c433b:	62 f1 e7 09 10 d8    	vmovsd xmm3{k1},xmm3,xmm0
  1c4341:	83 fa 03             	cmp    edx,0x3
  1c4344:	0f 84 28 02 00 00    	je     1c4572 <PyInit__clifft_core@@Base+0x175f52>
  1c434a:	83 fa 02             	cmp    edx,0x2
  1c434d:	0f 84 b0 00 00 00    	je     1c4403 <PyInit__clifft_core@@Base+0x175de3>
  1c4353:	83 fa 01             	cmp    edx,0x1
  1c4356:	0f 85 d2 04 00 00    	jne    1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c435c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c4360:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c4364:	62 f2 fd 48 19 46 06 	vbroadcastsd zmm0,QWORD PTR [rsi+0x30]
  1c436b:	c5 e1 57 0d ad 95 e4 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe495ad]        # d920 <PyInit__clifft_core@@Base-0x40d00>
  1c4372:	ff 
  1c4373:	31 d2                	xor    edx,edx
  1c4375:	4c 8d 05 44 f2 e5 ff 	lea    r8,[rip+0xffffffffffe5f244]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c437c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  1c4380:	62 f1 fd 48 28 14 d0 	vmovapd zmm2,ZMMWORD PTR [rax+rdx*8]
  1c4387:	62 f1 fd 48 28 24 d1 	vmovapd zmm4,ZMMWORD PTR [rcx+rdx*8]
  1c438e:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c4392:	4d 89 ca             	mov    r10,r9
  1c4395:	49 21 d2             	and    r10,rdx
  1c4398:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c439d:	41 83 e2 01          	and    r10d,0x1
  1c43a1:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c43a6:	c5 f9 28 eb          	vmovapd xmm5,xmm3
  1c43aa:	62 f1 d7 09 10 e9    	vmovsd xmm5{k1},xmm5,xmm1
  1c43b0:	41 83 e1 07          	and    r9d,0x7
  1c43b4:	41 c1 e1 06          	shl    r9d,0x6
  1c43b8:	62 f2 fd 48 19 ed    	vbroadcastsd zmm5,xmm5
  1c43be:	62 91 d5 48 59 2c 01 	vmulpd zmm5,zmm5,ZMMWORD PTR [r9+r8*1]
  1c43c5:	62 f1 ed 48 59 f0    	vmulpd zmm6,zmm2,zmm0
  1c43cb:	62 f2 d5 48 b8 f4    	vfmadd231pd zmm6,zmm5,zmm4
  1c43d1:	62 f1 dd 48 59 e0    	vmulpd zmm4,zmm4,zmm0
  1c43d7:	62 f2 d5 48 bc e2    	vfnmadd231pd zmm4,zmm5,zmm2
  1c43dd:	62 f1 fd 48 29 34 d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm6
  1c43e4:	62 f1 fd 48 29 24 d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm4
  1c43eb:	48 83 c2 08          	add    rdx,0x8
  1c43ef:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c43f4:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c43f9:	4d 85 c9             	test   r9,r9
  1c43fc:	74 82                	je     1c4380 <PyInit__clifft_core@@Base+0x175d60>
  1c43fe:	e9 2b 04 00 00       	jmp    1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c4403:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c4408:	48 8b 46 18          	mov    rax,QWORD PTR [rsi+0x18]
  1c440c:	44 8b 4e 08          	mov    r9d,DWORD PTR [rsi+0x8]
  1c4410:	41 83 e1 07          	and    r9d,0x7
  1c4414:	41 c1 e1 06          	shl    r9d,0x6
  1c4418:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c441c:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c4420:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
  1c4424:	4c 8b 47 20          	mov    r8,QWORD PTR [rdi+0x20]
  1c4428:	4c 8d 15 91 f3 e5 ff 	lea    r10,[rip+0xffffffffffe5f391]        # 237c0 <PyInit__clifft_core@@Base-0x2ae60>
  1c442f:	62 91 fd 48 28 0c 11 	vmovapd zmm1,ZMMWORD PTR [r9+r10*1]
  1c4436:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c443d:	0f 84 10 02 00 00    	je     1c4653 <PyInit__clifft_core@@Base+0x176033>
  1c4443:	48 85 c0             	test   rax,rax
  1c4446:	0f 84 e2 03 00 00    	je     1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c444c:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c4450:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c4455:	49 89 c1             	mov    r9,rax
  1c4458:	49 c1 e1 04          	shl    r9,0x4
  1c445c:	45 31 d2             	xor    r10d,r10d
  1c445f:	49 bb f8 ff ff ff ff 	movabs r11,0x1ffffffffffffff8
  1c4466:	ff ff 1f 
  1c4469:	48 8d 1d 50 f1 e5 ff 	lea    rbx,[rip+0xffffffffffe5f150]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c4470:	49 89 d6             	mov    r14,rdx
  1c4473:	4d 89 c7             	mov    r15,r8
  1c4476:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1c447d:	00 00 00 
  1c4480:	45 31 e4             	xor    r12d,r12d
  1c4483:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c448a:	84 00 00 00 00 00 
  1c4490:	4b 8d 2c 22          	lea    rbp,[r10+r12*1]
  1c4494:	4c 8b 6e 08          	mov    r13,QWORD PTR [rsi+0x8]
  1c4498:	49 31 ed             	xor    r13,rbp
  1c449b:	4d 21 dd             	and    r13,r11
  1c449e:	62 91 fd 48 28 1c e6 	vmovapd zmm3,ZMMWORD PTR [r14+r12*8]
  1c44a5:	62 91 fd 48 28 2c e7 	vmovapd zmm5,ZMMWORD PTR [r15+r12*8]
  1c44ac:	62 b2 f5 48 16 34 ea 	vpermpd zmm6,zmm1,ZMMWORD PTR [rdx+r13*8]
  1c44b3:	62 92 f5 48 16 3c e8 	vpermpd zmm7,zmm1,ZMMWORD PTR [r8+r13*8]
  1c44ba:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1c44be:	48 21 cd             	and    rbp,rcx
  1c44c1:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1c44c6:	83 e5 01             	and    ebp,0x1
  1c44c9:	c5 f8 92 cd          	kmovw  k1,ebp
  1c44cd:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c44d1:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c44d7:	83 e1 07             	and    ecx,0x7
  1c44da:	c1 e1 06             	shl    ecx,0x6
  1c44dd:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c44e3:	62 71 bd 48 59 04 19 	vmulpd zmm8,zmm8,ZMMWORD PTR [rcx+rbx*1]
  1c44ea:	62 71 e5 48 59 ca    	vmulpd zmm9,zmm3,zmm2
  1c44f0:	62 72 bd 48 b8 cf    	vfmadd231pd zmm9,zmm8,zmm7
  1c44f6:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c44fc:	62 72 bd 48 bc d6    	vfnmadd231pd zmm10,zmm8,zmm6
  1c4502:	62 f1 cd 48 59 f2    	vmulpd zmm6,zmm6,zmm2
  1c4508:	62 f2 bd 48 b8 f5    	vfmadd231pd zmm6,zmm8,zmm5
  1c450e:	62 f1 c5 48 59 ea    	vmulpd zmm5,zmm7,zmm2
  1c4514:	62 f2 bd 48 bc eb    	vfnmadd231pd zmm5,zmm8,zmm3
  1c451a:	62 11 fd 48 29 0c e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm9
  1c4521:	62 11 fd 48 29 14 e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm10
  1c4528:	62 f2 f5 48 16 de    	vpermpd zmm3,zmm1,zmm6
  1c452e:	62 b1 fd 48 29 1c ea 	vmovapd ZMMWORD PTR [rdx+r13*8],zmm3
  1c4535:	62 f2 f5 48 16 dd    	vpermpd zmm3,zmm1,zmm5
  1c453b:	62 91 fd 48 29 1c e8 	vmovapd ZMMWORD PTR [r8+r13*8],zmm3
  1c4542:	49 83 c4 08          	add    r12,0x8
  1c4546:	49 39 c4             	cmp    r12,rax
  1c4549:	0f 82 41 ff ff ff    	jb     1c4490 <PyInit__clifft_core@@Base+0x175e70>
  1c454f:	49 01 c2             	add    r10,rax
  1c4552:	49 01 c2             	add    r10,rax
  1c4555:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c4559:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c455e:	4d 01 cf             	add    r15,r9
  1c4561:	4d 01 ce             	add    r14,r9
  1c4564:	48 85 c9             	test   rcx,rcx
  1c4567:	0f 84 13 ff ff ff    	je     1c4480 <PyInit__clifft_core@@Base+0x175e60>
  1c456d:	e9 bc 02 00 00       	jmp    1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c4572:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1c4577:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1c457a:	83 e2 07             	and    edx,0x7
  1c457d:	c1 e2 06             	shl    edx,0x6
  1c4580:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1c4584:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1c4588:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1c458c:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1c4590:	4c 8d 05 29 f2 e5 ff 	lea    r8,[rip+0xffffffffffe5f229]        # 237c0 <PyInit__clifft_core@@Base-0x2ae60>
  1c4597:	62 b1 fd 48 28 0c 02 	vmovapd zmm1,ZMMWORD PTR [rdx+r8*1]
  1c459e:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1c45a5:	0f 84 d8 01 00 00    	je     1c4783 <PyInit__clifft_core@@Base+0x176163>
  1c45ab:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c45af:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c45b4:	31 d2                	xor    edx,edx
  1c45b6:	4c 8d 05 03 f0 e5 ff 	lea    r8,[rip+0xffffffffffe5f003]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c45bd:	0f 1f 00             	nop    DWORD PTR [rax]
  1c45c0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c45c7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c45ce:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c45d4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c45da:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c45de:	4d 89 ca             	mov    r10,r9
  1c45e1:	49 21 d2             	and    r10,rdx
  1c45e4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c45e9:	41 83 e2 01          	and    r10d,0x1
  1c45ed:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c45f2:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c45f6:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c45fc:	41 83 e1 07          	and    r9d,0x7
  1c4600:	41 c1 e1 06          	shl    r9d,0x6
  1c4604:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c460a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c4611:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c4617:	62 f2 bd 48 b8 df    	vfmadd231pd zmm3,zmm8,zmm7
  1c461d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c4623:	62 f2 bd 48 bc ee    	vfnmadd231pd zmm5,zmm8,zmm6
  1c4629:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c4630:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c4637:	48 83 c2 08          	add    rdx,0x8
  1c463b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c4640:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4645:	4d 85 c9             	test   r9,r9
  1c4648:	0f 84 72 ff ff ff    	je     1c45c0 <PyInit__clifft_core@@Base+0x175fa0>
  1c464e:	e9 db 01 00 00       	jmp    1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c4653:	48 85 c0             	test   rax,rax
  1c4656:	0f 84 d2 01 00 00    	je     1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c465c:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c4661:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c4665:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c466a:	49 89 c1             	mov    r9,rax
  1c466d:	49 c1 e1 04          	shl    r9,0x4
  1c4671:	45 31 d2             	xor    r10d,r10d
  1c4674:	49 bb f8 ff ff ff ff 	movabs r11,0x1ffffffffffffff8
  1c467b:	ff ff 1f 
  1c467e:	48 8d 1d 3b ef e5 ff 	lea    rbx,[rip+0xffffffffffe5ef3b]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c4685:	49 89 d6             	mov    r14,rdx
  1c4688:	4d 89 c7             	mov    r15,r8
  1c468b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
  1c4690:	45 31 e4             	xor    r12d,r12d
  1c4693:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1c469a:	84 00 00 00 00 00 
  1c46a0:	4b 8d 0c 22          	lea    rcx,[r10+r12*1]
  1c46a4:	4c 8b 6e 08          	mov    r13,QWORD PTR [rsi+0x8]
  1c46a8:	49 31 cd             	xor    r13,rcx
  1c46ab:	4d 21 dd             	and    r13,r11
  1c46ae:	62 91 fd 48 28 1c e6 	vmovapd zmm3,ZMMWORD PTR [r14+r12*8]
  1c46b5:	62 91 fd 48 28 2c e7 	vmovapd zmm5,ZMMWORD PTR [r15+r12*8]
  1c46bc:	62 b2 f5 48 16 34 ea 	vpermpd zmm6,zmm1,ZMMWORD PTR [rdx+r13*8]
  1c46c3:	62 92 f5 48 16 3c e8 	vpermpd zmm7,zmm1,ZMMWORD PTR [r8+r13*8]
  1c46ca:	48 8b 6e 10          	mov    rbp,QWORD PTR [rsi+0x10]
  1c46ce:	48 21 e9             	and    rcx,rbp
  1c46d1:	f3 48 0f b8 c9       	popcnt rcx,rcx
  1c46d6:	83 e1 01             	and    ecx,0x1
  1c46d9:	c5 f8 92 c9          	kmovw  k1,ecx
  1c46dd:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1c46e1:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1c46e7:	83 e5 07             	and    ebp,0x7
  1c46ea:	c1 e5 06             	shl    ebp,0x6
  1c46ed:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c46f3:	62 71 bd 48 59 44 1d 	vmulpd zmm8,zmm8,ZMMWORD PTR [rbp+rbx*1+0x0]
  1c46fa:	00 
  1c46fb:	62 71 e5 48 59 ca    	vmulpd zmm9,zmm3,zmm2
  1c4701:	62 72 bd 48 bc ce    	vfnmadd231pd zmm9,zmm8,zmm6
  1c4707:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1c470d:	62 72 bd 48 bc d7    	vfnmadd231pd zmm10,zmm8,zmm7
  1c4713:	62 f1 cd 48 59 f2    	vmulpd zmm6,zmm6,zmm2
  1c4719:	62 f2 bd 48 b8 f3    	vfmadd231pd zmm6,zmm8,zmm3
  1c471f:	62 f1 c5 48 59 da    	vmulpd zmm3,zmm7,zmm2
  1c4725:	62 f2 bd 48 b8 dd    	vfmadd231pd zmm3,zmm8,zmm5
  1c472b:	62 11 fd 48 29 0c e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm9
  1c4732:	62 11 fd 48 29 14 e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm10
  1c4739:	62 f2 f5 48 16 ee    	vpermpd zmm5,zmm1,zmm6
  1c473f:	62 b1 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [rdx+r13*8],zmm5
  1c4746:	62 f2 f5 48 16 db    	vpermpd zmm3,zmm1,zmm3
  1c474c:	62 91 fd 48 29 1c e8 	vmovapd ZMMWORD PTR [r8+r13*8],zmm3
  1c4753:	49 83 c4 08          	add    r12,0x8
  1c4757:	49 39 c4             	cmp    r12,rax
  1c475a:	0f 82 40 ff ff ff    	jb     1c46a0 <PyInit__clifft_core@@Base+0x176080>
  1c4760:	49 01 c2             	add    r10,rax
  1c4763:	49 01 c2             	add    r10,rax
  1c4766:	0f b6 4f 54          	movzx  ecx,BYTE PTR [rdi+0x54]
  1c476a:	c4 c2 f3 f7 ca       	shrx   rcx,r10,rcx
  1c476f:	4d 01 cf             	add    r15,r9
  1c4772:	4d 01 ce             	add    r14,r9
  1c4775:	48 85 c9             	test   rcx,rcx
  1c4778:	0f 84 12 ff ff ff    	je     1c4690 <PyInit__clifft_core@@Base+0x176070>
  1c477e:	e9 ab 00 00 00       	jmp    1c482e <PyInit__clifft_core@@Base+0x17620e>
  1c4783:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1c4788:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1c478c:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1c4791:	31 d2                	xor    edx,edx
  1c4793:	4c 8d 05 26 ee e5 ff 	lea    r8,[rip+0xffffffffffe5ee26]        # 235c0 <PyInit__clifft_core@@Base-0x2b060>
  1c479a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1c47a0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1c47a7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1c47ae:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1c47b4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1c47ba:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1c47be:	4d 89 ca             	mov    r10,r9
  1c47c1:	49 21 d2             	and    r10,rdx
  1c47c4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1c47c9:	41 83 e2 01          	and    r10d,0x1
  1c47cd:	41 83 e1 07          	and    r9d,0x7
  1c47d1:	41 c1 e1 06          	shl    r9d,0x6
  1c47d5:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1c47da:	c5 79 28 c0          	vmovapd xmm8,xmm0
  1c47de:	62 71 bf 09 10 c4    	vmovsd xmm8{k1},xmm8,xmm4
  1c47e4:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1c47ea:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1c47f1:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1c47f7:	62 f2 bd 48 b8 de    	vfmadd231pd zmm3,zmm8,zmm6
  1c47fd:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1c4803:	62 f2 bd 48 b8 ef    	vfmadd231pd zmm5,zmm8,zmm7
  1c4809:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1c4810:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1c4817:	48 83 c2 08          	add    rdx,0x8
  1c481b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1c4820:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1c4825:	4d 85 c9             	test   r9,r9
  1c4828:	0f 84 72 ff ff ff    	je     1c47a0 <PyInit__clifft_core@@Base+0x176180>
  1c482e:	5b                   	pop    rbx
  1c482f:	41 5c                	pop    r12
  1c4831:	41 5d                	pop    r13
  1c4833:	41 5e                	pop    r14
  1c4835:	41 5f                	pop    r15
  1c4837:	5d                   	pop    rbp
  1c4838:	c5 f8 77             	vzeroupper
  1c483b:	c3                   	ret
