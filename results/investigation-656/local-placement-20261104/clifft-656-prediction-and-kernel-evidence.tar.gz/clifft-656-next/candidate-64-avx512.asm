
/tmp/clifft-656-next/candidate-64/clifft/_clifft_core.abi3.so:     file format elf64-x86-64


Disassembly of section .text:

00000000001cf840 <PyInit__clifft_core@@Base+0x181180>:
  1cf840:	55                   	push   rbp
  1cf841:	41 57                	push   r15
  1cf843:	41 56                	push   r14
  1cf845:	41 55                	push   r13
  1cf847:	41 54                	push   r12
  1cf849:	53                   	push   rbx
  1cf84a:	c5 fb 10 5e 38       	vmovsd xmm3,QWORD PTR [rsi+0x38]
  1cf84f:	c5 e1 57 05 c9 e0 e3 	vxorpd xmm0,xmm3,XMMWORD PTR [rip+0xffffffffffe3e0c9]        # d920 <PyInit__clifft_core@@Base-0x40da0>
  1cf856:	ff 
  1cf857:	c5 f8 92 c9          	kmovw  k1,ecx
  1cf85b:	62 f1 e7 09 10 d8    	vmovsd xmm3{k1},xmm3,xmm0
  1cf861:	83 fa 03             	cmp    edx,0x3
  1cf864:	0f 84 35 02 00 00    	je     1cfa9f <PyInit__clifft_core@@Base+0x1813df>
  1cf86a:	83 fa 02             	cmp    edx,0x2
  1cf86d:	0f 84 b0 00 00 00    	je     1cf923 <PyInit__clifft_core@@Base+0x181263>
  1cf873:	83 fa 01             	cmp    edx,0x1
  1cf876:	0f 85 e2 04 00 00    	jne    1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cf87c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1cf880:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1cf884:	62 f2 fd 48 19 46 06 	vbroadcastsd zmm0,QWORD PTR [rsi+0x30]
  1cf88b:	c5 e1 57 0d 8d e0 e3 	vxorpd xmm1,xmm3,XMMWORD PTR [rip+0xffffffffffe3e08d]        # d920 <PyInit__clifft_core@@Base-0x40da0>
  1cf892:	ff 
  1cf893:	31 d2                	xor    edx,edx
  1cf895:	4c 8d 05 24 3d e5 ff 	lea    r8,[rip+0xffffffffffe53d24]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cf89c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  1cf8a0:	62 f1 fd 48 28 14 d0 	vmovapd zmm2,ZMMWORD PTR [rax+rdx*8]
  1cf8a7:	62 f1 fd 48 28 24 d1 	vmovapd zmm4,ZMMWORD PTR [rcx+rdx*8]
  1cf8ae:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cf8b2:	4d 89 ca             	mov    r10,r9
  1cf8b5:	49 21 d2             	and    r10,rdx
  1cf8b8:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cf8bd:	41 83 e2 01          	and    r10d,0x1
  1cf8c1:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1cf8c6:	c5 f9 28 eb          	vmovapd xmm5,xmm3
  1cf8ca:	62 f1 d7 09 10 e9    	vmovsd xmm5{k1},xmm5,xmm1
  1cf8d0:	41 83 e1 07          	and    r9d,0x7
  1cf8d4:	41 c1 e1 06          	shl    r9d,0x6
  1cf8d8:	62 f2 fd 48 19 ed    	vbroadcastsd zmm5,xmm5
  1cf8de:	62 91 d5 48 59 2c 01 	vmulpd zmm5,zmm5,ZMMWORD PTR [r9+r8*1]
  1cf8e5:	62 f1 ed 48 59 f0    	vmulpd zmm6,zmm2,zmm0
  1cf8eb:	62 f2 d5 48 b8 f4    	vfmadd231pd zmm6,zmm5,zmm4
  1cf8f1:	62 f1 dd 48 59 e0    	vmulpd zmm4,zmm4,zmm0
  1cf8f7:	62 f2 d5 48 bc e2    	vfnmadd231pd zmm4,zmm5,zmm2
  1cf8fd:	62 f1 fd 48 29 34 d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm6
  1cf904:	62 f1 fd 48 29 24 d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm4
  1cf90b:	48 83 c2 08          	add    rdx,0x8
  1cf90f:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cf914:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cf919:	4d 85 c9             	test   r9,r9
  1cf91c:	74 82                	je     1cf8a0 <PyInit__clifft_core@@Base+0x1811e0>
  1cf91e:	e9 3b 04 00 00       	jmp    1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cf923:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1cf928:	48 8b 46 08          	mov    rax,QWORD PTR [rsi+0x8]
  1cf92c:	48 8b 4e 10          	mov    rcx,QWORD PTR [rsi+0x10]
  1cf930:	48 8b 56 18          	mov    rdx,QWORD PTR [rsi+0x18]
  1cf934:	4c 8d 04 12          	lea    r8,[rdx+rdx*1]
  1cf938:	41 89 c3             	mov    r11d,eax
  1cf93b:	41 83 e3 07          	and    r11d,0x7
  1cf93f:	41 c1 e3 06          	shl    r11d,0x6
  1cf943:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1cf947:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1cf94b:	4c 8b 4f 18          	mov    r9,QWORD PTR [rdi+0x18]
  1cf94f:	4c 8b 57 20          	mov    r10,QWORD PTR [rdi+0x20]
  1cf953:	8b 7f 54             	mov    edi,DWORD PTR [rdi+0x54]
  1cf956:	48 8d 1d 63 3e e5 ff 	lea    rbx,[rip+0xffffffffffe53e63]        # 237c0 <PyInit__clifft_core@@Base-0x2af00>
  1cf95d:	62 d1 fd 48 28 0c 1b 	vmovapd zmm1,ZMMWORD PTR [r11+rbx*1]
  1cf964:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1cf96b:	0f 84 12 02 00 00    	je     1cfb83 <PyInit__clifft_core@@Base+0x1814c3>
  1cf971:	48 85 d2             	test   rdx,rdx
  1cf974:	0f 84 e4 03 00 00    	je     1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cf97a:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cf97e:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cf983:	89 ce                	mov    esi,ecx
  1cf985:	83 e6 07             	and    esi,0x7
  1cf988:	c1 e6 06             	shl    esi,0x6
  1cf98b:	4c 8d 1d 2e 3c e5 ff 	lea    r11,[rip+0xffffffffffe53c2e]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cf992:	62 b1 fd 48 28 1c 1e 	vmovapd zmm3,ZMMWORD PTR [rsi+r11*1]
  1cf999:	48 89 d6             	mov    rsi,rdx
  1cf99c:	48 c1 e6 04          	shl    rsi,0x4
  1cf9a0:	45 31 db             	xor    r11d,r11d
  1cf9a3:	48 bb f8 ff ff ff ff 	movabs rbx,0x1ffffffffffffff8
  1cf9aa:	ff ff 1f 
  1cf9ad:	4d 89 ce             	mov    r14,r9
  1cf9b0:	4d 89 d7             	mov    r15,r10
  1cf9b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cf9ba:	84 00 00 00 00 00 
  1cf9c0:	45 31 e4             	xor    r12d,r12d
  1cf9c3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cf9ca:	84 00 00 00 00 00 
  1cf9d0:	4b 8d 2c 23          	lea    rbp,[r11+r12*1]
  1cf9d4:	49 89 ed             	mov    r13,rbp
  1cf9d7:	49 31 c5             	xor    r13,rax
  1cf9da:	49 21 dd             	and    r13,rbx
  1cf9dd:	62 91 fd 48 28 2c e6 	vmovapd zmm5,ZMMWORD PTR [r14+r12*8]
  1cf9e4:	62 91 fd 48 28 34 e7 	vmovapd zmm6,ZMMWORD PTR [r15+r12*8]
  1cf9eb:	62 92 f5 48 16 3c e9 	vpermpd zmm7,zmm1,ZMMWORD PTR [r9+r13*8]
  1cf9f2:	62 12 f5 48 16 04 ea 	vpermpd zmm8,zmm1,ZMMWORD PTR [r10+r13*8]
  1cf9f9:	48 21 cd             	and    rbp,rcx
  1cf9fc:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1cfa01:	83 e5 01             	and    ebp,0x1
  1cfa04:	c5 f8 92 cd          	kmovw  k1,ebp
  1cfa08:	c5 79 28 cc          	vmovapd xmm9,xmm4
  1cfa0c:	62 71 b7 09 10 c8    	vmovsd xmm9{k1},xmm9,xmm0
  1cfa12:	62 52 fd 48 19 c9    	vbroadcastsd zmm9,xmm9
  1cfa18:	62 71 b5 48 59 cb    	vmulpd zmm9,zmm9,zmm3
  1cfa1e:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1cfa24:	62 52 b5 48 b8 d0    	vfmadd231pd zmm10,zmm9,zmm8
  1cfa2a:	62 71 cd 48 59 da    	vmulpd zmm11,zmm6,zmm2
  1cfa30:	62 72 b5 48 bc df    	vfnmadd231pd zmm11,zmm9,zmm7
  1cfa36:	62 f1 c5 48 59 fa    	vmulpd zmm7,zmm7,zmm2
  1cfa3c:	62 f2 b5 48 b8 fe    	vfmadd231pd zmm7,zmm9,zmm6
  1cfa42:	62 f1 bd 48 59 f2    	vmulpd zmm6,zmm8,zmm2
  1cfa48:	62 f2 b5 48 bc f5    	vfnmadd231pd zmm6,zmm9,zmm5
  1cfa4e:	62 11 fd 48 29 14 e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm10
  1cfa55:	62 11 fd 48 29 1c e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm11
  1cfa5c:	62 f2 f5 48 16 ef    	vpermpd zmm5,zmm1,zmm7
  1cfa62:	62 91 fd 48 29 2c e9 	vmovapd ZMMWORD PTR [r9+r13*8],zmm5
  1cfa69:	62 f2 f5 48 16 ee    	vpermpd zmm5,zmm1,zmm6
  1cfa6f:	62 91 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [r10+r13*8],zmm5
  1cfa76:	49 83 c4 08          	add    r12,0x8
  1cfa7a:	49 39 d4             	cmp    r12,rdx
  1cfa7d:	0f 82 4d ff ff ff    	jb     1cf9d0 <PyInit__clifft_core@@Base+0x181310>
  1cfa83:	4d 01 c3             	add    r11,r8
  1cfa86:	c4 42 c3 f7 e3       	shrx   r12,r11,rdi
  1cfa8b:	49 01 f7             	add    r15,rsi
  1cfa8e:	49 01 f6             	add    r14,rsi
  1cfa91:	4d 85 e4             	test   r12,r12
  1cfa94:	0f 84 26 ff ff ff    	je     1cf9c0 <PyInit__clifft_core@@Base+0x181300>
  1cfa9a:	e9 bf 02 00 00       	jmp    1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cfa9f:	c5 fb 10 6e 20       	vmovsd xmm5,QWORD PTR [rsi+0x20]
  1cfaa4:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
  1cfaa7:	83 e2 07             	and    edx,0x7
  1cfaaa:	c1 e2 06             	shl    edx,0x6
  1cfaad:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1cfab1:	c5 f9 2e c5          	vucomisd xmm0,xmm5
  1cfab5:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
  1cfab9:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
  1cfabd:	4c 8d 05 fc 3c e5 ff 	lea    r8,[rip+0xffffffffffe53cfc]        # 237c0 <PyInit__clifft_core@@Base-0x2af00>
  1cfac4:	62 b1 fd 48 28 0c 02 	vmovapd zmm1,ZMMWORD PTR [rdx+r8*1]
  1cfacb:	62 f2 fd 48 19 56 06 	vbroadcastsd zmm2,QWORD PTR [rsi+0x30]
  1cfad2:	0f 84 d7 01 00 00    	je     1cfcaf <PyInit__clifft_core@@Base+0x1815ef>
  1cfad8:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cfadc:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cfae1:	31 d2                	xor    edx,edx
  1cfae3:	4c 8d 05 d6 3a e5 ff 	lea    r8,[rip+0xffffffffffe53ad6]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cfaea:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1cfaf0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1cfaf7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1cfafe:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1cfb04:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1cfb0a:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cfb0e:	4d 89 ca             	mov    r10,r9
  1cfb11:	49 21 d2             	and    r10,rdx
  1cfb14:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cfb19:	41 83 e2 01          	and    r10d,0x1
  1cfb1d:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1cfb22:	c5 79 28 c4          	vmovapd xmm8,xmm4
  1cfb26:	62 71 bf 09 10 c0    	vmovsd xmm8{k1},xmm8,xmm0
  1cfb2c:	41 83 e1 07          	and    r9d,0x7
  1cfb30:	41 c1 e1 06          	shl    r9d,0x6
  1cfb34:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1cfb3a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1cfb41:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1cfb47:	62 f2 bd 48 b8 df    	vfmadd231pd zmm3,zmm8,zmm7
  1cfb4d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1cfb53:	62 f2 bd 48 bc ee    	vfnmadd231pd zmm5,zmm8,zmm6
  1cfb59:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1cfb60:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1cfb67:	48 83 c2 08          	add    rdx,0x8
  1cfb6b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cfb70:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cfb75:	4d 85 c9             	test   r9,r9
  1cfb78:	0f 84 72 ff ff ff    	je     1cfaf0 <PyInit__clifft_core@@Base+0x181430>
  1cfb7e:	e9 db 01 00 00       	jmp    1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cfb83:	48 85 d2             	test   rdx,rdx
  1cfb86:	0f 84 d2 01 00 00    	je     1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cfb8c:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1cfb91:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cfb95:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cfb9a:	89 ce                	mov    esi,ecx
  1cfb9c:	83 e6 07             	and    esi,0x7
  1cfb9f:	c1 e6 06             	shl    esi,0x6
  1cfba2:	4c 8d 1d 17 3a e5 ff 	lea    r11,[rip+0xffffffffffe53a17]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cfba9:	62 b1 fd 48 28 1c 1e 	vmovapd zmm3,ZMMWORD PTR [rsi+r11*1]
  1cfbb0:	48 89 d6             	mov    rsi,rdx
  1cfbb3:	48 c1 e6 04          	shl    rsi,0x4
  1cfbb7:	45 31 db             	xor    r11d,r11d
  1cfbba:	48 bb f8 ff ff ff ff 	movabs rbx,0x1ffffffffffffff8
  1cfbc1:	ff ff 1f 
  1cfbc4:	4d 89 ce             	mov    r14,r9
  1cfbc7:	4d 89 d7             	mov    r15,r10
  1cfbca:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1cfbd0:	45 31 e4             	xor    r12d,r12d
  1cfbd3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1cfbda:	84 00 00 00 00 00 
  1cfbe0:	4b 8d 2c 23          	lea    rbp,[r11+r12*1]
  1cfbe4:	49 89 ed             	mov    r13,rbp
  1cfbe7:	49 31 c5             	xor    r13,rax
  1cfbea:	49 21 dd             	and    r13,rbx
  1cfbed:	62 91 fd 48 28 2c e6 	vmovapd zmm5,ZMMWORD PTR [r14+r12*8]
  1cfbf4:	62 91 fd 48 28 34 e7 	vmovapd zmm6,ZMMWORD PTR [r15+r12*8]
  1cfbfb:	62 92 f5 48 16 3c e9 	vpermpd zmm7,zmm1,ZMMWORD PTR [r9+r13*8]
  1cfc02:	62 12 f5 48 16 04 ea 	vpermpd zmm8,zmm1,ZMMWORD PTR [r10+r13*8]
  1cfc09:	48 21 cd             	and    rbp,rcx
  1cfc0c:	f3 48 0f b8 ed       	popcnt rbp,rbp
  1cfc11:	83 e5 01             	and    ebp,0x1
  1cfc14:	c5 f8 92 cd          	kmovw  k1,ebp
  1cfc18:	c5 79 28 cc          	vmovapd xmm9,xmm4
  1cfc1c:	62 71 b7 09 10 c8    	vmovsd xmm9{k1},xmm9,xmm0
  1cfc22:	62 52 fd 48 19 c9    	vbroadcastsd zmm9,xmm9
  1cfc28:	62 71 b5 48 59 cb    	vmulpd zmm9,zmm9,zmm3
  1cfc2e:	62 71 d5 48 59 d2    	vmulpd zmm10,zmm5,zmm2
  1cfc34:	62 72 b5 48 bc d7    	vfnmadd231pd zmm10,zmm9,zmm7
  1cfc3a:	62 71 cd 48 59 da    	vmulpd zmm11,zmm6,zmm2
  1cfc40:	62 52 b5 48 bc d8    	vfnmadd231pd zmm11,zmm9,zmm8
  1cfc46:	62 f1 c5 48 59 fa    	vmulpd zmm7,zmm7,zmm2
  1cfc4c:	62 f2 b5 48 b8 fd    	vfmadd231pd zmm7,zmm9,zmm5
  1cfc52:	62 f1 bd 48 59 ea    	vmulpd zmm5,zmm8,zmm2
  1cfc58:	62 f2 b5 48 b8 ee    	vfmadd231pd zmm5,zmm9,zmm6
  1cfc5e:	62 11 fd 48 29 14 e6 	vmovapd ZMMWORD PTR [r14+r12*8],zmm10
  1cfc65:	62 11 fd 48 29 1c e7 	vmovapd ZMMWORD PTR [r15+r12*8],zmm11
  1cfc6c:	62 f2 f5 48 16 f7    	vpermpd zmm6,zmm1,zmm7
  1cfc72:	62 91 fd 48 29 34 e9 	vmovapd ZMMWORD PTR [r9+r13*8],zmm6
  1cfc79:	62 f2 f5 48 16 ed    	vpermpd zmm5,zmm1,zmm5
  1cfc7f:	62 91 fd 48 29 2c ea 	vmovapd ZMMWORD PTR [r10+r13*8],zmm5
  1cfc86:	49 83 c4 08          	add    r12,0x8
  1cfc8a:	49 39 d4             	cmp    r12,rdx
  1cfc8d:	0f 82 4d ff ff ff    	jb     1cfbe0 <PyInit__clifft_core@@Base+0x181520>
  1cfc93:	4d 01 c3             	add    r11,r8
  1cfc96:	c4 42 c3 f7 e3       	shrx   r12,r11,rdi
  1cfc9b:	49 01 f7             	add    r15,rsi
  1cfc9e:	49 01 f6             	add    r14,rsi
  1cfca1:	4d 85 e4             	test   r12,r12
  1cfca4:	0f 84 26 ff ff ff    	je     1cfbd0 <PyInit__clifft_core@@Base+0x181510>
  1cfcaa:	e9 af 00 00 00       	jmp    1cfd5e <PyInit__clifft_core@@Base+0x18169e>
  1cfcaf:	c5 fb 10 6e 28       	vmovsd xmm5,QWORD PTR [rsi+0x28]
  1cfcb4:	c5 d3 59 e3          	vmulsd xmm4,xmm5,xmm3
  1cfcb8:	c4 e2 d1 bf c3       	vfnmsub231sd xmm0,xmm5,xmm3
  1cfcbd:	31 d2                	xor    edx,edx
  1cfcbf:	4c 8d 05 fa 38 e5 ff 	lea    r8,[rip+0xffffffffffe538fa]        # 235c0 <PyInit__clifft_core@@Base-0x2b100>
  1cfcc6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  1cfccd:	00 00 00 
  1cfcd0:	62 f1 fd 48 28 1c d0 	vmovapd zmm3,ZMMWORD PTR [rax+rdx*8]
  1cfcd7:	62 f1 fd 48 28 2c d1 	vmovapd zmm5,ZMMWORD PTR [rcx+rdx*8]
  1cfcde:	62 f2 f5 48 16 f3    	vpermpd zmm6,zmm1,zmm3
  1cfce4:	62 f2 f5 48 16 fd    	vpermpd zmm7,zmm1,zmm5
  1cfcea:	4c 8b 4e 10          	mov    r9,QWORD PTR [rsi+0x10]
  1cfcee:	4d 89 ca             	mov    r10,r9
  1cfcf1:	49 21 d2             	and    r10,rdx
  1cfcf4:	f3 4d 0f b8 d2       	popcnt r10,r10
  1cfcf9:	41 83 e2 01          	and    r10d,0x1
  1cfcfd:	41 83 e1 07          	and    r9d,0x7
  1cfd01:	41 c1 e1 06          	shl    r9d,0x6
  1cfd05:	c4 c1 78 92 ca       	kmovw  k1,r10d
  1cfd0a:	c5 79 28 c0          	vmovapd xmm8,xmm0
  1cfd0e:	62 71 bf 09 10 c4    	vmovsd xmm8{k1},xmm8,xmm4
  1cfd14:	62 52 fd 48 19 c0    	vbroadcastsd zmm8,xmm8
  1cfd1a:	62 11 bd 48 59 04 01 	vmulpd zmm8,zmm8,ZMMWORD PTR [r9+r8*1]
  1cfd21:	62 f1 e5 48 59 da    	vmulpd zmm3,zmm3,zmm2
  1cfd27:	62 f2 bd 48 b8 de    	vfmadd231pd zmm3,zmm8,zmm6
  1cfd2d:	62 f1 d5 48 59 ea    	vmulpd zmm5,zmm5,zmm2
  1cfd33:	62 f2 bd 48 b8 ef    	vfmadd231pd zmm5,zmm8,zmm7
  1cfd39:	62 f1 fd 48 29 1c d0 	vmovapd ZMMWORD PTR [rax+rdx*8],zmm3
  1cfd40:	62 f1 fd 48 29 2c d1 	vmovapd ZMMWORD PTR [rcx+rdx*8],zmm5
  1cfd47:	48 83 c2 08          	add    rdx,0x8
  1cfd4b:	44 0f b6 4f 54       	movzx  r9d,BYTE PTR [rdi+0x54]
  1cfd50:	c4 62 b3 f7 ca       	shrx   r9,rdx,r9
  1cfd55:	4d 85 c9             	test   r9,r9
  1cfd58:	0f 84 72 ff ff ff    	je     1cfcd0 <PyInit__clifft_core@@Base+0x181610>
  1cfd5e:	5b                   	pop    rbx
  1cfd5f:	41 5c                	pop    r12
  1cfd61:	41 5d                	pop    r13
  1cfd63:	41 5e                	pop    r14
  1cfd65:	41 5f                	pop    r15
  1cfd67:	5d                   	pop    rbp
  1cfd68:	c5 f8 77             	vzeroupper
  1cfd6b:	c3                   	ret
