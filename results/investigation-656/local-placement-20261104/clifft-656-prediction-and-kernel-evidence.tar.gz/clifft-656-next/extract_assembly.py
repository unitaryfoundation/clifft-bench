import hashlib,json,subprocess
from pathlib import Path
root=Path('/tmp/clifft-656-next');records=[]
for variant in ['parent','candidate']:
 for align in [16,32,64]:
  module=root/f'{variant}-{align}/clifft/_clifft_core.abi3.so'
  for isa in ['avx2','avx512']:
   needle=f'clifft::sampling::apply_direct_rotation_{isa}('
   found=[line for line in (root/f'{variant}-{align}.map').read_text().splitlines() if needle in line]
   assert len(found)==1,found
   fields=found[0].split();start=int(fields[0],16);size=int(fields[2],16)
   output=root/f'{variant}-{align}-{isa}.asm'
   with output.open('w') as stream:
    subprocess.run(['objdump','-d','-Mintel',f'--start-address={start}',f'--stop-address={start+size}',str(module)],stdout=stream,check=True)
   records.append(dict(variant=variant,alignment=align,isa=isa,start=hex(start),size=size,sha256=hashlib.sha256(module.read_bytes()).hexdigest()))
(root/'assembly-identities.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
