"""Matched-build validation and fixed-work measurements; not release benchmarking."""
import argparse,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/tmp/clifft-656-next')
BENCH=Path('/tmp/clifft-rc-investigation/bench')
sys.path.insert(0,str(BENCH/'src'))
from clifft_bench.system import restricted_environment
PERF='/usr/lib/linux-tools/6.8.0-106-generic/perf'
parser=argparse.ArgumentParser();parser.add_argument('--correctness',action='store_true');args=parser.parse_args()
OUT=ROOT/('normal-correctness' if args.correctness else 'normal-performance');OUT.mkdir()
raw=json.loads((BENCH/'results/release-v1/0.13.0rc1-20261103-183623/raw.json').read_text())
# Fixed amounts of work chosen before comparing builds. D5 is the primary target.
SPECS=[('d5','msc-d5-inject-cultivate-p1e-3--clifft-current',20000,50),
       ('qv10','quantum-volume-q10-seed42-all-observables--clifft-coverage',4096,30),
       ('coherent-d5','coherent-surface-d5-r5-p1e-3-rz2e-2--clifft-bulk',256,250),
       ('draper','draper-adder-m16-basis-all-observables--clifft-current',2048,100),
       ('d3','msc-d3-inject-cultivate-p1e-3--clifft-current',100000,50),
       ('surface-d7','surface-code-d7-r7-p1e-3--clifft-current',100000,50)]
CASES={name:next(c for c in raw['cases'] if c['case_id']==case_id) for name,case_id,_,_ in SPECS}
(OUT/'protocol.json').write_text(json.dumps(dict(specs=SPECS,alignments=[16,32,64],fresh_workers_per_build_case=2,passes_per_worker=2,compiler='Clang 22.1.8',parent='7e83ec2823bf99c54aa1b90c54a092641c10c4b0',patch_sha256=hashlib.sha256((ROOT/'candidate.patch').read_bytes()).hexdigest(),purpose='local normal-build diagnostic'),indent=2))
stream=(OUT/'results.jsonl').open('w')
expected={}


def save(value):
    stream.write(json.dumps(value)+'\n');stream.flush()


def request(process,value):
    process.stdin.write(json.dumps(value)+'\n');process.stdin.flush()
    line=process.stdout.readline();assert line,'worker exited'
    answer=json.loads(line);assert answer['ok'],answer
    return answer


try:
    for alignment in [16,32,64]:
        for name,_,shots,calls in SPECS:
            # Reversing parent/candidate order between fresh workers forms ABBA.
            for fresh in range(1 if args.correctness else 2):
                for variant in (['parent','candidate'] if fresh==0 else ['candidate','parent']):
                    label=f'{alignment}-{name}-{fresh}-{variant}'
                    env=restricted_environment();env['PYTHONHASHSEED']='0'
                    env['PYTHONPATH']=str(ROOT/f'{variant}-{alignment}')+':'+str(BENCH/'src')
                    command=['setarch','x86_64','-R',str(ROOT/'build-env/bin/python'),str(ROOT/'normal_worker.py')]
                    with (OUT/f'{label}.stderr').open('w') as err:
                        process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=env)
                        try:
                            case=CASES[name]
                            setup=request(process,dict(command='prepare',case=case,artifact=str(BENCH/'workloads/circuits'/Path(case['workload']['artifact']['path']).name),batch_size=case['execution']['batch_size']))
                            save(dict(action='setup',label=label,result=setup))
                            if args.correctness:
                                result=request(process,dict(command='correctness',shots=2048))
                                if name in expected:assert result==expected[name],label
                                else:expected[name]=result
                                save(dict(action='correctness',label=label,result=result))
                                print('exact outputs match',label,flush=True)
                            else:
                                for repetition in range(2):
                                    prefix=OUT/f'{label}-{repetition}'
                                    with Path(str(prefix)+'.perf-log').open('w') as log:
                                        profiler=subprocess.Popen([PERF,'stat','-p',str(process.pid),'-x',',','-e','cycles:u,instructions:u','-o',str(prefix)+'.csv'],stdout=log,stderr=log)
                                        try:
                                            time.sleep(.15);assert profiler.poll() is None
                                            result=request(process,dict(command='sample',shots=shots,calls=calls))
                                        finally:
                                            profiler.send_signal(signal.SIGINT);profiler.wait(timeout=10)
                                    if name in expected:assert result['totals']==expected[name],(label,result)
                                    else:expected[name]=result['totals']
                                    save(dict(action='sample',label=label,alignment=alignment,workload=name,fresh=fresh,variant=variant,repetition=repetition,shots_per_call=shots,calls=calls,result=result))
                                    print(label,repetition,round(result['totals'][0]/result['seconds']),flush=True)
                        finally:
                            process.stdin.close()
                            try:process.wait(timeout=10)
                            except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=5)
                            assert process.returncode==0,(label,(OUT/f'{label}.stderr').read_text())
finally:
    stream.close()
