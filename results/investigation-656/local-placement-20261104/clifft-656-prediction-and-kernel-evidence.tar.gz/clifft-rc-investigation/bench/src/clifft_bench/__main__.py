from clifft_bench.cli import main

raise SystemExit(main())
