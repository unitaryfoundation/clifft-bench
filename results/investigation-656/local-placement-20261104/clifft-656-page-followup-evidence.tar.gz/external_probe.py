"""Apply a diagnostic intervention while the live driver supplies a separate call."""
import argparse
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('directory', type=Path)
parser.add_argument('label')
parser.add_argument('body', type=Path)
args = parser.parse_args()
selected = json.loads((args.directory/'selected.json').read_text())
worker = selected['slow']
pid = selected['pids'][str(worker)]
mapping = next(line.split() for line in Path(f'/proc/{pid}/maps').read_text().splitlines() if '_clifft_core.abi3.so' in line and 'r-xp' in line)
pc = int(mapping[0].split('-')[0],16) + 0x1c5420 - int(mapping[2],16)
prefix = args.directory/f'{worker}-{args.label}'
ready = Path(str(prefix)+'.ready')
assert not ready.exists()
body = args.body.read_text().replace('OUTPUT_PREFIX',repr(str(prefix))).replace('SLOTS_PATH',repr(str(args.directory/f'{worker}-backing.json')))
script = f'''set pagination off
set confirm off
attach {pid}
break *{pc:#x}
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
disable 1
python
{body}
end
detach
quit
end
python open({str(ready)!r},'w').write('ready')
continue
'''
Path(str(prefix)+'.gdb').write_text(script)
with Path(str(prefix)+'.gdb-log').open('w') as log:
 debugger = subprocess.Popen(['gdb','-q','-nx','-batch','-x',str(prefix)+'.gdb'],stdout=log,stderr=subprocess.STDOUT)
 until=time.monotonic()+15
 while not ready.exists() and debugger.poll() is None and time.monotonic()<until: time.sleep(.05)
 if not ready.exists():
  debugger.terminate(); debugger.wait(timeout=5)
  raise RuntimeError(Path(str(prefix)+'.gdb-log').read_text())
 with (args.directory/'commands.jsonl').open('a') as commands:
  commands.write(json.dumps({'action':'profile','label':'debug-external-'+args.label})+'\n')
 debugger.wait(timeout=30)
 assert debugger.returncode == 0,Path(str(prefix)+'.gdb-log').read_text()
print(Path(str(prefix)+'.gdb-log').read_text())
