"""Reproduce the diagnostic hook's temporary-slot relocation or restore code."""
import json
from pathlib import Path
import subprocess
import sys
r=Path('/tmp/clifft-656-placement/direct-rc1-page-subsets')
s=json.loads((r/'selected.json').read_text());worker=s['slow'];pid=s['pids'][str(worker)]
hook=json.loads((r/f'{worker}-install-candidate.hook.json').read_text())
if sys.argv[1]=='relocate':
 body=f'''
import json
from pathlib import Path
slots=Path({str(r/f'{worker}-backing.json')!r})
state=json.loads(slots.read_text())
previous=state['temporary']
state['temporary']=int(gdb.parse_and_eval('(long)mmap((void*)0,4096,3,34,-1,0)'))
assert state['temporary'] not in (-1,0,previous,{hook['trampoline']})
slots.write_text(json.dumps(state,indent=2))
print('TEMPORARY',previous,state['temporary'])
'''
elif sys.argv[1]=='restore':
 body=f'''
inferior=gdb.selected_inferior()
original=bytes.fromhex({hook['original']!r})
inferior.write_memory({hook['entry']},original)
assert bytes(inferior.read_memory({hook['entry']},15))==original
print('Original function entry restored')
'''
else:raise ValueError(sys.argv[1])
script=r/f'manage-{sys.argv[1]}.gdb'
script.write_text(f'set pagination off\nset confirm off\nattach {pid}\npython\n{body}\nend\ndetach\nquit\n')
subprocess.run(['gdb','-q','-nx','-batch','-x',str(script)],check=True)
