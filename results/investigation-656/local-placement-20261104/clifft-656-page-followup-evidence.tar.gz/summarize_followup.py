"""Validate and summarize the selective-backing and kernel diagnostic evidence."""
import csv
import json
from pathlib import Path
import re
import statistics

root=Path('/tmp/clifft-656-placement')
directory=root/'direct-rc1-page-subsets'
selected=json.loads((directory/'selected.json').read_text())
slow=selected['slow']
rows=[]
mask=0
hook=False
correctness=0
backing_changes=0
for event in map(json.loads,(directory/'results.jsonl').read_text().splitlines()):
 if event.get('action')=='backing':
  evidence=event['evidence'];state=evidence['state'];mask=state['mask']
  assert evidence['restored_bytes']==24576
  assert evidence['after']['present']==[True]*6
  assert evidence['after']['pfns']==[state['replacement' if mask&(1<<i) else 'original'][i] for i in range(6)]
  backing_changes+=1
  continue
 request=event['request'];result=event['result'];assert result['ok']
 if request['command']=='correctness':
  assert not result['contract_errors'];correctness+=1
 if request['command']!='sample':continue
 calls=-request['min_seconds']
 assert calls in [1,100]
 counts=(20000,2852,17148,0) if calls==1 else (2000000,287417,1712583,0)
 assert tuple(result[k] for k in ['attempted_shots','accepted_shots','discarded_shots','logical_errors'])==counts
 assert result['api_calls']==calls
 assert result['seed_first']==20270819 and result['seed_last']==20270818+calls
 phase=event['phase'];worker=event['worker']
 debug=phase.startswith('debug-')
 if phase=='debug-external-install-candidate':hook=True
 if phase=='final-original-code-and-pages':hook=False
 variant='wheel'
 match=re.fullmatch(r'candidate-\d+-mode-(\d+)-mask-(\d+)',phase)
 if worker==slow:
  if hook:variant='hook-original'
  if match:
   mode=int(match[1]);assert mask==int(match[2])
   variant=['hook-original','source-copy','metadata-cached'][mode]
 row=dict(worker=worker,pid=event['pid'],phase=phase,backing_mask=mask if worker==slow else '',kernel=variant,diagnostic_intervention=debug,calls=calls,
  attempted=result['attempted_shots'],accepted=result['accepted_shots'],discarded=result['discarded_shots'],logical_errors=result['logical_errors'],
  started_at=result['started_at'],seed_first=result['seed_first'],seed_last=result['seed_last'],seconds=result['duration_seconds'],cpu_seconds=result['process_cpu_seconds'],shots_per_second=result['throughput_attempted_shots_per_second'])
 perf=directory/f'{worker}-{phase}.csv'
 if perf.exists():
  for fields in csv.reader(perf.open()):
   if len(fields)<5:continue
   assert float(fields[4])==100,fields
   row[fields[2]]=int(fields[0])
 rows.append(row)
fields=list(dict.fromkeys(k for row in rows for k in row))
with (directory/'all-samples.csv').open('w') as stream:
 writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(rows)
summary={'workers':correctness,'sample_calls':len(rows),'profiled_passes':sum('cycles:u' in r for r in rows),'backing_changes':backing_changes,
 'attempted_shots':sum(r['attempted'] for r in rows),'all_seeded_counts_match':True,'all_counter_running_percent':100,'confirm':{},'candidate':{}}
for m in [4,12]:
 passes=[r for r in rows if r['worker']==slow and re.fullmatch(r'confirm-\d+-mask-'+str(m),r['phase'])]
 if passes:summary['confirm'][m]={k:statistics.median(r[k] for r in passes) for k in ['cycles:u','instructions:u','shots_per_second']}
for variant in ['hook-original','source-copy','metadata-cached']:
 summary['candidate'][variant]={}
 for m in [4,12]:
  passes=[r for r in rows if r['worker']==slow and r['kernel']==variant and r['backing_mask']==m and re.fullmatch(r'candidate-\d+-mode-\d+-mask-\d+',r['phase'])]
  if passes:summary['candidate'][variant][m]={'passes':len(passes),**{k:statistics.median(r[k] for r in passes) for k in ['cycles:u','instructions:u','shots_per_second']}}
(directory/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
