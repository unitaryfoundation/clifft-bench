"""Keep a live d5 worker pair for selective, reversible page-backing experiments."""
from followup_support import *

CORE = 'cycles:u,instructions:u'


def set_backing(worker, mask, label):
    assert 0 <= mask <= 63
    lines = Path(f'/proc/{worker.process.pid}/maps').read_text().splitlines()
    mapping = next(line.split() for line in lines if '_clifft_core.abi3.so' in line and 'r-xp' in line)
    pc = int(mapping[0].split('-')[0], 16) + 0x1c5420 - int(mapping[2], 16)
    prefix = OUT / f'{worker.index}-{label}'
    ready = Path(str(prefix) + '.ready')
    assert not ready.exists()
    slots = OUT / f'{worker.index}-backing.json'
    body = f'''
import json, subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
def frames():
    return json.loads(subprocess.check_output(['sudo','-n','python3',{str(ROOT/'page_frames.py')!r},str(inferior.pid),str(address),'6'],text=True))
def pfns(value):
    return value['pfns']
def call(expression):
    value = int(gdb.parse_and_eval(expression))
    assert value != -1 and value != (1<<64)-1, expression
    return value
before = frames()
slots = Path({str(slots)!r})
if not slots.exists():
    original = pfns(before)
    parked = call('(long)mmap((void*)0,24576,3,34,-1,0)')
    temporary = call('(long)mmap((void*)0,4096,3,34,-1,0)')
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address, parked)) == parked
    assert call('(long)mmap((void*)%d,24576,3,50,-1,0)' % address) == address
    inferior.write_memory(address, saved)
    replacement = pfns(frames())
    assert all(a != b for a, b in zip(original, replacement))
    state = dict(address=address, parked=parked, temporary=temporary, original=original, replacement=replacement, mask=63)
else:
    state = json.loads(slots.read_text())
    assert address == state['address']
    expected = [state['replacement' if state['mask'] & (1<<i) else 'original'][i] for i in range(6)]
    assert pfns(before) == expected, (pfns(before), expected)
parked, temporary = state['parked'], state['temporary']
for i in range(6):
    if (state['mask'] ^ {mask}) & (1<<i):
        active = address + i*4096
        other = parked + i*4096
        assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)' % (active, temporary)) == temporary
        assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)' % (other, active)) == active
        assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)' % (temporary, other)) == other
inferior.write_memory(address, saved)
assert bytes(inferior.read_memory(address, 24576)) == saved
state['mask'] = {mask}
after = frames()
expected = [state['replacement' if {mask} & (1<<i) else 'original'][i] for i in range(6)]
assert pfns(after) == expected, (pfns(after), expected)
slots.write_text(json.dumps(state, indent=2))
Path({str(prefix)+'.backing.json'!r}).write_text(json.dumps(dict(before=before, after=after, state=state, restored_bytes=len(saved)), indent=2))
print('BACKING', json.dumps(state), 'restored bytes', len(saved))
'''
    script = f'''set pagination off
set confirm off
attach {worker.process.pid}
break *{pc:#x}
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
disable 1
python
{body}
end
detach
quit
end
python open({str(ready)!r},'w').write('ready')
continue
'''
    Path(str(prefix) + '.gdb').write_text(script)
    with Path(str(prefix) + '.gdb-log').open('w') as log:
        debugger = subprocess.Popen(['gdb','-q','-nx','-batch','-x',str(prefix)+'.gdb'], stdout=log, stderr=subprocess.STDOUT)
        until = time.monotonic()+15
        while not ready.exists() and debugger.poll() is None and time.monotonic()<until:
            time.sleep(.05)
        if not ready.exists():
            debugger.terminate()
            debugger.wait(timeout=5)
            raise RuntimeError(Path(str(prefix)+'.gdb-log').read_text())
        worker.sample('debug-'+label, 1)
        debugger.wait(timeout=15)
        assert debugger.returncode == 0, Path(str(prefix)+'.gdb-log').read_text()
    save({'action':'backing','worker':worker.index,'phase':label,'evidence':json.loads(Path(str(prefix)+'.backing.json').read_text())})
    print('backing', worker.index, label, mask, flush=True)


def event_count(worker, phase, event):
    lines = (OUT/f'{worker.index}-{phase}.csv').read_text().splitlines()
    return next(float(line.split(',')[0]) for line in lines if len(line.split(','))>2 and line.split(',')[2] == event)


def measure(worker, phase, events=CORE):
    worker.profile(phase, events)
    print('cycles', worker.index, phase, event_count(worker, phase, 'cycles:u'), flush=True)


try:
    workers = [Worker(i) for i in range(args.workers)]
    for worker in workers:
        measure(worker, 'screen')
    ranked = sorted(workers, key=lambda w:event_count(w, 'screen', 'cycles:u'))
    control, slow = ranked[0], ranked[-1]
    selected = {'slow':slow.index,'control':control.index,'pids':{str(w.index):w.process.pid for w in workers}}
    (OUT/'selected.json').write_text(json.dumps(selected, indent=2))
    print('selected', selected, flush=True)
    for worker in workers:
        if worker not in (control, slow):
            worker.process.stdin.close()
            worker.process.wait(timeout=5)
    for rep in range(2):
        measure(slow, f'original-{rep}')
        measure(control, f'control-original-{rep}')
    set_backing(slow, 63, 'all-replacement')
    for rep in range(2):
        measure(slow, f'all-replacement-{rep}')
        measure(control, f'control-all-replacement-{rep}')
    print('READY for commands', flush=True)
    commands = OUT/'commands.jsonl'
    commands.touch()
    with commands.open() as stream:
        idle = time.monotonic()
        while time.monotonic()-idle < 1800:
            line = stream.readline()
            if not line:
                time.sleep(.25)
                continue
            command = json.loads(line)
            idle = time.monotonic()
            print('command', command, flush=True)
            if command['action'] == 'stop':
                break
            if command['action'] == 'mask':
                set_backing(slow, command['mask'], command['label'])
            elif command['action'] == 'profile':
                worker = slow if command.get('worker', 'slow') == 'slow' else control
                measure(worker, command['label'], command.get('events', CORE))
            elif command['action'] == 'record':
                worker = slow if command.get('worker', 'slow') == 'slow' else control
                worker.profile(command['label'], record=True)
            else:
                raise ValueError(command)
            print('DONE', command['label'], flush=True)
finally:
    for process in processes:
        if process.poll() is None:
            process.stdin.close()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=5)
    output.close()
