"""Compare wheel, recompiled unchanged kernel, and metadata-hoisted kernel."""
import json
from pathlib import Path
import subprocess
import time

root=Path('/tmp/clifft-656-placement')
directory=root/'direct-rc1-page-subsets'
selected=json.loads((directory/'selected.json').read_text())
worker=selected['slow'];pid=selected['pids'][str(worker)]
hook=json.loads((directory/f'{worker}-install-candidate.hook.json').read_text())
log=root/'direct-rc1-page-subsets.log'

def request(command):
 with (directory/'commands.jsonl').open('a') as stream:stream.write(json.dumps(command)+'\n')
 until=time.monotonic()+60
 marker='DONE '+command['label']+'\n'
 while time.monotonic()<until:
  if marker in log.read_text():return
  time.sleep(.1)
 raise RuntimeError('Timed out: '+str(command))

def set_mode(mode,label):
 script=directory/f'{worker}-{label}-mode.gdb'
 script.write_text(f'set pagination off\nset confirm off\nattach {pid}\nset {{int}}{hook["mode"]:#x} = {mode}\ndetach\nquit\n')
 result=subprocess.run(['gdb','-q','-nx','-batch','-x',str(script)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=20)
 script.with_suffix('.gdb-log').write_text(result.stdout)
 assert result.returncode==0,result.stdout

for stage,mode in enumerate([0,1,2,2,1,0]):
 for mask in ([4,12] if stage%2==0 else [12,4]):
  label=f'candidate-{stage}-mode-{mode}-mask-{mask}'
  set_mode(0,label+'prepare')
  request({'action':'mask','mask':mask,'label':label+'-backing'})
  set_mode(mode,label+'run')
  request({'action':'profile','label':label})
  print('DONE',label,flush=True)
 if stage in [1,3,5]:request({'action':'profile','worker':'control','label':f'control-candidate-{stage}'})
set_mode(0,'candidate-finish')
print('FINISHED',flush=True)
