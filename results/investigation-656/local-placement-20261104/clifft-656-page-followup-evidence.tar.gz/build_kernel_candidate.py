from pathlib import Path
source=Path('/home/exedev/.codex/worktrees/bd34/clifft-codex/src/clifft/sampling/kernels_avx512.cc').read_text()
function=source[source.index('template <bool RealPhase>\nvoid apply_nondiagonal_rotation_avx512('):source.index('\nvoid apply_diagonal_rotation_avx512_parallel')]
# Keep the arithmetic identical; only cache immutable loop metadata in variant 2.
baseline=function.replace('apply_nondiagonal_rotation_avx512','probe_baseline').replace('void probe_baseline','__attribute__((noinline,aligned(64))) void probe_baseline')
hoisted=function.replace('apply_nondiagonal_rotation_avx512','probe_hoisted').replace('void probe_hoisted','__attribute__((noinline,aligned(64))) void probe_hoisted')
anchor='    for (uint64_t block = 0; block < state.size(); block += pair_period) {'
hoisted=hoisted.replace(anchor,'    const uint64_t size = state.size();\n    const uint64_t x = rotation.pauli.x;\n    const uint64_t z = rotation.pauli.z;\n    for (uint64_t block = 0; block < size; block += pair_period) {')
hoisted=hoisted.replace('(left ^ rotation.pauli.x)','(left ^ x)').replace('signed_sine_lanes(left, rotation.pauli.z,','signed_sine_lanes(left, z,')
header='''// Temporary in-process diagnostic; not production code.
#include "clifft/sampling/kernel_dispatch.h"
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <immintrin.h>
using namespace clifft::sampling;
namespace {
constexpr size_t kLanes=8;
using LaneIndices=std::array<uint64_t,kLanes>;
using LaneSigns=std::array<double,kLanes>;
'''
for first,last in [('constexpr std::array<LaneIndices, kLanes> make_lane_permutations()', '\nconstexpr std::array<std::array<LaneIndices, 2>, kLanes> make_diagonal_compaction_permutations()'),('constexpr std::array<LaneSigns, kLanes> make_lane_parity_signs()', '\nalignas(64) constexpr auto kLanePermutations'),('__m512d signed_sine_lanes(', '\n// A diagonal Pauli')]:
 fragment=source[source.index(first):source.index(last)]
 if first.startswith('__m512d'):header+='alignas(64) constexpr auto kLanePermutations = make_lane_permutations();\nalignas(64) constexpr auto kLaneParitySigns = make_lane_parity_signs();\n'
 header+=fragment+'\n'
footer='''
}
extern "C" {
using Original = void (*)(State&,const PreparedRotation&,DirectRotationKernel,bool);
Original probe_original = nullptr;
int probe_mode = 0;
void probe_dispatch(State& state,const PreparedRotation& rotation,DirectRotationKernel kernel,bool sign) noexcept {
    if (probe_mode && kernel==DirectRotationKernel::HighPivot && rotation.pauli.even_phase.real()!=0.0) {
        const double sine=sign ? -rotation.sine : rotation.sine;
        if (probe_mode==1) probe_baseline<true>(state,rotation,sine);
        else probe_hoisted<true>(state,rotation,sine);
    } else probe_original(state,rotation,kernel,sign);
}
}
'''
Path('/tmp/clifft-656-placement/kernel_candidate.cc').write_text(header+baseline+hoisted+footer)
