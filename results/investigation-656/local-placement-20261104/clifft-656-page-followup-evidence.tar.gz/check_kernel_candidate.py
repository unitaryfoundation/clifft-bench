import ctypes as c
import json
from pathlib import Path
import random
import clifft
root=Path('/tmp/clifft-656-placement')
mapping=next(line.split() for line in Path('/proc/self/maps').read_text().splitlines() if '_clifft_core.abi3.so' in line and 'r-xp' in line)
function=int(mapping[0].split('-')[0],16)+0x1c52b0-int(mapping[2],16)
helper=c.CDLL(str(root/'kernel_probe.so'))
helper.make_state.restype=c.c_void_p
helper.initialize_state.argtypes=[c.c_void_p]
helper.drop_state.argtypes=[c.c_void_p]
helper.real_pointer.argtypes=[c.c_void_p]
helper.real_pointer.restype=c.c_uint64
helper.make_rotation.argtypes=[c.c_void_p,c.c_uint64,c.c_uint64]
helper.run_kernel.argtypes=[c.c_uint64,c.c_void_p,c.c_void_p,c.c_uint64]
helper.run_kernel.restype=c.c_double
candidate=c.CDLL(str(root/'kernel_candidate.so'))
c.c_void_p.in_dll(candidate,'probe_original').value=function
mode=c.c_int.in_dll(candidate,'probe_mode')
dispatch=c.cast(candidate.probe_dispatch,c.c_void_p).value
state=helper.make_state()
buffer=c.create_string_buffer(256)
rot=c.addressof(buffer)
rand=random.Random(656)
cases=[(666,0),(512,3)]+[(rand.randrange(8,1024),rand.randrange(1024)) for _ in range(100)]
try:
 for x,z in cases:
  helper.make_rotation(rot,x,z)
  helper.initialize_state(state)
  helper.run_kernel(function,state,rot,31)
  expected=c.string_at(helper.real_pointer(state),16384)
  for variant in [1,2]:
   mode.value=variant
   helper.initialize_state(state)
   helper.run_kernel(dispatch,state,rot,31)
   assert c.string_at(helper.real_pointer(state),16384)==expected,(x,z,variant)
finally:helper.drop_state(state)
result={'cases':len(cases),'variants':[1,2],'width':10,'rotations_per_case':31,'coefficient_bytes_equal':True}
(root/'kernel-candidate-check.json').write_text(json.dumps(result,indent=2))
print(result)
