## Local follow-up: one coefficient page is sufficient; a kernel change helps partially

The follow-up isolates a **single 4 KiB coefficient page** whose backing changes d5's fixed-work cost by about **12.7%** in one retained worker. Scratch pages, virtual addresses, code, data, and seeded work are held fixed. A small experimental kernel change improves both tested backings, but leaves a substantial difference. This does not change the accepted RC decision or establish the cause of the EC2 variation.

### Protocol and identity

- Same EPYC 9554P/KVM VM, CPU 0; same published `0.13.0rc1` wheel, extension SHA256 `75b71fd3f1f6c2a22141f3f965bd02958f0a68a2d4d08be7b406e006ee2207b4`.
- Pinned harness `d2e711f61b4cad439a5f1752edefc51bb96905f1`, unchanged workload and adapter; the diagnostic worker replaces duration stopping with fixed API-call counts. Direct batch-1 preparation, no full calibration; ASLR disabled, `PYTHONHASHSEED=0`, existing thread limits, CPU affinity and 12 GiB ceiling.
- Eight fresh workers screened with one 2m-shot pass each. Keep worker 5 and unmodified control 3 alive. Every measured pass is 100 calls of 20,000 attempted shots, seeds 20270819..20270918. Page interventions occur during separate diagnostic calls; those rows are excluded from timing comparisons.
- 124 sample requests, including 44 one-call debugger passes and 80 profiled passes. One of the 80 installs the experimental hook and is also excluded from timing conclusions. All 160,880,000 attempted shots validate: every 100-call pass returns 287,417 accepted, 1,712,583 discarded, zero logical errors; each one-call pass returns 2,852 accepted, 17,148 discarded, zero logical errors. Eight initial correctness checks pass. All new counters report 100% running; at most four hardware events per pass.

### Selective backing test

Six 4 KiB pages hold real coefficients (pages 0,1), imaginary coefficients (2,3), and scratch (4,5). Original backing A and replacement B are retained. At a breakpoint, save all 24 KiB, exchange selected pages using `mremap`, restore the bytes, and verify guest PFNs against the intended selection. The State is still created/destroyed by each public sample call; its allocation is reused. These are diagnostic page exchanges, not a proposed allocation policy.

Original PFNs: `[6341216,6114220,6960043,6624519,8300149,4112251]`.
Replacement PFNs: `[6096145,7690256,4762370,4941122,6294396,6942200]`.
A mask bit selects B for that page. The exploratory coefficient matrix covers all 16 combinations with scratch on A. Whole-allocation and scratch-only comparisons are also retained in the CSV. Replacement is not automatically faster; the combinations matter.

The selected confirmation compares mask 4 (`A,A,B,A,A,A`) with mask 12 (`A,A,B,B,A,A`). **Only page 3 differs:** the upper half of the imaginary coefficient array, at `0x12d4000`. The exchange changes its guest PFN between 6624519 and 4941122. Real base remains `0x12d1000`, imaginary base `0x12d3000`, State `0x1472408`, rotation `0x12bf320`, and the inspected hot-loop PC `0x7ffff1deb420`.

After exploring the combinations, repeat this selected pair in 4/12/12/4 order:

| Backing mask | Median cycles, same 2m shots | Instructions | Median wall throughput |
| --- | ---: | ---: | ---: |
| 4 | 36.877b | 91.666407b | 180.4k shots/s |
| 12 | 41.554b | 91.666409b | 160.1k shots/s |

Each row has two confirmation passes. Mask 12 costs 12.684% more cycles. The unmodified control ranges 34.13–35.08b cycles over the full campaign. Wall time varies more on this VM, so the causal comparison emphasizes fixed-work cycles. This is a selected, within-worker contrast, not a population effect size or release percentage. The scratch-only exchanges in this pair do not produce a comparable change. Guest PFNs are not host physical addresses.

### Targeted counters

Each counter group has cycles/instructions plus two named events, measured under both retained masks, alternating order by group. The 9.8–13.2% cycle gap remains; instruction counts match.

| Event, mask 12 versus 4 | Change |
| --- | ---: |
| Backend dispatch stall slots | +21.82% |
| Non-forwardable store/load conflicts | -15.36% |
| Load/store miss-address-buffer allocations | +0.87% |
| In-flight miss-address-buffer occupancy sum | +1.03% |
| L1 data-TLB misses | -0.94% |
| L2 data-TLB misses / requested walks | -4.17% |
| Demand fills from local L2 | +0.57% |
| Demand fills from local CCX | +15.61% (8.34m to 9.64m) |

These measurements do not support a simple explanation based on a large increase in cache-miss, translation-miss, or conflict *counts*. They do not rule out latency, ordering, replay, or prediction effects. The exact CPU/VM mechanism remains unresolved. This VM exposes no `ibs_op`/`ibs_fetch` PMUs, so instruction-level AMD IBS latency sampling is unavailable here.

### Experimental mitigation

The high-pivot AVX-512 rotation repeatedly reloads immutable X/Z masks and the State size while writing coefficients. A temporary variant snapshots those three values before the loops; arithmetic and pairing remain identical. It adds no hot allocation. The prototype only replaces the real-phase, high-pivot path; other paths use the wheel's original implementation.

Clang 22.1.8 compiles an unchanged source copy and the modified copy into the same diagnostic library. Source is taken from `6abe2509d57acedbae2b2b497e28379f106194f4`; this kernel is unchanged by #655. An in-process entry hook selects the original wheel, unchanged copy, or modified copy. This keeps the same live worker and backing sets for all variants. It is a diagnostic hook, not a built wheel. Code locations differ between variants, so the experiment does not isolate every effect of code generation/layout.

Run variants in 0/1/2/2/1/0 order, reversing backing order on alternating stages. Two measured passes per table cell:

| Kernel | Mask 4 cycles | Mask 12 cycles | Backing gap |
| --- | ---: | ---: | ---: |
| Wheel through hook | 37.357b | 41.380b | 10.77% |
| Unchanged source copy | 36.079b | 41.284b | 14.43% |
| Metadata cached before loops | 34.533b | 37.450b | 8.45% |

Against the unchanged copy, the variant reduces cycles **4.29% and 9.29%**, respectively; retired instructions fall from 91.953b to 88.623b. The unchanged copy retains the backing sensitivity, which is an important rebuild control. The modified copy improves both cases but does **not** eliminate the sensitivity.

Before the full d5 comparison, both compiled variants match the wheel's full coefficient bytes on 102 synthetic width-10 rotation cases, 31 applications each. All full d5 passes retain the exact seeded aggregate counts. This is preliminary correctness/performance evidence, not the full regression suite or cross-workload validation. Original machine code and original backing are restored, a final pass validates, and both workers exit successfully. No production source is changed, no PR is opened, and no EC2 work is launched.

### Follow-up supported by this evidence

1. Validate the small metadata-caching change as a normal source patch with matched compiler/build settings, fresh processes, the SIMD correctness suite, and Draper/d3/surface/QV controls. Do not call it a fix for #656 based on this one-worker prototype.
2. Retain the single-page reproducer while reducing the remaining slow loop to a small controlled workload. Investigate load/store ordering and metadata dependencies separately; do not label the cause as a specific cache conflict from these counters.
3. A later, separately authorized reference-host run should confirm whether the same intervention explains EC2 d5, then validate any candidate wheel. This local evidence still does not identify a source regression to bisect or a trustworthy release-change percentage.
