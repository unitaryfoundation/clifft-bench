// Temporary ABI probe for the immutable wheel's AVX-512 rotation entry point.
#include "clifft/sampling/kernel_dispatch.h"
#include "clifft/sampling/state.h"
#include <bit>
#include <cmath>
#include <cstdint>
#include <new>

using namespace clifft::sampling;

extern "C" void* make_state() {
    return new State(10, 10);
}

extern "C" void drop_state(void* raw) {
    delete static_cast<State*>(raw);
}

extern "C" void initialize_state(void* raw) {
    auto& state = *static_cast<State*>(raw);
    for (uint64_t i = 0; i < state.size(); ++i) {
        state.real()[i] = static_cast<double>((i * 17 + 3) % 101 + 1) / 2048;
        state.imag()[i] = static_cast<double>((i * 19 + 7) % 97 + 1) / 2048;
    }
}

extern "C" void make_rotation(void* storage, uint64_t x, uint64_t z) {
    auto* rotation = new (storage) PreparedRotation;
    rotation->pauli.active_width = 10;
    rotation->pauli.x = x;
    rotation->pauli.z = z;
    rotation->pauli.pairing_bit = uint64_t{1} << (63 - std::countl_zero(x));
    rotation->pauli.even_phase = (std::popcount(x & z) & 1) ?
        std::complex<double>(0.0, 1.0) : std::complex<double>(1.0, 0.0);
    rotation->cosine = std::cos(std::acos(-1.0) / 8);
    rotation->sine = std::sin(std::acos(-1.0) / 8);
}

extern "C" double run_kernel(uintptr_t address, void* state_raw, const void* rotation_raw,
                               uint64_t calls) {
    using Function = void (*)(State&, const PreparedRotation&, DirectRotationKernel, bool);
    auto function = reinterpret_cast<Function>(address);
    auto& state = *static_cast<State*>(state_raw);
    const auto& rotation = *static_cast<const PreparedRotation*>(rotation_raw);
    for (uint64_t i = 0; i < calls; ++i) {
        function(state, rotation, DirectRotationKernel::HighPivot, (i & 1) != 0);
    }
    double sum = 0;
    for (uint64_t i = 0; i < state.size(); ++i) sum += state.real()[i] + state.imag()[i];
    return sum;
}

extern "C" uintptr_t real_pointer(void* raw) {
    return reinterpret_cast<uintptr_t>(static_cast<State*>(raw)->real_data());
}
