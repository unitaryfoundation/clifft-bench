// Temporary in-process diagnostic; not production code.
#include "clifft/sampling/kernel_dispatch.h"
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <immintrin.h>
using namespace clifft::sampling;
namespace {
constexpr size_t kLanes=8;
using LaneIndices=std::array<uint64_t,kLanes>;
using LaneSigns=std::array<double,kLanes>;
constexpr std::array<LaneIndices, kLanes> make_lane_permutations() {
    std::array<LaneIndices, kLanes> result{};
    for (size_t lane_xor = 0; lane_xor < kLanes; ++lane_xor) {
        for (size_t lane = 0; lane < kLanes; ++lane) {
            result[lane_xor][lane] = lane ^ lane_xor;
        }
    }
    return result;
}

constexpr std::array<LaneSigns, kLanes> make_lane_parity_signs() {
    std::array<LaneSigns, kLanes> result{};
    for (size_t z = 0; z < kLanes; ++z) {
        for (size_t lane = 0; lane < kLanes; ++lane) {
            result[z][lane] = (std::popcount(z & lane) & 1U) != 0 ? -1.0 : 1.0;
        }
    }
    return result;
}

alignas(64) constexpr auto kLanePermutations = make_lane_permutations();
alignas(64) constexpr auto kLaneParitySigns = make_lane_parity_signs();
__m512d signed_sine_lanes(uint64_t basis, uint64_t z, double sine) noexcept {
    const bool high_parity = (std::popcount(basis & z) & 1U) != 0;
    const double block_sine = high_parity ? -sine : sine;
    const __m512d lane_signs = _mm512_load_pd(kLaneParitySigns[z & (kLanes - 1)].data());
    return _mm512_mul_pd(_mm512_set1_pd(block_sine), lane_signs);
}

template <bool RealPhase>
__attribute__((noinline,aligned(64))) void probe_baseline(State& state, const PreparedRotation& rotation,
                                       double sine) noexcept {
    assert(!rotation.pauli.is_diagonal() && rotation.pauli.pairing_bit >= kLanes &&
           "AVX-512 non-diagonal rotation requires a high pairing pivot");
    double* const real = state.real_data();
    double* const imag = state.imag_data();
    const uint64_t pair_stride = rotation.pauli.pairing_bit;
    const uint64_t pair_period = pair_stride << 1;
    const uint64_t lane_xor = rotation.pauli.x & (kLanes - 1);
    const __m512i permutation = _mm512_load_si512(kLanePermutations[lane_xor].data());
    const __m512d cosine = _mm512_set1_pd(rotation.cosine);
    const double base_phase =
        RealPhase ? rotation.pauli.even_phase.real() : rotation.pauli.even_phase.imag();
    const double even_left_sine = sine * base_phase;

    for (uint64_t block = 0; block < state.size(); block += pair_period) {
        for (uint64_t offset = 0; offset < pair_stride; offset += kLanes) {
            const uint64_t left = block + offset;
            const uint64_t right_base = (left ^ rotation.pauli.x) & ~(uint64_t{kLanes - 1});
            const __m512d left_real = _mm512_load_pd(real + left);
            const __m512d left_imag = _mm512_load_pd(imag + left);
            const __m512d right_real =
                _mm512_permutexvar_pd(permutation, _mm512_load_pd(real + right_base));
            const __m512d right_imag =
                _mm512_permutexvar_pd(permutation, _mm512_load_pd(imag + right_base));
            const __m512d left_sine = signed_sine_lanes(left, rotation.pauli.z, even_left_sine);

            __m512d output_left_real;
            __m512d output_left_imag;
            __m512d output_right_real;
            __m512d output_right_imag;
            if constexpr (RealPhase) {
                output_left_real =
                    _mm512_fmadd_pd(left_sine, right_imag, _mm512_mul_pd(cosine, left_real));
                output_left_imag =
                    _mm512_fnmadd_pd(left_sine, right_real, _mm512_mul_pd(cosine, left_imag));
                output_right_real =
                    _mm512_fmadd_pd(left_sine, left_imag, _mm512_mul_pd(cosine, right_real));
                output_right_imag =
                    _mm512_fnmadd_pd(left_sine, left_real, _mm512_mul_pd(cosine, right_imag));
            } else {
                output_left_real =
                    _mm512_fnmadd_pd(left_sine, right_real, _mm512_mul_pd(cosine, left_real));
                output_left_imag =
                    _mm512_fnmadd_pd(left_sine, right_imag, _mm512_mul_pd(cosine, left_imag));
                output_right_real =
                    _mm512_fmadd_pd(left_sine, left_real, _mm512_mul_pd(cosine, right_real));
                output_right_imag =
                    _mm512_fmadd_pd(left_sine, left_imag, _mm512_mul_pd(cosine, right_imag));
            }

            _mm512_store_pd(real + left, output_left_real);
            _mm512_store_pd(imag + left, output_left_imag);
            _mm512_store_pd(real + right_base,
                            _mm512_permutexvar_pd(permutation, output_right_real));
            _mm512_store_pd(imag + right_base,
                            _mm512_permutexvar_pd(permutation, output_right_imag));
        }
    }
}
template <bool RealPhase>
__attribute__((noinline,aligned(64))) void probe_hoisted(State& state, const PreparedRotation& rotation,
                                       double sine) noexcept {
    assert(!rotation.pauli.is_diagonal() && rotation.pauli.pairing_bit >= kLanes &&
           "AVX-512 non-diagonal rotation requires a high pairing pivot");
    double* const real = state.real_data();
    double* const imag = state.imag_data();
    const uint64_t pair_stride = rotation.pauli.pairing_bit;
    const uint64_t pair_period = pair_stride << 1;
    const uint64_t lane_xor = rotation.pauli.x & (kLanes - 1);
    const __m512i permutation = _mm512_load_si512(kLanePermutations[lane_xor].data());
    const __m512d cosine = _mm512_set1_pd(rotation.cosine);
    const double base_phase =
        RealPhase ? rotation.pauli.even_phase.real() : rotation.pauli.even_phase.imag();
    const double even_left_sine = sine * base_phase;

    const uint64_t size = state.size();
    const uint64_t x = rotation.pauli.x;
    const uint64_t z = rotation.pauli.z;
    for (uint64_t block = 0; block < size; block += pair_period) {
        for (uint64_t offset = 0; offset < pair_stride; offset += kLanes) {
            const uint64_t left = block + offset;
            const uint64_t right_base = (left ^ x) & ~(uint64_t{kLanes - 1});
            const __m512d left_real = _mm512_load_pd(real + left);
            const __m512d left_imag = _mm512_load_pd(imag + left);
            const __m512d right_real =
                _mm512_permutexvar_pd(permutation, _mm512_load_pd(real + right_base));
            const __m512d right_imag =
                _mm512_permutexvar_pd(permutation, _mm512_load_pd(imag + right_base));
            const __m512d left_sine = signed_sine_lanes(left, z, even_left_sine);

            __m512d output_left_real;
            __m512d output_left_imag;
            __m512d output_right_real;
            __m512d output_right_imag;
            if constexpr (RealPhase) {
                output_left_real =
                    _mm512_fmadd_pd(left_sine, right_imag, _mm512_mul_pd(cosine, left_real));
                output_left_imag =
                    _mm512_fnmadd_pd(left_sine, right_real, _mm512_mul_pd(cosine, left_imag));
                output_right_real =
                    _mm512_fmadd_pd(left_sine, left_imag, _mm512_mul_pd(cosine, right_real));
                output_right_imag =
                    _mm512_fnmadd_pd(left_sine, left_real, _mm512_mul_pd(cosine, right_imag));
            } else {
                output_left_real =
                    _mm512_fnmadd_pd(left_sine, right_real, _mm512_mul_pd(cosine, left_real));
                output_left_imag =
                    _mm512_fnmadd_pd(left_sine, right_imag, _mm512_mul_pd(cosine, left_imag));
                output_right_real =
                    _mm512_fmadd_pd(left_sine, left_real, _mm512_mul_pd(cosine, right_real));
                output_right_imag =
                    _mm512_fmadd_pd(left_sine, left_imag, _mm512_mul_pd(cosine, right_imag));
            }

            _mm512_store_pd(real + left, output_left_real);
            _mm512_store_pd(imag + left, output_left_imag);
            _mm512_store_pd(real + right_base,
                            _mm512_permutexvar_pd(permutation, output_right_real));
            _mm512_store_pd(imag + right_base,
                            _mm512_permutexvar_pd(permutation, output_right_imag));
        }
    }
}

}
extern "C" {
using Original = void (*)(State&,const PreparedRotation&,DirectRotationKernel,bool);
Original probe_original = nullptr;
int probe_mode = 0;
void probe_dispatch(State& state,const PreparedRotation& rotation,DirectRotationKernel kernel,bool sign) noexcept {
    if (probe_mode && kernel==DirectRotationKernel::HighPivot && rotation.pauli.even_phase.real()!=0.0) {
        const double sine=sign ? -rotation.sine : rotation.sine;
        if (probe_mode==1) probe_baseline<true>(state,rotation,sine);
        else probe_hoisted<true>(state,rotation,sine);
    } else probe_original(state,rotation,kernel,sign);
}
}
