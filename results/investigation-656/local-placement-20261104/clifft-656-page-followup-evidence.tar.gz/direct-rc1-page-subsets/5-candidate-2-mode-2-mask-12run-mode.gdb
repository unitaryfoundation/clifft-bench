set pagination off
set confirm off
attach 3959879
set {int}0x7ffff768f030 = 2
detach
quit
