set pagination off
set confirm off
attach 3959879
python
import json
from pathlib import Path
slots=Path('/tmp/clifft-656-placement/direct-rc1-page-subsets/5-backing.json')
state=json.loads(slots.read_text())
previous=state['temporary']
state['temporary']=int(gdb.parse_and_eval('(long)mmap((void*)0,4096,3,34,-1,0)'))
assert state['temporary'] not in (-1,0,previous)
slots.write_text(json.dumps(state,indent=2))
print('TEMPORARY',previous,state['temporary'])
end
detach
quit
