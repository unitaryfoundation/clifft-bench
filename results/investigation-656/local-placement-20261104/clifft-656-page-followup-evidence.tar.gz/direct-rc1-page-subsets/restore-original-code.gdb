set pagination off
set confirm off
attach 3959879
python
inferior=gdb.selected_inferior()
original=bytes.fromhex('55415741564155415453c5fb105e38')
inferior.write_memory(140737251291824,original)
assert bytes(inferior.read_memory(140737251291824,15))==original
print('Original function entry restored')
end
detach
quit
