set pagination off
set confirm off
attach 3959879
break *0x7ffff1deb420
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
disable 1
python
import json,struct
from pathlib import Path
inferior=gdb.selected_inferior()
lines=Path('/proc/%d/maps'%inferior.pid).read_text().splitlines()
mapping=next(line.split() for line in lines if '_clifft_core.abi3.so' in line and 'r-xp' in line)
entry=int(mapping[0].split('-')[0],16)+0x1c52b0-int(mapping[2],16)
original=bytes(inferior.read_memory(entry,15))
assert original == bytes.fromhex('55 41 57 41 56 41 55 41 54 53 c5 fb 10 5e 38'),original.hex()
def call(expression):
 value=int(gdb.parse_and_eval(expression));assert value not in [-1,0,(1<<64)-1],expression
 return value
library=call('(long)dlopen("/tmp/clifft-656-placement/kernel_candidate.so",2)')
dispatch=call('(long)dlsym((void*)%d,"probe_dispatch")'%library)
mode=call('(long)dlsym((void*)%d,"probe_mode")'%library)
original_slot=call('(long)dlsym((void*)%d,"probe_original")'%library)
trampoline=call('(long)mmap((void*)0,4096,7,34,-1,0)')
def jump(target):return b'\xff\x25\x00\x00\x00\x00'+struct.pack('<Q',target)
inferior.write_memory(trampoline,original+jump(entry+15))
inferior.write_memory(original_slot,struct.pack('<Q',trampoline))
inferior.write_memory(mode,struct.pack('<I',0))
inferior.write_memory(entry,jump(dispatch)+b'\x90')
info=dict(entry=entry,original=original.hex(),library=library,dispatch=dispatch,mode=mode,trampoline=trampoline)
Path('/tmp/clifft-656-placement/direct-rc1-page-subsets/5-install-candidate'+'.hook.json').write_text(json.dumps(info,indent=2))
print('HOOK',json.dumps(info))

end
detach
quit
end
python open('/tmp/clifft-656-placement/direct-rc1-page-subsets/5-install-candidate.ready','w').write('ready')
continue
