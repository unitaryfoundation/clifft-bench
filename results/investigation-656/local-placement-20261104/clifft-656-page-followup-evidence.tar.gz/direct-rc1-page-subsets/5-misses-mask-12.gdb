set pagination off
set confirm off
attach 3959879
break *0x7ffff1deb420
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
disable 1
python

import json, subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
def frames():
    return json.loads(subprocess.check_output(['sudo','-n','python3','/tmp/clifft-656-placement/page_frames.py',str(inferior.pid),str(address),'6'],text=True))
def pfns(value):
    return value['pfns']
def call(expression):
    value = int(gdb.parse_and_eval(expression))
    assert value != -1 and value != (1<<64)-1, expression
    return value
before = frames()
slots = Path('/tmp/clifft-656-placement/direct-rc1-page-subsets/5-backing.json')
if not slots.exists():
    original = pfns(before)
    parked = call('(long)mmap((void*)0,24576,3,34,-1,0)')
    temporary = call('(long)mmap((void*)0,4096,3,34,-1,0)')
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address, parked)) == parked
    assert call('(long)mmap((void*)%d,24576,3,50,-1,0)' % address) == address
    inferior.write_memory(address, saved)
    replacement = pfns(frames())
    assert all(a != b for a, b in zip(original, replacement))
    state = dict(address=address, parked=parked, temporary=temporary, original=original, replacement=replacement, mask=63)
else:
    state = json.loads(slots.read_text())
    assert address == state['address']
    expected = [state['replacement' if state['mask'] & (1<<i) else 'original'][i] for i in range(6)]
    assert pfns(before) == expected, (pfns(before), expected)
parked, temporary = state['parked'], state['temporary']
for i in range(6):
    if (state['mask'] ^ 12) & (1<<i):
        active = address + i*4096
        other = parked + i*4096
        assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)' % (active, temporary)) == temporary
        assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)' % (other, active)) == active
        assert call('(long)mremap((void*)%d,4096,4096,3,(void*)%d)' % (temporary, other)) == other
inferior.write_memory(address, saved)
assert bytes(inferior.read_memory(address, 24576)) == saved
state['mask'] = 12
after = frames()
expected = [state['replacement' if 12 & (1<<i) else 'original'][i] for i in range(6)]
assert pfns(after) == expected, (pfns(after), expected)
slots.write_text(json.dumps(state, indent=2))
Path('/tmp/clifft-656-placement/direct-rc1-page-subsets/5-misses-mask-12.backing.json').write_text(json.dumps(dict(before=before, after=after, state=state, restored_bytes=len(saved)), indent=2))
print('BACKING', json.dumps(state), 'restored bytes', len(saved))

end
detach
quit
end
python open('/tmp/clifft-656-placement/direct-rc1-page-subsets/5-misses-mask-12.ready','w').write('ready')
continue
