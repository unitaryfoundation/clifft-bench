## Status

The maintainer accepts the unresolved d5 performance risk and is proceeding with the RC. #655 is merged; its matched-build Draper improvement is independently validated. This issue now tracks the cause and mitigation of d5's persistent process-to-process variation.

**Local investigation has demonstrated a causal dependency on the backing pages of the scalar State allocation.** The same published RC wheel becomes fast or slow when its original versus replacement pages are mapped at the same virtual address. The precise CPU/VM mechanism and a production fix remain open. The EC2 behavior has not yet been causally linked to this local mechanism.

[Local evidence, counter data and reproduction scripts](https://github.com/unitaryfoundation/clifft/issues/656#issuecomment-6632836484).

## Current local finding

On this EPYC 9554P VM, keep one d5 process, its code, virtual addresses, seeds and work unchanged. Exchange the backing of its 24 KiB coefficient/scratch allocation while preserving all bytes. Retain both page sets and restore them in A/B/A/B order:

| Backing in the same process | Median throughput | Cycles for the same 2m attempted shots |
| --- | ---: | ---: |
| Original A | 185k shots/s | 38.331b |
| Replacement B | 201k shots/s | 34.394b |
| Original A restored | 186k shots/s | 38.194b |
| Replacement B restored | 207k shots/s | 34.381b |

Instructions stay at 91.6664b, and every pass returns identical aggregate counts. Guest page-frame identities verify that A and B are restored exactly. An interleaved, unmodified process stays around 34-35b cycles. The about 10.3% reduction in cycles is a **local backing comparison**, not a release-change estimate.

Profiling concentrates the extra cost in the AVX-512 high-pivot rotation. Disabling ASLR and fixing Python's hash seed does not remove the separation; debugger checks find matching code, State, array, descriptor and stack addresses. The backing experiment goes beyond those address controls. It does not yet identify a particular cache conflict, load/store dependency, translation effect or hypervisor contribution.

The evidence comment retains the protocol, exact extension identity, all 186 fixed-work sample/counter rows from 48 fresh workers, reproduction scripts, controls, excluded counter measurements and remaining limitations. Raw profiles and supporting artifacts are under `/tmp/clifft-656-placement/` on the VM. These fixed-work probes are diagnostics; official release measurements retain the pinned harness's five >=30-second samples.

## Release evidence retained

- Original release comparison: [clifft-bench #100](https://github.com/unitaryfoundation/clifft-bench/pull/100).
- [First EC2 campaign](https://github.com/unitaryfoundation/clifft-bench/tree/3bb234081a62c19b0854d99d554c5a15f4444c37/results/investigation-656/20261104-014655): 76 fresh workers / 380 samples. Published previous-to-RC d5 medians change by -6.77% after direct batch-1 preparation and +8.17% after full calibration. All calibrated d5 workers select batch 1.
- [Bounded interleaved repeat after stop/start](https://github.com/unitaryfoundation/clifft-bench/tree/8022e7386b1b804025738c2ee778dcc7f24a8059/results/investigation-656/20261104-113047): 16 workers / 80 samples. Direct comparison -4.02%; calibrated -1.35%; individual blocks change sign. Both releases have substantial between-process variation despite stable samples within each process.
- These results do not give d5 one trustworthy release-change percentage. The direct losses remain a material accepted risk. The previous release is also variable.
- #655 improves matched-build Draper throughput about 10.1%, with noisy d3 controls inside the 1.1% inconclusive band. It changes packed no-noise sampling; d5's final batch-1 execution is scalar. No parent-versus-patch d5 effect was measured. Measure the actual next candidate wheel rather than extrapolating the source-pair gain.
- D3's earlier large-batch decline did not reproduce; no batch-policy change or bisect is supported. The same-commit Draper wheel/source gap is build-dependent and is not proof of pure layout: compiler/LTO settings differ.

## Next investigation

1. Preserve the slow/fast backing reproducer. Separate coefficient-page from scratch-page effects and use targeted load/store or translation evidence to identify the CPU/VM mechanism. #604's different, established instruction-fetch case is useful background, not the explanation for this one.
2. Evaluate a general kernel or storage improvement against both backing sets. Preserve seeded semantics and allocation-free, exception-free hot execution. Picking favorable addresses/pages, global alignment flags or PGO alone does not resolve the demonstrated dependency.
3. Check any candidate change across fresh processes and matched builds, then on the actual built RC. A separately authorized reference-host confirmation should test the narrowed mechanism; no EC2 work is currently running from this investigation.
4. Bisect only a reproducible matched-build source difference after the backing/preparation controls. The local wheel experiment itself changes no source.

## Acceptance

- [x] A reproducible local intervention changes and restores the slow behavior with code, virtual addresses, data and work held fixed.
- [ ] Identify the underlying CPU/VM mechanism and establish how broadly it explains the release-host observations.
- [ ] Demonstrate a general mitigation on both adverse and favorable cases, with correctness and relevant workload controls.
- [ ] Validate the resulting shipped wheel and retain the release comparison's remaining uncertainty.
