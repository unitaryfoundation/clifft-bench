set pagination off
set confirm off
attach 10
break *0x7ffff1deb420
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
detach
quit
end
python open('/tmp/clifft-656-placement/direct-rc1-fixed-hash/6.gdb-ready','w').write('ready')
continue
