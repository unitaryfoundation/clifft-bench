## Local d5 investigation: changing and restoring backing pages changes and restores the slowdown

**A controlled A/B/A/B experiment establishes a local dependency on the backing pages of the scalar State's 24 KiB coefficient/scratch allocation.** The exact microarchitectural mechanism remains open. This is stronger than a correlation with preparation history, and it does not establish that every EC2 result has the same cause.

The maintainer has accepted the unresolved d5 release risk and merged #655. This investigation continues independently of preparing the next RC.

### The decisive experiment

One process uses the same published `0.13.0rc1` extension throughout. ASLR is disabled and `PYTHONHASHSEED=0`. The benchmark is the original d5 circuit and batch-1 aggregate survivor operation. Every measured pass performs exactly 100 calls of 20,000 attempted shots, with seeds `20270819..20270918`. Preparation, scheduler, detector postselection, no retained records, one thread and CPU affinity are preserved.

At a breakpoint in the AVX-512 high-pivot rotation, save all 24,576 allocation bytes. Use `mremap` to park the original six pages at another virtual address, map replacement pages at the original address, and restore the saved bytes. Subsequent interventions exchange the two existing page sets. Each exchange verifies identical restored bytes and records the guest page-frame numbers through `/proc/PID/pagemap`. These interventions happen outside measured passes. Both sets remain allocated, so restoring A really restores its original backing pages.

| State in the same process | Two measured throughputs, shots/s | Median cycles for 2m shots | Median instructions |
| --- | --- | ---: | ---: |
| A: original backing | 183,219; 186,926 | 38.331 billion | 91.6664 billion |
| B: replacement backing | 199,750; 202,725 | 34.394 billion | 91.6664 billion |
| A: original backing restored | 187,454; 185,370 | 38.194 billion | 91.6664 billion |
| B: replacement backing restored | 209,151; 204,882 | 34.381 billion | 91.6664 billion |

Each pass produces exactly **287,417 survivors, 1,712,583 discards and zero logical errors**. Replacement backing reduces cycles by about **10.3%** in both transitions from A. The original slow backing restores the higher cycle cost. Wall-clock throughput also varies with host conditions; cycle counts give the cleaner comparison here. A second, unmodified process is interleaved throughout: its cycle totals remain in the 34.3-35.0 billion range.

The following addresses remain unchanged across the swaps:

```text
hot loop PC:     0x7ffff1deb420
State object:   0x1472408
real array:     0x12d1000
imaginary array:0x12d3000
rotation:       0x12bf320
stack:          0x7fffffffcec8
rotation X/Z:   666 / 0, active width 10
```

The recorded guest PFN sequences are exactly A/B/A/B:

```text
A = [1526869, 5330933, 7435373, 6991693, 4073942, 6307781]
B = [8026362, 8096864, 8024104, 8042276, 8042227, 8063942]
```

These are guest physical identities; they do not expose the hypervisor's host physical-address mapping. Moving/restoring the backing changes other associated translation state too. This experiment identifies the causal allocation/backing dependency, not a particular cache-bank hash, memory-dependence predictor or host-translation mechanism.

An earlier independent intervention discarded and restored the same-size allocation using `madvise(MADV_DONTNEED)`. All six guest PFNs changed. Its slow process improved from 39.959b to 34.362b median cycles; the initially fast control remained around 34-35b. The reversible experiment above removes the ambiguity of a one-way improvement.

### How this was narrowed down

- Six cohorts, each of eight fresh processes: 48 successful correctness checks and 186 fixed-work samples, totaling 233,340,000 attempted shots. The same seed/call-count combination produces identical aggregate counts throughout. The complete sample/counter CSV is below.
- First keep selected fast and slow processes alive, then alternate their fixed-work measurements. For identical seeded work, retired instruction counts match to much better than 0.001%, while cycle costs differ persistently. Selected extremes are diagnostic cases, not an estimate of the population's slow-process probability.
- `perf record` locates most of the extra sampled cycle cost in the high-pivot, real-phase AVX-512 rotation loop. The immutable source is [the non-diagonal rotation kernel](https://github.com/unitaryfoundation/clifft/blob/69b5869267c1823ded4bc7156c76d9673c350ba5/src/clifft/sampling/kernels_avx512.cc#L184); the allocation is constructed in [State](https://github.com/unitaryfoundation/clifft/blob/69b5869267c1823ded4bc7156c76d9673c350ba5/src/clifft/sampling/state.cc#L51).
- The wheel is stripped. `perf` reports this loop at file offsets `0x1c5420..0x1c54df`; the executable ELF segment has virtual address = file offset + `0x1000`. The corresponding disassembly is `0x1c6420..0x1c64df`. These offsets are specific to the extension hash below.
- Neither disabling ASLR nor additionally fixing Python's hash seed removes the separation. Debugger inspection finds matching code, State, coefficient, descriptor and stack addresses in a fast/slow pair. Merely attaching/detaching the debugger leaves their separation present.
- Initial paired counters do not show #604's large extra op-cache-fetch signature. Some later pairs have increases in both front-end and back-end stalls. L2 request/miss and data-TLB totals remain close; those aggregate counters do not identify the specific stall. Do not relabel this as a confirmed front-end problem or a confirmed cache-conflict mechanism.
- One six-event counter bundle produced inconsistent cycle/instruction totals despite reporting 100% running. All four passes from that bundle (`direct-rc1-fixed-address`, `memory*`) are marked unusable in the CSV. The subsequent memory passes use four events and retain the fixed instruction totals. No conclusion relies on the suspect bundle.
- An exploratory synthetic rotation-descriptor-offset sweep did not produce a reproducible ordering across two passes. Its geometry is not the full d5 sequence, so it is only a negative diagnostic. Its temporary source/results are retained locally, alongside the raw `perf.data` files.

### What this establishes and what remains

This reproducer demonstrates that the same RC wheel can be made persistently faster or slower by changing the backing of its State allocation, with fixed code, virtual addresses and work. Repeated calls reuse the same backing, which offers a concrete explanation for stable fast/slow processes. Preparation history can change the pages an allocator supplies; applying that explanation to the EC2 observations remains an inference until reproduced there.

It does **not** establish a source-regression percentage, show that #655 fixes d5, prove the previous release has an identical mechanism, or identify a production remedy. The previous release's observed variability remains part of the release evidence. The ~11% source-build/wheel bridge is also a separate build comparison, not proof of pure layout.

Next work should retain the A/B backing sets and investigate the rotation's memory accesses: separate coefficient from scratch backing, collect targeted load/store or translation evidence where the VM supports it, and test a general kernel/storage change against both sets. Any change must preserve seeded behavior and allocation-free hot execution. A fix needs end-to-end benefit across fresh processes/builds and validation of the actual candidate wheel; selecting a lucky address/page set is not a fix. Bisect only if a matched-build source difference survives these controls. PGO or function padding is not the first response to this evidence.

### Reproduction and provenance

VM: AMD EPYC 9554P, Linux `6.12.93`, CPU 0, one thread, 12 GiB address-space ceiling, CPython 3.12.3, NumPy 2.5.4. The working profiler is `/usr/lib/linux-tools/6.8.0-106-generic/perf` (6.8.12), bypassing the mismatched-kernel wrapper.

Published `0.13.0rc1`, source `69b5869267c1823ded4bc7156c76d9673c350ba5`; extension SHA256:
`75b71fd3f1f6c2a22141f3f965bd02958f0a68a2d4d08be7b406e006ee2207b4`.

Pinned harness: `unitaryfoundation/clifft-bench@d2e711f61b4cad439a5f1752edefc51bb96905f1`, including its original d5 artifact and release raw case. The original worker/adapter files are unchanged. A temporary wrapper changes the sampling stop condition to a fixed number of API calls and adds process CPU timing. These shorter fixed-work passes are causal diagnostics, not replacements for the official five >=30-second release samples.

All local artifacts are under `/tmp/clifft-656-placement/`. No repository source was changed and no EC2 instance was launched or restarted. The debugger's first sandboxed attach attempts failed; the subsequent address and backing experiments ran with local debugger access. The decisive experiment's debugger transcripts verify successful calls and restored bytes.

For another machine, place the pinned harness at `/tmp/clifft-rc-investigation/bench`, install the exact wheel/NumPy into a Python-3.12.3 environment at `/tmp/clifft-rc-investigation/sys013`, and save the three scripts below in `/tmp/clifft-656-placement/`. The driver checks the extension hash before running. `gdb`, `perf`, local ptrace access and passwordless root access to the diagnostic workers' pagemap are needed for the backing experiment. The run directory must not already exist.

```sh
python3 /tmp/clifft-656-placement/run.py \
  --name direct-rc1-swap --no-aslr --hash-seed 0 --screen-calls 20 \
  --only-addresses --swap-pages
```

The driver screens eight fresh workers, selects two, alternates fixed-work counters, and changes only the slower worker's backing. New pages are not guaranteed to be fast; retain an inconclusive result if the chosen sets have similar costs. Do not silently repeat until favorable. The root-cause follow-up is local; a future EC2 confirmation should be a separately authorized, bounded run.
