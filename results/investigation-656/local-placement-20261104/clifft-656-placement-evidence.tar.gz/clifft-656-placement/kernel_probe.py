import ctypes as c
import json
import os
from pathlib import Path
import random
import statistics
import time

os.sched_setaffinity(0,{0})
import clifft

root=Path('/tmp/clifft-656-placement')
assert clifft.__version__ == '0.13.0rc1'
mapping=next(line.split() for line in Path('/proc/self/maps').read_text().splitlines()
             if '_clifft_core.abi3.so' in line and 'r-xp' in line)
function=int(mapping[0].split('-')[0],16)+0x1c52b0-int(mapping[2],16)
lib=c.CDLL(str(root/'kernel_probe.so'))
lib.make_state.restype=c.c_void_p
lib.initialize_state.argtypes=[c.c_void_p]
lib.drop_state.argtypes=[c.c_void_p]
lib.real_pointer.argtypes=[c.c_void_p]
lib.real_pointer.restype=c.c_uint64
lib.make_rotation.argtypes=[c.c_void_p,c.c_uint64,c.c_uint64]
lib.run_kernel.argtypes=[c.c_uint64,c.c_void_p,c.c_void_p,c.c_uint64]
lib.run_kernel.restype=c.c_double
buffer=c.create_string_buffer(8192)
base=(c.addressof(buffer)+4095)&~4095
state=lib.make_state()
print(json.dumps({'function':hex(function),'descriptor_base':hex(base),'state':hex(state),'real':hex(lib.real_pointer(state))}),flush=True)
rows=[]
try:
    offsets=list(range(0,4096,64))
    random.Random(656).shuffle(offsets)
    for repeat in range(2):
        for offset in offsets if repeat==0 else offsets[::-1]:
            descriptor=base+offset
            lib.make_rotation(descriptor,512,3)
            lib.initialize_state(state)
            start=time.perf_counter()
            checksum=lib.run_kernel(function,state,descriptor,200000)
            elapsed=time.perf_counter()-start
            row={'repeat':repeat,'offset':offset,'seconds':elapsed,'checksum':checksum}
            rows.append(row)
            print(json.dumps(row),flush=True)
finally:
    lib.drop_state(state)
(root/'kernel-offsets.json').write_text(json.dumps(rows,indent=2)+'\n')
