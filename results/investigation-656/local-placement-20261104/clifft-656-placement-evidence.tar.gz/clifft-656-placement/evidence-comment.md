## Local d5 investigation: changing and restoring backing pages changes and restores the slowdown

**A controlled A/B/A/B experiment establishes a local dependency on the backing pages of the scalar State's 24 KiB coefficient/scratch allocation.** The exact microarchitectural mechanism remains open. This is stronger than a correlation with preparation history, and it does not establish that every EC2 result has the same cause.

The maintainer has accepted the unresolved d5 release risk and merged #655. This investigation continues independently of preparing the next RC.

### The decisive experiment

One process uses the same published `0.13.0rc1` extension throughout. ASLR is disabled and `PYTHONHASHSEED=0`. The benchmark is the original d5 circuit and batch-1 aggregate survivor operation. Every measured pass performs exactly 100 calls of 20,000 attempted shots, with seeds `20270819..20270918`. Preparation, scheduler, detector postselection, no retained records, one thread and CPU affinity are preserved.

At a breakpoint in the AVX-512 high-pivot rotation, save all 24,576 allocation bytes. Use `mremap` to park the original six pages at another virtual address, map replacement pages at the original address, and restore the saved bytes. Subsequent interventions exchange the two existing page sets. Each exchange verifies identical restored bytes and records the guest page-frame numbers through `/proc/PID/pagemap`. These interventions happen outside measured passes. Both sets remain allocated, so restoring A really restores its original backing pages.

| State in the same process | Two measured throughputs, shots/s | Median cycles for 2m shots | Median instructions |
| --- | --- | ---: | ---: |
| A: original backing | 183,219; 186,926 | 38.331 billion | 91.6664 billion |
| B: replacement backing | 199,750; 202,725 | 34.394 billion | 91.6664 billion |
| A: original backing restored | 187,454; 185,370 | 38.194 billion | 91.6664 billion |
| B: replacement backing restored | 209,151; 204,882 | 34.381 billion | 91.6664 billion |

Each pass produces exactly **287,417 survivors, 1,712,583 discards and zero logical errors**. Replacement backing reduces cycles by about **10.3%** in both transitions from A. The original slow backing restores the higher cycle cost. Wall-clock throughput also varies with host conditions; cycle counts give the cleaner comparison here. A second, unmodified process is interleaved throughout: its cycle totals remain in the 34.3-35.0 billion range.

The following addresses remain unchanged across the swaps:

```text
hot loop PC:     0x7ffff1deb420
State object:   0x1472408
real array:     0x12d1000
imaginary array:0x12d3000
rotation:       0x12bf320
stack:          0x7fffffffcec8
rotation X/Z:   666 / 0, active width 10
```

The recorded guest PFN sequences are exactly A/B/A/B:

```text
A = [1526869, 5330933, 7435373, 6991693, 4073942, 6307781]
B = [8026362, 8096864, 8024104, 8042276, 8042227, 8063942]
```

These are guest physical identities; they do not expose the hypervisor's host physical-address mapping. Moving/restoring the backing changes other associated translation state too. This experiment identifies the causal allocation/backing dependency, not a particular cache-bank hash, memory-dependence predictor or host-translation mechanism.

An earlier independent intervention discarded and restored the same-size allocation using `madvise(MADV_DONTNEED)`. All six guest PFNs changed. Its slow process improved from 39.959b to 34.362b median cycles; the initially fast control remained around 34-35b. The reversible experiment above removes the ambiguity of a one-way improvement.

### How this was narrowed down

- Six cohorts, each of eight fresh processes: 48 successful correctness checks and 186 fixed-work samples, totaling 233,340,000 attempted shots. The same seed/call-count combination produces identical aggregate counts throughout. The complete sample/counter CSV is below.
- First keep selected fast and slow processes alive, then alternate their fixed-work measurements. For identical seeded work, retired instruction counts match to much better than 0.001%, while cycle costs differ persistently. Selected extremes are diagnostic cases, not an estimate of the population's slow-process probability.
- `perf record` locates most of the extra sampled cycle cost in the high-pivot, real-phase AVX-512 rotation loop. The immutable source is [the non-diagonal rotation kernel](https://github.com/unitaryfoundation/clifft/blob/69b5869267c1823ded4bc7156c76d9673c350ba5/src/clifft/sampling/kernels_avx512.cc#L184); the allocation is constructed in [State](https://github.com/unitaryfoundation/clifft/blob/69b5869267c1823ded4bc7156c76d9673c350ba5/src/clifft/sampling/state.cc#L51).
- The wheel is stripped. `perf` reports this loop at file offsets `0x1c5420..0x1c54df`; the executable ELF segment has virtual address = file offset + `0x1000`. The corresponding disassembly is `0x1c6420..0x1c64df`. These offsets are specific to the extension hash below.
- Neither disabling ASLR nor additionally fixing Python's hash seed removes the separation. Debugger inspection finds matching code, State, coefficient, descriptor and stack addresses in a fast/slow pair. Merely attaching/detaching the debugger leaves their separation present.
- Initial paired counters do not show #604's large extra op-cache-fetch signature. Some later pairs have increases in both front-end and back-end stalls. L2 request/miss and data-TLB totals remain close; those aggregate counters do not identify the specific stall. Do not relabel this as a confirmed front-end problem or a confirmed cache-conflict mechanism.
- One six-event counter bundle produced inconsistent cycle/instruction totals despite reporting 100% running. All four passes from that bundle (`direct-rc1-fixed-address`, `memory*`) are marked unusable in the CSV. The subsequent memory passes use four events and retain the fixed instruction totals. No conclusion relies on the suspect bundle.
- An exploratory synthetic rotation-descriptor-offset sweep did not produce a reproducible ordering across two passes. Its geometry is not the full d5 sequence, so it is only a negative diagnostic. Its temporary source/results are retained locally, alongside the raw `perf.data` files.

### What this establishes and what remains

This reproducer demonstrates that the same RC wheel can be made persistently faster or slower by changing the backing of its State allocation, with fixed code, virtual addresses and work. Repeated calls reuse the same backing, which offers a concrete explanation for stable fast/slow processes. Preparation history can change the pages an allocator supplies; applying that explanation to the EC2 observations remains an inference until reproduced there.

It does **not** establish a source-regression percentage, show that #655 fixes d5, prove the previous release has an identical mechanism, or identify a production remedy. The previous release's observed variability remains part of the release evidence. The ~11% source-build/wheel bridge is also a separate build comparison, not proof of pure layout.

Next work should retain the A/B backing sets and investigate the rotation's memory accesses: separate coefficient from scratch backing, collect targeted load/store or translation evidence where the VM supports it, and test a general kernel/storage change against both sets. Any change must preserve seeded behavior and allocation-free hot execution. A fix needs end-to-end benefit across fresh processes/builds and validation of the actual candidate wheel; selecting a lucky address/page set is not a fix. Bisect only if a matched-build source difference survives these controls. PGO or function padding is not the first response to this evidence.

### Reproduction and provenance

VM: AMD EPYC 9554P, Linux `6.12.93`, CPU 0, one thread, 12 GiB address-space ceiling, CPython 3.12.3, NumPy 2.5.4. The working profiler is `/usr/lib/linux-tools/6.8.0-106-generic/perf` (6.8.12), bypassing the mismatched-kernel wrapper.

Published `0.13.0rc1`, source `69b5869267c1823ded4bc7156c76d9673c350ba5`; extension SHA256:
`75b71fd3f1f6c2a22141f3f965bd02958f0a68a2d4d08be7b406e006ee2207b4`.

Pinned harness: `unitaryfoundation/clifft-bench@d2e711f61b4cad439a5f1752edefc51bb96905f1`, including its original d5 artifact and release raw case. The original worker/adapter files are unchanged. A temporary wrapper changes the sampling stop condition to a fixed number of API calls and adds process CPU timing. These shorter fixed-work passes are causal diagnostics, not replacements for the official five >=30-second release samples.

All local artifacts are under `/tmp/clifft-656-placement/`. No repository source was changed and no EC2 instance was launched or restarted. The debugger's first sandboxed attach attempts failed; the subsequent address and backing experiments ran with local debugger access. The decisive experiment's debugger transcripts verify successful calls and restored bytes.

For another machine, place the pinned harness at `/tmp/clifft-rc-investigation/bench`, install the exact wheel/NumPy into a Python-3.12.3 environment at `/tmp/clifft-rc-investigation/sys013`, and save the three scripts below in `/tmp/clifft-656-placement/`. The driver checks the extension hash before running. `gdb`, `perf`, local ptrace access and passwordless root access to the diagnostic workers' pagemap are needed for the backing experiment. The run directory must not already exist.

```sh
python3 /tmp/clifft-656-placement/run.py \
  --name direct-rc1-swap --no-aslr --hash-seed 0 --screen-calls 20 \
  --only-addresses --swap-pages
```

The driver screens eight fresh workers, selects two, alternates fixed-work counters, and changes only the slower worker's backing. New pages are not guaranteed to be fast; retain an inconclusive result if the chosen sets have similar costs. Do not silently repeat until favorable. The root-cause follow-up is local; a future EC2 confirmation should be a separately authorized, bounded run.


<details>
<summary>Reproduction source: diagnostic_worker.py</summary>

```python
"""Reuse the pinned worker; negative durations request a fixed number of API calls."""
import resource
import time

from clifft_bench import worker

original_aggregate = worker.aggregate_sample


def aggregate(prepared, *, min_seconds, **kwargs):
    cpu_start = time.process_time()
    if min_seconds >= 0:
        result = original_aggregate(prepared, min_seconds=min_seconds, **kwargs)
    else:
        calls = int(-min_seconds)
        assert 0 < calls <= kwargs["max_api_calls"]
        start = worker.utc_now()
        setup = worker.begin_sample(prepared, kwargs["seed"])
        totals = worker.Counts(0, 0, 0, 0)
        elapsed = 0.0
        for index in range(calls):
            counts, duration = worker.timed_sample(
                prepared, kwargs["shots_per_call"], kwargs["seed"] + index
            )
            assert not worker.validate_counts(counts, postselect=kwargs["postselect"])
            totals = worker.Counts(
                totals.attempted_shots + counts.attempted_shots,
                totals.accepted_shots + counts.accepted_shots,
                totals.discarded_shots + counts.discarded_shots,
                totals.logical_errors + counts.logical_errors,
            )
            elapsed += duration
        result = {
            "started_at": start,
            "duration_seconds": elapsed,
            "stream_setup_seconds": setup,
            "api_calls": calls,
            **totals.as_dict(),
            "throughput_attempted_shots_per_second": totals.attempted_shots / elapsed,
            "seed_first": kwargs["seed"],
            "seed_last": kwargs["seed"] + calls - 1,
            "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            "diagnostic_fixed_calls": True,
        }
    result["process_cpu_seconds"] = time.process_time() - cpu_start
    return result


worker.aggregate_sample = aggregate
raise SystemExit(worker.main())
```

</details>


<details>
<summary>Reproduction source: run.py</summary>

```python
"""Local diagnostic, not the release harness: fixed work and live-process profiling."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time

ROOT = Path('/tmp/clifft-656-placement')
PREVIOUS = Path('/tmp/clifft-rc-investigation')
BENCH = PREVIOUS / 'bench'
PERF = '/usr/lib/linux-tools/6.8.0-106-generic/perf'
sys.path.insert(0, str(BENCH / 'src'))
from clifft_bench.system import restricted_environment

parser = argparse.ArgumentParser()
parser.add_argument('--name', default='direct-rc1')
parser.add_argument('--version', default='sys013')
parser.add_argument('--workers', type=int, default=8)
parser.add_argument('--history', choices=['direct','calibrate'], default='direct')
parser.add_argument('--no-aslr', action='store_true')
parser.add_argument('--cpu', type=int, default=0)
parser.add_argument('--extra-counters', action='store_true')
parser.add_argument('--hash-seed')
parser.add_argument('--debug-addresses', action='store_true')
parser.add_argument('--only-addresses', action='store_true')
parser.add_argument('--screen-calls', type=int, default=50)
parser.add_argument('--repage', action='store_true')
parser.add_argument('--swap-pages', action='store_true')
args = parser.parse_args()
if args.version == 'sys013':
    extension = PREVIOUS / 'sys013/lib/python3.12/site-packages/clifft/_clifft_core.abi3.so'
    assert hashlib.sha256(extension.read_bytes()).hexdigest() == '75b71fd3f1f6c2a22141f3f965bd02958f0a68a2d4d08be7b406e006ee2207b4'
if args.debug_addresses or args.swap_pages or args.repage:
    assert args.version == 'sys013', 'Debugger offsets are specific to the pinned RC1 wheel'
OUT = ROOT / args.name
OUT.mkdir()
raw = json.loads((BENCH / 'results/release-v1/0.13.0rc1-20261103-183623/raw.json').read_text())
case = next(c for c in raw['cases'] if c['case_id'].startswith('msc-d5') and c['variant_id'] == ('clifft-previous' if args.version == 'sys012' else 'clifft-current'))
output = (OUT / 'results.jsonl').open('w')
processes = []


def save(event):
    output.write(json.dumps(event) + '\n')
    output.flush()


class Worker:
    def __init__(self, index):
        self.index = index
        env = restricted_environment()
        env['PYTHONPATH'] = str(BENCH / 'src')
        if args.hash_seed is not None:
            env['PYTHONHASHSEED'] = args.hash_seed
        command = [str(PREVIOUS / args.version / 'bin/python'), str(ROOT / 'diagnostic_worker.py')]
        if args.no_aslr:
            command = ['setarch', 'x86_64', '-R', *command]
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=(OUT / f'{index}.stderr').open('w'), text=True, env=env)
        processes.append(self.process)
        self.request({'command':'prepare','adapter':'clifft',
            'artifact_path':str(BENCH / 'workloads/circuits' / Path(case['workload']['artifact']['path']).name),
            'workload':case['workload'],
            'execution':{'batch_size':1 if args.history=='direct' else 'calibrate', 'options':case['execution']['options']},
            'shots_per_call':20000,'seed':520270819,'sampling_seed':20260818,
            'expected_version':case['simulator']['version'],'expected_commit':case['simulator']['commit_sha'],
            'source_url':case['simulator']['source_url'],'dependency_distributions':['numpy'],
            'logical_cpu':args.cpu,'memory_limit_gib':12,'timeout_seconds':180})
        self.request({'command':'warmup','shots':1,'seed':20260818})
        result = self.request({'command':'correctness','shots':8,'seed':20260819})
        assert not result['contract_errors']
        (OUT / f'{index}.maps').write_text(Path(f'/proc/{self.process.pid}/maps').read_text())

    def request(self, request, phase='setup'):
        self.process.stdin.write(json.dumps(request) + '\n')
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError(f'worker {self.index} exited: {(OUT / f"{self.index}.stderr").read_text()}')
        result = json.loads(line)
        assert result['ok'], result
        save({'worker':self.index,'pid':self.process.pid,'phase':phase,'request':request,'result':result})
        return result

    def sample(self, phase, calls=50):
        return self.request({'command':'sample','shots_per_call':20000,'min_seconds':-calls,
                             'seed':20270819,'max_api_calls':100000000},phase)

    def profile(self, phase, events=None, record=False):
        prefix = OUT / f'{self.index}-{phase}'
        command = [PERF, 'record' if record else 'stat', '-p', str(self.process.pid)]
        if record:
            command += ['-e','cycles:u','-F','997','-o',str(prefix)+'.data']
        else:
            command += ['-x',',','-e',events,'-o',str(prefix)+'.csv']
        with open(str(prefix)+'.perf.log','w') as log:
            profiler = subprocess.Popen(command, stdout=log, stderr=log)
            try:
                time.sleep(0.15)
                assert profiler.poll() is None, Path(str(prefix)+'.perf.log').read_text()
                result = self.sample(phase, 100)
            finally:
                profiler.send_signal(signal.SIGINT)
                profiler.wait(timeout=10)
        print(phase,self.index,round(result['throughput_attempted_shots_per_second']),
              'cpu/wall',round(result['process_cpu_seconds']/result['duration_seconds'],4),flush=True)
        if record:
            with open(str(prefix)+'.report','w') as report:
                subprocess.run([PERF,'report','--stdio','--no-children','--sort','dso,symbol',
                                '-i',str(prefix)+'.data'],stdout=report,stderr=subprocess.STDOUT,check=True)

    def addresses(self, repage=False, swap=False, suffix=''):
        lines = Path(f'/proc/{self.process.pid}/maps').read_text().splitlines()
        mapping = next(line.split() for line in lines if '_clifft_core.abi3.so' in line and 'r-xp' in line)
        # perf reports file offsets for this stripped ELF; its executable segment's
        # virtual address is file offset + 0x1000. Resolve using the live mapping.
        pc = int(mapping[0].split('-')[0],16) + 0x1c5420 - int(mapping[2],16)
        ready = OUT / f'{self.index}{suffix}.gdb-ready'
        ready.unlink(missing_ok=True)
        commands = OUT / f'{self.index}{suffix}.gdb'
        intervention = '''disable 1
python
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
print('REPAGE address', hex(address))
gdb.execute('call (int)madvise((void*)%d, 24576, 4)' % address)
inferior.write_memory(address, saved)
print('REPAGE restored', bytes(inferior.read_memory(address, 24576)) == saved)
end
''' if repage else ''
        if swap:
            slots = OUT / f'{self.index}-swap-slots.json'
            intervention = f'''disable 1
python
import json, subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
def frames():
    return subprocess.check_output(['sudo','-n','python3',{str(ROOT/'page_frames.py')!r},str(inferior.pid),str(address),'6'],text=True).strip()
def call(expression):
    value=int(gdb.parse_and_eval(expression))
    assert value != -1 and value != (1<<64)-1, expression
    return value
print('SWAP before', frames())
slots=Path({str(slots)!r})
if not slots.exists():
    parked=call('(long)mmap((void*)0,24576,3,34,-1,0)')
    temporary=call('(long)mmap((void*)0,24576,3,34,-1,0)')
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address,parked))==parked
    assert call('(long)mmap((void*)%d,24576,3,50,-1,0)' % address)==address
    slots.write_text(json.dumps({{'parked':parked,'temporary':temporary}}))
else:
    locations=json.loads(slots.read_text())
    parked,temporary=locations['parked'],locations['temporary']
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address,temporary))==temporary
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (parked,address))==address
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (temporary,parked))==parked
inferior.write_memory(address,saved)
assert bytes(inferior.read_memory(address,24576))==saved
print('SWAP after', frames())
print('SWAP restored bytes',len(saved))
end
'''
        commands.write_text(f'''set pagination off
set confirm off
attach {self.process.pid}
break *{pc:#x}
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
{intervention}
detach
quit
end
python open({str(ready)!r},'w').write('ready')
continue
''')
        with (OUT / f'{self.index}{suffix}.gdb-log').open('w') as log:
            debugger = subprocess.Popen(['gdb','-q','-nx','-batch','-x',str(commands)],stdout=log,stderr=subprocess.STDOUT)
            until = time.monotonic()+15
            while not ready.exists() and debugger.poll() is None and time.monotonic()<until:
                time.sleep(0.05)
            if not ready.exists():
                debugger.terminate();debugger.wait(timeout=5)
                raise RuntimeError(f'debugger did not attach to worker {self.index}')
            self.sample('debug-addresses',1)
            debugger.wait(timeout=15)
            assert debugger.returncode == 0, f'debugger failed for worker {self.index}'
        print('debugged',self.index,(OUT/f'{self.index}{suffix}.gdb-log').read_text()[-1300:],flush=True)


try:
    workers = [ ]
    for i in range(args.workers):
        worker = Worker(i)
        rates = [worker.sample('screen',args.screen_calls)['throughput_attempted_shots_per_second'] for _ in range(2)]
        worker.rate = statistics.median(rates)
        workers.append(worker)
        print('screen', i, [round(x) for x in rates],flush=True)
    low, high = min(workers,key=lambda w:w.rate), max(workers,key=lambda w:w.rate)
    print('selected',low.index,high.index,'spread',high.rate/low.rate-1,flush=True)
    save({'selected_low':low.index,'selected_high':high.index})
    core = 'cycles:u,instructions:u,branches:u,branch-misses:u,task-clock,context-switches,cpu-migrations,page-faults'
    front = 'cycles:u,instructions:u,op_cache_hit_miss.all_op_cache_accesses:u,de_no_dispatch_per_slot.no_ops_from_frontend:u,l2_cache_req_stat.dc_access_in_l2:u'
    for i, worker in enumerate([low,high,high,low]):
        worker.profile(f'core{i}',core)
    for i, worker in enumerate([] if args.only_addresses else [high,low,low,high]):
        worker.profile(f'front{i}',front)
    if args.extra_counters:
        memory = 'cycles:u,instructions:u,ls_bad_status2.stli_other:u,de_no_dispatch_per_slot.backend_stalls:u'
        for i, worker in enumerate([low,high,high,low]):
            worker.profile(f'memory{i}',memory)
        caches = 'cycles:u,instructions:u,l2_cache_req_stat.ic_dc_miss_in_l2:u,ls_l1_d_tlb_miss.all:u'
        for i, worker in enumerate([high,low]):
            worker.profile(f'cache{i}',caches)
    for worker in ([] if args.only_addresses else [low,high]):
        worker.profile('hotspots',record=True)
    for worker in [high,low]:
        result=worker.sample('final',100)
        print('final',worker.index,round(result['throughput_attempted_shots_per_second']),flush=True)
    if args.debug_addresses:
        for worker in [low,high]:
            worker.addresses(repage=args.repage)
            result=worker.sample('after-debug',100)
            print('after-debug',worker.index,round(result['throughput_attempted_shots_per_second']),flush=True)
        if args.repage:
            for i,worker in enumerate([low,high,high,low]):
                worker.profile(f'after-repage{i}',core)
    if args.swap_pages:
        for stage in ['new','original','new-again']:
            low.addresses(swap=True,suffix='-'+stage)
            for i,worker in enumerate([low,high,low]):
                worker.profile(f'swap-{stage}-{i}',core)
finally:
    for process in processes:
        if process.poll() is None:
            process.stdin.close()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=5)
    output.close()
```

</details>


<details>
<summary>Reproduction source: page_frames.py</summary>

```python
import json
from pathlib import Path
import struct
import sys

pid, address, count = map(int, sys.argv[1:])
with Path(f'/proc/{pid}/pagemap').open('rb') as stream:
    stream.seek(address // 4096 * 8)
    entries = struct.unpack(f'{count}Q', stream.read(count * 8))
print(json.dumps({'pid':pid,'address':hex(address),
                  'pfns':[v & ((1 << 55) - 1) for v in entries],
                  'present':[bool(v >> 63) for v in entries]}))
```

</details>


<details>
<summary>All 186 fixed-work samples and hardware counters (CSV)</summary>

```csv
run,worker,phase,calls,seconds,cpu_seconds,shots_per_second,attempted,accepted,discarded,errors,cycles:u,instructions:u,branches:u,branch-misses:u,task-clock:u,context-switches:u,cpu-migrations:u,page-faults:u,counter_usable,op_cache_hit_miss.all_op_cache_accesses:u,de_no_dispatch_per_slot.no_ops_from_frontend:u,l2_cache_req_stat.dc_access_in_l2:u,ls_bad_status2.stli_other:u,ls_l1_d_tlb_miss.all:u,de_no_dispatch_per_slot.backend_stalls:u,de_no_dispatch_per_slot.smt_contention:u,l2_cache_req_stat.ic_dc_miss_in_l2:u
direct-rc1,0,screen,50,5.601946503855288,5.58999441,178509.38050047334,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,0,screen,50,5.799333481118083,5.798586948,172433.6086648366,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,1,screen,50,5.33970791939646,5.3382702559999995,187276.16099890135,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,1,screen,50,5.522268947213888,5.5213177369999995,181084.98690642783,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,2,screen,50,5.457274249754846,5.457364127,183241.66135592735,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,2,screen,50,5.186407727189362,5.1865421860000005,192811.68249799826,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,3,screen,50,5.407858757302165,5.407523370000001,184916.0721236871,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,3,screen,50,6.731373403221369,6.731046525999999,148558.0935862865,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,4,screen,50,6.036672334186733,6.036385053,165654.17909745156,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,4,screen,50,5.673978569917381,5.673987556000001,176243.17534469665,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,5,screen,50,5.59781692083925,5.5972833810000004,178641.06921347394,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,5,screen,50,5.6439932426437736,5.643659889,177179.51758772437,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,6,screen,50,6.088571299798787,6.08841727,164242.14331415447,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,6,screen,50,5.989321183413267,5.988100599,166963.8293517109,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,7,screen,50,5.390261884778738,5.3880761580000005,185519.74308035843,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,7,screen,50,5.488011980429292,5.487468789999999,182215.34565997365,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1,6,core0,100,11.33866672962904,11.335195311,176387.58133474417,2000000,287417,1712583,0,38062807176,91666411338,7153033266,130784167,11347.51,0,0,0,True,,,,,,,,
direct-rc1,2,core1,100,10.415435026399791,10.412499964999999,192022.70427789533,2000000,287417,1712583,0,35897684551,91666404925,7153029646,128644670,10414.53,0,0,0,True,,,,,,,,
direct-rc1,2,core2,100,10.539532435126603,10.532803807,189761.7387024034,2000000,287417,1712583,0,36182928897,91666411169,7153026651,129081237,10535.07,0,0,0,True,,,,,,,,
direct-rc1,6,core3,100,11.04873451218009,11.045571728000002,181016.20577408266,2000000,287417,1712583,0,38116090410,91666409300,7153027153,129763084,11047.42,0,0,0,True,,,,,,,,
direct-rc1,2,front0,100,10.089517614804208,10.085427111000001,198225.53231538323,2000000,287417,1712583,0,36034945288,91666399459,,,,,,,True,15047869860,24452021133,1868733204,,,,,
direct-rc1,6,front1,100,11.558114156126976,11.554379120999997,173038.6093253627,2000000,287417,1712583,0,38476563470,91666415636,,,,,,,True,14962310459,23471192119,1868301055,,,,,
direct-rc1,6,front2,100,11.042677639983594,11.03817436,181115.49256480616,2000000,287417,1712583,0,38012932113,91666397040,,,,,,,True,14928634547,23137703174,1862337420,,,,,
direct-rc1,2,front3,100,10.41341071203351,10.409536137000003,192060.03252026194,2000000,287417,1712583,0,35752466169,91666405418,,,,,,,True,15174405783,24212050746,1859373824,,,,,
direct-rc1,6,hotspots,100,11.124290212988853,11.117038265999994,179786.75148772873,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1,2,hotspots,100,10.303767953068018,10.302112324,194103.75011448955,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1,2,final,100,10.418598985299468,10.417516492000004,191964.39010868722,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1,6,final,100,10.97424852102995,10.973478490000005,182244.82488868377,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,0,screen,50,4.8707216661423445,4.870695468,205308.38519295008,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,0,screen,50,4.911754189059138,4.911957423999999,203593.25029487134,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,1,screen,50,5.281153224408627,5.280999137,189352.58219325347,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,1,screen,50,5.662930306047201,5.661453518000001,176587.02225809539,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,2,screen,50,4.967751005664468,4.967545475,201298.33376506835,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,2,screen,50,4.66156195756048,4.661564826,214520.3708765735,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,3,screen,50,4.948041710071266,4.94739515,202100.15569686805,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,3,screen,50,4.720472923479974,4.718248926999999,211843.18101390384,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,4,screen,50,4.807412846013904,4.799827006999999,208012.0913328998,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,4,screen,50,4.764600900001824,4.764820974,209881.16759152213,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,5,screen,50,4.805310072377324,4.805049563,208103.11612321646,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,5,screen,50,4.973679155111313,4.973870259,201058.40542052808,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,6,screen,50,4.877482603304088,4.877303385,205023.79635810148,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,6,screen,50,4.711662171408534,4.711816935999999,212239.3252360565,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,7,screen,50,4.982664780691266,4.9828689850000005,200695.82121502177,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,7,screen,50,4.838827472180128,4.837920130999999,206661.63564402744,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,1,core0,100,10.793115608394146,10.790366800000001,185303.3056038552,2000000,287417,1712583,0,37586831818,91666406867,7153027806,129081459,10808.60,0,0,0,True,,,,,,,,
direct-rc1-fixed-address,4,core1,100,10.294087669812143,10.291485076999999,194286.28006200943,2000000,287417,1712583,0,35180003744,91666402388,7153027632,129168440,10293.15,0,0,0,True,,,,,,,,
direct-rc1-fixed-address,4,core2,100,10.51915882807225,10.515806736000002,190129.2710461452,2000000,287417,1712583,0,35402942746,91666407192,7153029663,129320319,10517.64,0,0,0,True,,,,,,,,
direct-rc1-fixed-address,1,core3,100,10.807644604705274,10.803866709000001,185054.1975750451,2000000,287417,1712583,0,37637106962,91666427674,7153028153,129328384,10805.78,0,0,0,True,,,,,,,,
direct-rc1-fixed-address,4,front0,100,10.814879128709435,10.808502371000003,184930.4070991189,2000000,287417,1712583,0,35679732187,91666419803,,,,,,,True,14869079169,22868306109,1871050163,,,,,
direct-rc1-fixed-address,1,front1,100,11.638705108314753,11.633575519000004,171840.42222800106,2000000,287417,1712583,0,38457897219,91666409557,,,,,,,True,14865086328,23540935573,1883795383,,,,,
direct-rc1-fixed-address,1,front2,100,10.910228928551078,10.906290569,183314.21027895957,2000000,287417,1712583,0,37734635933,91666422085,,,,,,,True,14881029179,23073313880,1867453566,,,,,
direct-rc1-fixed-address,4,front3,100,10.708276152610779,10.705131080000001,186771.42534397388,2000000,287417,1712583,0,36072497353,91666405855,,,,,,,True,14889349681,23167833895,1878597743,,,,,
direct-rc1-fixed-address,1,memory0,100,11.149774278514087,11.146600876999997,179375.82860794352,2000000,287417,1712583,0,15873724710,91666415230,,,,,,,False,,,,1206001522,64030506,85839533983,256025548,
direct-rc1-fixed-address,4,memory1,100,10.04126080404967,10.026991111000001,199178.17483571326,2000000,287417,1712583,0,35245602304,91666403856,,,,,,,False,,,,1796324749,63573519,69941467521,0,
direct-rc1-fixed-address,4,memory2,100,9.95234764739871,9.949229707,200957.6102903468,2000000,287417,1712583,0,35170956883,91666403780,,,,,,,False,,,,1802183357,63021146,69728616636,0,
direct-rc1-fixed-address,1,memory3,100,11.822992701083422,11.813086264000006,169161.90769674807,2000000,287417,1712583,0,38402303607,87490158092,,,,,,,False,,,,1203630900,64911380,87093005453,30756043,
direct-rc1-fixed-address,1,hotspots,100,11.65976435597986,11.657866898999998,171530.0531759267,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,4,hotspots,100,10.794914883561432,10.793600831000006,185272.41961357318,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,4,final,100,10.298879466950893,10.299090802999999,194195.8837772595,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-address,1,final,100,10.969713400118053,10.970027385999998,182320.16890965233,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,0,screen,50,5.273884165100753,5.269053178,189613.56918253357,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,0,screen,50,5.211285272613168,5.20918581,191891.2413517819,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,1,screen,50,4.867323947139084,4.86283465,205451.70423427026,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,1,screen,50,4.834540315903723,4.836491816,206844.8983061318,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,2,screen,50,4.915102233178914,4.913854809,203454.56768927377,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,2,screen,50,4.999429339542985,4.999569644,200022.82902380484,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,3,screen,50,4.7825219156220555,4.782366386,209094.70309660494,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,3,screen,50,4.666938000358641,4.667103807,214273.25580994494,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,4,screen,50,5.209521242417395,5.20892075,191956.21890505354,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,4,screen,50,5.267191503196955,5.2666214170000005,189854.4982450408,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,5,screen,50,4.817631553858519,4.817599586,207570.8756098386,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,5,screen,50,4.827250987291336,4.8274326709999995,207157.24179925423,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,6,screen,50,5.316201436333358,5.316174904,188104.23419352426,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,6,screen,50,5.269769860431552,5.269436514000001,189761.60752456618,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,7,screen,50,5.008047215640545,5.008500639,199678.62860336408,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,7,screen,50,4.929936144500971,4.930009605,202842.38389485757,1000000,143519,856481,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,6,core0,100,10.828353025019169,10.823950432,184700.29517683364,2000000,287417,1712583,0,38120357243,91666435929,7153033406,129023622,10843.48,0,0,0,True,,,,,,,,
direct-rc1-fixed-hash,3,core1,100,10.30665797367692,10.303133572999998,194049.322788044,2000000,287417,1712583,0,35121132958,91666443740,7153037418,130611594,10306.03,0,0,0,True,,,,,,,,
direct-rc1-fixed-hash,3,core2,100,10.287365155294538,10.285396760999998,194413.24088419977,2000000,287417,1712583,0,35126262585,91666446621,7153036694,129864885,10288.94,0,0,0,True,,,,,,,,
direct-rc1-fixed-hash,6,core3,100,10.645015020854771,10.641907553,187881.3694561987,2000000,287417,1712583,0,37638978104,91666440633,7153034524,128733712,10643.85,0,0,0,True,,,,,,,,
direct-rc1-fixed-hash,3,front0,100,9.896855922415853,9.893347567,202084.38070418974,2000000,287417,1712583,0,34910400323,91666438036,,,,,,,True,14876461188,22640784077,1846992075,,,,,
direct-rc1-fixed-hash,6,front1,100,10.842212612740695,10.838851466999998,184464.19300519876,2000000,287417,1712583,0,37800306200,91666440392,,,,,,,True,15792943539,26647567163,1850027346,,,,,
direct-rc1-fixed-hash,6,front2,100,10.77370308060199,10.769061354000002,185637.19317650326,2000000,287417,1712583,0,38044818259,91666435700,,,,,,,True,15724451437,26473732294,1857190760,,,,,
direct-rc1-fixed-hash,3,front3,100,10.076338544487953,10.072848708999999,198484.79595736266,2000000,287417,1712583,0,35285214234,91666439423,,,,,,,True,14874427927,23190521791,1849530791,,,,,
direct-rc1-fixed-hash,6,memory0,100,11.13263459969312,11.126619450000007,179651.9936130062,2000000,287417,1712583,0,38160511436,91666442845,,,,,,,True,,,,1568313403,,76554990603,,
direct-rc1-fixed-hash,3,memory1,100,9.800985427573323,9.798747460999998,204061.11352572334,2000000,287417,1712583,0,34763970518,91666440284,,,,,,,True,,,,1519392016,,66855038343,,
direct-rc1-fixed-hash,3,memory2,100,10.32329322770238,10.319993580999999,193736.6260829475,2000000,287417,1712583,0,35328352706,91666435481,,,,,,,True,,,,1518119032,,69676319442,,
direct-rc1-fixed-hash,6,memory3,100,11.30955744534731,11.305351524999992,176841.5793159784,2000000,287417,1712583,0,38211502848,91666443875,,,,,,,True,,,,1568350475,,76532290899,,
direct-rc1-fixed-hash,3,cache0,100,10.065667279064655,10.062830543000004,198695.22253728306,2000000,287417,1712583,0,35147180862,91666437563,,,,,,,True,,,,,65329750,,,18762560
direct-rc1-fixed-hash,6,cache1,100,10.567537813447416,10.564625797000005,189258.84489904143,2000000,287417,1712583,0,37513020893,91666432595,,,,,,,True,,,,,65147753,,,18947898
direct-rc1-fixed-hash,6,hotspots,100,10.769290355034173,10.768745807999991,185713.25816887157,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,3,hotspots,100,10.338483265601099,10.335207241999996,193451.9743969152,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,3,final,100,9.866511202417314,9.864704506999999,202705.89664054668,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,6,final,100,10.725871552713215,10.722857950000005,186465.03364979048,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,6,after-debug,100,10.593167749233544,10.591268213999996,188800.93729703352,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-fixed-hash,3,after-debug,100,10.103829656727612,10.089348138999995,197944.74649206942,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,0,screen,20,2.086699609644711,2.0793090320000003,191690.26444975732,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,0,screen,20,2.0057855658233166,2.005621451,199423.11222875494,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,1,screen,20,2.2359924633055925,2.235768717,178891.47953954086,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,1,screen,20,2.085473761893809,2.085163452,191802.94056385627,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,2,screen,20,1.8723684530705214,1.871980635,213633.16570733438,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,2,screen,20,1.9213715232908726,1.920854264,208184.6197631216,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,3,screen,20,2.0535425385460258,2.053192725,194785.34897222673,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,3,screen,20,2.1245125625282526,2.1239002399999998,188278.4818763248,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,4,screen,20,1.9887416688725352,1.9885232040000003,201132.20649053404,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,4,screen,20,1.864389038644731,1.8642373119999998,214547.49610133385,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,5,screen,20,1.976597921922803,1.973620549,202367.91487207796,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,5,screen,20,1.909949243068695,1.9098485149999997,209429.64921796785,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,6,screen,20,2.067903406918049,2.0674933380000002,193432.63261805344,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,6,screen,20,2.049370347522199,2.049246653,195181.900862195,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,7,screen,20,1.9967701314017177,1.99664527,200323.50930610276,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,7,screen,20,1.9547054301947355,1.9544842379999996,204634.41387183868,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,1,core0,100,11.681999972090125,11.667321405000001,171203.56144309792,2000000,287417,1712583,0,39203427720,91666408773,7153032596,133570194,11682.49,0,0,0,True,,,,,,,,
direct-rc1-addresses,2,core1,100,10.222367507405579,10.21463305,195649.39321063375,2000000,287417,1712583,0,34396619940,91666409608,7153034153,129147758,10218.26,0,0,0,True,,,,,,,,
direct-rc1-addresses,2,core2,100,9.436488809995353,9.433415663,211943.2386632571,2000000,287417,1712583,0,34081167392,91666397470,7153021714,127908635,9434.83,0,0,0,True,,,,,,,,
direct-rc1-addresses,1,core3,100,10.896381956525147,10.892674360999997,183547.1634511057,2000000,287417,1712583,0,38506840447,91666402467,7153025581,130871766,10894.49,0,0,0,True,,,,,,,,
direct-rc1-addresses,2,final,100,9.759032194502652,9.758902639000002,204938.35455595868,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,1,final,100,10.682975694537163,10.683010240000002,187213.75552906276,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,1,debug-addresses,1,0.12691895384341478,0.11790806799999842,157580.87657005774,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,1,after-debug,100,11.070951579138637,11.070706182999999,180652.94439266328,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,2,debug-addresses,1,0.11790856532752514,0.10995894100000214,169622.96118559508,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-addresses,2,after-debug,100,9.915861274115741,9.915383667,201697.0533079944,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,0,screen,20,1.9491759184747934,1.949261835,205214.93017058983,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,0,screen,20,1.9936295365914702,1.9937591579999996,200639.08196498948,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,1,screen,20,1.9394238917157054,1.939549811,206246.8146899754,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,1,screen,20,1.8868228290230036,1.886888849,211996.58698592274,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,2,screen,20,1.8568025585263968,1.8569343280000001,215424.08920281197,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,2,screen,20,1.9720429386943579,1.971792975,202835.34001791582,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,3,screen,20,1.9595001386478543,1.9596157330000001,204133.69313462693,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,3,screen,20,1.9115224275738,1.9116207610000004,209257.2884471463,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,screen,20,2.1819602148607373,2.182122113,183321.39938927797,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,screen,20,2.161655534990132,2.161761493,185043.35844694424,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,5,screen,20,1.8732942901551723,1.8734314300000001,213527.58191926504,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,5,screen,20,1.8676249394193292,1.8677348090000003,214175.76492867226,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,6,screen,20,1.893730659969151,1.893828524,211223.2792421051,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,6,screen,20,1.8647895464673638,1.864891182,214501.41693348478,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,7,screen,20,1.9124747132882476,1.912557486,209153.09217984526,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,7,screen,20,2.0260707046836615,2.026235724,197426.47631956832,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,core0,100,11.262802310287952,11.260035729,177575.69962611434,2000000,287417,1712583,0,39987857757,91666447019,7153030767,130301464,11273.60,0,0,0,True,,,,,,,,
direct-rc1-repage,5,core1,100,10.004633190110326,10.002517658999999,199907.37911081227,2000000,287417,1712583,0,35027622032,91666480889,7153026579,130510882,10003.93,0,0,0,True,,,,,,,,
direct-rc1-repage,5,core2,100,10.208526141010225,10.205816079,195914.66705124997,2000000,287417,1712583,0,34896135201,91666401744,7153025006,130406521,10207.74,0,0,0,True,,,,,,,,
direct-rc1-repage,4,core3,100,11.020591021515429,11.016494622999998,181478.47026492617,2000000,287417,1712583,0,39929258763,91666399434,7153024632,129311716,11018.30,0,0,0,True,,,,,,,,
direct-rc1-repage,5,final,100,9.631683737970889,9.631969298000001,207648.01403470302,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,final,100,11.23301895428449,11.233131840999995,178046.52588404666,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,debug-addresses,1,0.11309484671801329,0.10310196999999732,176842.71724482105,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,after-debug,100,9.69570697285235,9.695695606999998,206276.8610478774,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,5,debug-addresses,1,0.11112939938902855,0.09969390100000197,179970.37786541422,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,5,after-debug,100,9.775658663362265,9.775286841000003,204589.79480285116,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-repage,4,after-repage0,100,9.760409160517156,9.753049667000006,204909.4425355043,2000000,287417,1712583,0,34473146669,91666404708,7153024452,128898237,9767.95,0,0,0,True,,,,,,,,
direct-rc1-repage,5,after-repage1,100,9.507983098737895,9.501729802,210349.55355205492,2000000,287417,1712583,0,34490655073,91666402543,7153023616,127924313,9503.28,0,0,0,True,,,,,,,,
direct-rc1-repage,5,after-repage2,100,9.46000063791871,9.458277693,211416.47622975413,2000000,287417,1712583,0,34329765300,91666395776,7153023746,127455443,9459.65,0,0,0,True,,,,,,,,
direct-rc1-repage,4,after-repage3,100,9.505716362968087,9.503222229000002,210399.71356514527,2000000,287417,1712583,0,34250081127,91666398609,7153023006,127802428,9504.84,0,0,0,True,,,,,,,,
direct-rc1-swap,0,screen,20,2.0607499880716205,2.04144095,194104.0894409061,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,0,screen,20,2.1270268065854907,2.1265707509999996,188055.92800314477,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,1,screen,20,2.0891314297914505,2.089244979,191467.1304523576,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,1,screen,20,2.1392674511298537,2.1391895940000003,186979.8934157298,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,screen,20,2.139446672052145,2.13929927,186964.23015597873,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,screen,20,2.1159018175676465,2.115924952,189044.68850063352,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,3,screen,20,1.9215953014791012,1.921734391,208160.37575243326,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,3,screen,20,1.9443986024707556,1.944563047,205719.13572233508,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,4,screen,20,1.9388091685250401,1.938924324,206312.20776839126,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,4,screen,20,1.927628113888204,1.927572584,207508.9054356875,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,5,screen,20,1.8857783349230886,1.885962488,212114.00756511182,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,5,screen,20,1.9410605356097221,1.941178269,206072.91357574935,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,6,screen,20,2.0273675974458456,2.024725857,197300.18399422735,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,6,screen,20,1.9222876308485866,1.9224136520000004,208085.4049003174,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,7,screen,20,1.937237630598247,1.9373437919999998,206479.57363726938,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,7,screen,20,1.8711508018895984,1.870127062,213772.18746669506,400000,57358,342642,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,core0,100,10.91590808518231,10.913320758,183218.83845054358,2000000,287417,1712583,0,38426680964,91666425969,7153031047,131615935,10926.58,0,0,0,True,,,,,,,,
direct-rc1-swap,7,core1,100,10.30359848588705,10.301755137,194106.94261227487,2000000,287417,1712583,0,35019401743,91666413094,7153029174,131309565,10303.25,0,0,0,True,,,,,,,,
direct-rc1-swap,7,core2,100,9.813812678679824,9.811317002,203794.39321732035,2000000,287417,1712583,0,34635150106,91666408179,7153024209,129683177,9812.93,0,0,0,True,,,,,,,,
direct-rc1-swap,2,core3,100,10.699441748671234,10.693844471,186925.6403258965,2000000,287417,1712583,0,38235549504,91666406619,7153026557,131081165,10696.00,0,0,0,True,,,,,,,,
direct-rc1-swap,7,final,100,9.794577659107745,9.794618616000001,204194.61355133037,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,final,100,10.86502195801586,10.863546644,184076.94045426804,2000000,287417,1712583,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,debug-addresses,1,0.259699210524559,0.1192165160000016,77012.17096348722,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,swap-new-0,100,10.012499140575528,10.010160844000005,199750.3292554628,2000000,287417,1712583,0,34357270507,91666407054,7153026446,128692240,10023.51,0,0,0,True,,,,,,,,
direct-rc1-swap,7,swap-new-1,100,9.55219812784344,9.54888579,209375.89162543174,2000000,287417,1712583,0,34314149372,91666402852,7153023573,127859433,9550.70,0,0,0,True,,,,,,,,
direct-rc1-swap,2,swap-new-2,100,9.865578438155353,9.863015486999998,202725.0619451723,2000000,287417,1712583,0,34431596506,91666407765,7153027663,129952524,9864.77,0,0,0,True,,,,,,,,
direct-rc1-swap,2,debug-addresses,1,0.2906538927927613,0.13044851499999766,68810.36344577765,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,swap-original-0,100,10.66928874887526,10.666609315999999,187453.92003856273,2000000,287417,1712583,0,38103137993,91666409986,7153030751,130402649,10668.55,0,0,0,True,,,,,,,,
direct-rc1-swap,7,swap-original-1,100,9.704302923753858,9.702256726999998,206094.1435684648,2000000,287417,1712583,0,34533436158,91666405904,7153024765,128397712,9703.73,0,0,0,True,,,,,,,,
direct-rc1-swap,2,swap-original-2,100,10.7892279420048,10.783038221999988,185370.0756671909,2000000,287417,1712583,0,38284073725,91666400640,7153025975,130856008,10785.65,0,0,0,True,,,,,,,,
direct-rc1-swap,2,debug-addresses,1,0.2544568618759513,0.11382681999999988,78598.78429904586,20000,2852,17148,0,,,,,,,,,,,,,,,,,
direct-rc1-swap,2,swap-new-again-0,100,9.562457513064146,9.560808163000004,209151.25607278437,2000000,287417,1712583,0,34285263641,91666395705,7153023034,128392472,9562.20,0,0,0,True,,,,,,,,
direct-rc1-swap,7,swap-new-again-1,100,9.662747577764094,9.660900096999995,206980.4663636664,2000000,287417,1712583,0,34546594887,91666400409,7153023078,128438618,9662.62,0,0,0,True,,,,,,,,
direct-rc1-swap,2,swap-new-again-2,100,9.761698553338647,9.752361876999998,204882.37667572414,2000000,287417,1712583,0,34476135194,91666402886,7153024228,128491098,9755.67,0,0,0,True,,,,,,,,
```

</details>


<details>
<summary>Validation result</summary>

```json
{
  "workers": 48,
  "correctness_checks": 48,
  "samples": 186,
  "fixed_output_counts": {
    "50": [
      1000000,
      143519,
      856481,
      0
    ],
    "100": [
      2000000,
      287417,
      1712583,
      0
    ],
    "20": [
      400000,
      57358,
      342642,
      0
    ],
    "1": [
      20000,
      2852,
      17148,
      0
    ]
  },
  "total_attempted_shots": 233340000,
  "excluded_counters": "All four six-event memory passes in direct-rc1-fixed-address: two had inconsistent cycle/instruction counts despite reporting 100% running. Repeated with four-event passes in fixed-hash."
}
```

</details>
