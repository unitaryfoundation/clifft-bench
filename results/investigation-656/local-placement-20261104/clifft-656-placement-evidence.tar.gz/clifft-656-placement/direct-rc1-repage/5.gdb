set pagination off
set confirm off
attach 3953982
break *0x7ffff1deb420
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
disable 1
python
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
print('REPAGE address', hex(address))
gdb.execute('call (int)madvise((void*)%d, 24576, 4)' % address)
inferior.write_memory(address, saved)
print('REPAGE restored', bytes(inferior.read_memory(address, 24576)) == saved)
end

detach
quit
end
python open('/tmp/clifft-656-placement/direct-rc1-repage/5.gdb-ready','w').write('ready')
continue
