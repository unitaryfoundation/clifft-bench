set pagination off
set confirm off
attach 3954926
break *0x7ffff1deb420
condition 1 *(unsigned char*)($rdi+0x54) == 10
commands 1
silent
printf "state=%p real=%p imag=%p rotation=%p stack=%p x=%llu z=%llu\n", $rdi, $rdx, $r8, $rsi, $rsp, *(unsigned long long*)($rsi+8), *(unsigned long long*)($rsi+16)
x/12gx $rdi
disable 1
python
import json, subprocess
from pathlib import Path
inferior = gdb.selected_inferior()
address = int(gdb.parse_and_eval('$rdx'))
saved = bytes(inferior.read_memory(address, 24576))
def frames():
    return subprocess.check_output(['sudo','-n','python3','/tmp/clifft-656-placement/page_frames.py',str(inferior.pid),str(address),'6'],text=True).strip()
def call(expression):
    value=int(gdb.parse_and_eval(expression))
    assert value != -1 and value != (1<<64)-1, expression
    return value
print('SWAP before', frames())
slots=Path('/tmp/clifft-656-placement/direct-rc1-swap/2-swap-slots.json')
if not slots.exists():
    parked=call('(long)mmap((void*)0,24576,3,34,-1,0)')
    temporary=call('(long)mmap((void*)0,24576,3,34,-1,0)')
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address,parked))==parked
    assert call('(long)mmap((void*)%d,24576,3,50,-1,0)' % address)==address
    slots.write_text(json.dumps({'parked':parked,'temporary':temporary}))
else:
    locations=json.loads(slots.read_text())
    parked,temporary=locations['parked'],locations['temporary']
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (address,temporary))==temporary
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (parked,address))==address
    assert call('(long)mremap((void*)%d,24576,24576,3,(void*)%d)' % (temporary,parked))==parked
inferior.write_memory(address,saved)
assert bytes(inferior.read_memory(address,24576))==saved
print('SWAP after', frames())
print('SWAP restored bytes',len(saved))
end

detach
quit
end
python open('/tmp/clifft-656-placement/direct-rc1-swap/2-new.gdb-ready','w').write('ready')
continue
