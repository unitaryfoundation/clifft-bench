import csv
import hashlib
import io
import json
from pathlib import Path

root = Path('/tmp/clifft-656-placement')
runs = ['direct-rc1','direct-rc1-fixed-address','direct-rc1-fixed-hash',
        'direct-rc1-addresses','direct-rc1-repage','direct-rc1-swap']
rows=[]
outputs={}
correctness=0
workers=set()
for name in runs:
    folder=root/name
    for event in map(json.loads,(folder/'results.jsonl').read_text().splitlines()):
        if 'result' not in event:
            continue
        result=event['result']
        assert result['ok']
        workers.add((name,event['worker']))
        if event['request']['command']=='prepare':
            assert result['affinity']['applied']
            assert result['runtime_metadata']['effective_batch_size']==1
            assert result['runtime_metadata']['address_space_limit_bytes']==12*(1<<30)
        if event['request']['command']=='correctness':
            assert not result['contract_errors']
            correctness+=1
        if event['request']['command']!='sample':
            continue
        calls=result['api_calls']
        assert result['attempted_shots']==20000*calls
        assert result['attempted_shots']==result['accepted_shots']+result['discarded_shots']
        assert result['seed_first']==20270819 and result['seed_last']==20270819+calls-1
        counts=tuple(result[k] for k in ['attempted_shots','accepted_shots','discarded_shots','logical_errors'])
        outputs.setdefault(calls,set()).add(counts)
        row={'run':name,'worker':event['worker'],'phase':event['phase'],'calls':calls,
             'seconds':result['duration_seconds'],'cpu_seconds':result['process_cpu_seconds'],
             'shots_per_second':result['throughput_attempted_shots_per_second'],
             'attempted':counts[0],'accepted':counts[1],'discarded':counts[2],'errors':counts[3]}
        perf=folder/f'{event["worker"]}-{event["phase"]}.csv'
        if perf.exists():
            counters={r[2]:r[0] for r in csv.reader(perf.read_text().splitlines()) if len(r)>3}
            row.update(counters)
            row['counter_usable']=not(name=='direct-rc1-fixed-address' and event['phase'].startswith('memory'))
        rows.append(row)
assert correctness==48 and len(workers)==48
assert all(len(values)==1 for values in outputs.values()),outputs
fields=list(dict.fromkeys(key for row in rows for key in row))
with (root/'all-samples.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
summary={'workers':len(workers),'correctness_checks':correctness,'samples':len(rows),
         'fixed_output_counts':{str(k):list(next(iter(v))) for k,v in outputs.items()},
         'total_attempted_shots':sum(r['attempted'] for r in rows),
         'excluded_counters':'All four six-event memory passes in direct-rc1-fixed-address: two had inconsistent cycle/instruction counts despite reporting 100% running. Repeated with four-event passes in fixed-hash.'}
(root/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('CSV bytes',(root/'all-samples.csv').stat().st_size)
